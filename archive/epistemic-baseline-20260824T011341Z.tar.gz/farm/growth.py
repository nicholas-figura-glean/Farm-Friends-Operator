"""Growth policy: is buying more animals still buying more output?

rules.py owns the arithmetic (it is pure by contract); this module owns the state
and the file reads. The verdict is persisted in state/growth.json so a thin
evidence window holds the previous decision instead of flip-flopping, and so the
plateau recorded at saturation survives restarts.

Why this exists: adoption used to be capped only by a safety number tuned to keep
the cycle inside its budget. That is the wrong axis. Measurement showed total
production is capped per farm, so past roughly 8,000 animals every extra chicken
cost 10 coins plus ongoing feed and produced nothing. The cap is now an economic
decision, re-measured every run, and it reverses itself automatically if the
ceiling ever moves.
"""

import json
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from . import rules

STORE = os.path.join("state", "growth.json")
HISTORY = os.path.join("state", "history.ndjson")
# Enough tail to keep the smaller-herd cohort in view long after growth stops,
# but bounded so a long-lived farm never reads a huge file every cycle.
TAIL_BYTES = 2_000_000
TAIL_ROWS = 400


def _utcnow() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_ts(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def load() -> Dict[str, Any]:
    try:
        with open(STORE) as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def save(model: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(STORE), exist_ok=True)
        tmp = "%s.tmp.%d" % (STORE, os.getpid())
        with open(tmp, "w") as fh:
            json.dump(model, fh, indent=1, sort_keys=True)
        os.replace(tmp, STORE)
    except OSError:
        pass


def _tail_rows() -> List[Dict[str, Any]]:
    """Last N history rows, read from the end so file size stays irrelevant."""
    try:
        size = os.path.getsize(HISTORY)
        with open(HISTORY, "rb") as fh:
            if size > TAIL_BYTES:
                fh.seek(size - TAIL_BYTES)
                fh.readline()  # discard the partial line
            blob = fh.read().decode("utf-8", "replace")
    except OSError:
        return []
    rows = []
    for line in blob.splitlines()[-TAIL_ROWS:]:
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict) and not row.get("dry"):
            rows.append(row)
    return rows


def samples(rows: Optional[List[Dict[str, Any]]] = None) -> List[Tuple[int, float]]:
    """(animals, units/min) pairs from consecutive runs.

    Lifetime produce from the leaderboard is the measurement, not units collected:
    it counts production even when the barn is not drained (run 25 gained 41,207
    produce while a single collect call returned 572 units).
    """
    rows = rows if rows is not None else _tail_rows()
    raw: List[Tuple[int, float, int, int]] = []
    for before, after in zip(rows, rows[1:]):
        produced_before, produced_after = before.get("produce"), after.get("produce")
        if produced_before is None or produced_after is None:
            continue
        start, end = _parse_ts(before.get("ts")), _parse_ts(after.get("ts"))
        if not start or not end:
            continue
        minutes = (end - start).total_seconds() / 60.0
        raw.append(
            (
                int(after.get("animals") or 0),
                minutes,
                int(produced_after) - int(produced_before),
                int(after.get("max_hunger") or 0),
            )
        )
    return rules.clean_samples(raw)


def decide(
    current_animals: int,
    knobs: Dict[str, Any],
    run: Optional[int] = None,
    persist: bool = True,
) -> Dict[str, Any]:
    """Verdict + adoption cap for this run, persisting any change of mind."""
    model = load()
    verdict = rules.growth_verdict(samples(), current_animals, model)
    cap, reason = rules.adoption_cap(verdict, knobs)

    changed = bool(model.get("saturated")) != bool(verdict.get("saturated"))
    record = dict(verdict)
    record["updated_ts"] = _utcnow()
    record["run"] = run
    record["cap"] = cap
    if changed or not model:
        record["changed_ts"] = _utcnow()
        record["changed_run"] = run
    else:
        record["changed_ts"] = model.get("changed_ts")
        record["changed_run"] = model.get("changed_run")
    if persist:
        save(record)

    return {"cap": cap, "reason": reason, "verdict": record, "changed": changed and persist}


def status() -> Dict[str, Any]:
    """Current growth policy for reporting, without re-measuring."""
    model = load()
    if not model:
        return {"saturated": False, "reason": "no measurement yet", "cap": None}
    return model
