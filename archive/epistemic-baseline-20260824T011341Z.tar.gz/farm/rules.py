"""Settled strategy rules, previously carried in the LLM prompt.

Everything here is pure arithmetic over parsed state: no I/O, no model.
Change a rule here and every future cycle follows it, at zero token cost.
"""

import math
from typing import Any, Dict, List, Optional, Tuple

# --- market -----------------------------------------------------------------
ANIMAL_COST = {"chicken": 10, "pig": 20, "sheep": 20, "beehive": 25, "cow": 30}
ITEM_VALUE = {
    "egg": 2,
    "wheat": 2,
    "corn": 3,
    "wool": 4,
    "milk": 5,
    "honey": 6,
    "pumpkin": 6,
    "truffle": 8,
    "feed": 1,
    "coin": 1,
}
FEED_COST = 1

# --- engine choice (settled by large-sample measurement) --------------------
PRIMARY_KIND = "chicken"
MEASURED_UNITS_PER_COIN_TICK = {"chicken": 0.0895, "beehive": 0.0235, "pig": 0.0210}

# Adoption is restricted to one kind, now by EXPERIMENT rather than inference.
#
# The per-farm ceiling below was originally measured by varying chicken count
# only, which left an obvious alternative alive: maybe the cap is per KIND, and
# the farm was capped on eggs while four other species sat unused. The supporting
# evidence was real - across runs 7-47 the egg rate per chicken fell 0.25 -> 0.134
# units/min while the 2 pigs and 1 beehive held 0.25-0.29 units/animal/min, which
# is exactly what a per-kind cap would look like.
#
# Tested directly at run 50 (experiments/species_probe.py): 100 each of pig,
# sheep, cow and beehive adopted in one batch, 9,517 coins out of 570k idle.
# Result over the following six runs (25 minutes):
#
#   kind      n      produce
#   sheep   100      0 wool, ever
#   cow     100      0 milk, ever
#   pig     102      1-2 truffles/run - identical to the 2 pigs before
#   beehive 101      1-2 honey/run   - identical to the 1 beehive before
#
# Total output stayed at ~1,550/min and hunger stayed at 0 for the new animals,
# so this is not a warm-up artifact. The cap is per FARM and already saturated:
# an animal of any kind added past saturation produces nothing. The per-kind
# hypothesis is dead, and adopting anything is a pure feed liability.
ADOPTABLE_KINDS = ("chicken",)   # and only while growth_verdict() says it pays

# Crops were banned on prompt-era reasoning (worse units/coin than chickens).
# Also tested at run 50: one wheat, one corn and one pumpkin plot planted. 27
# minutes later all three still read "0% grown, about 15/20/30 min left" - the
# timers do not advance, so a plot is a coin sink that never yields produce.
# plant() does create unlimited extra plots, so this would have scaled badly.

# --- husbandry --------------------------------------------------------------
# REVERSED after measurement. The reasoning that produced the cooldown was that
# feed_animals('all') costs ~1.1-1.5 feed per fed animal regardless of hunger, so
# feeding less often had to be cheaper. It is cheaper, and it is much worse:
# production degrades sharply as time since the last bulk feed grows.
#
#   run  fed   u/chicken/min   revenue   feed cost   net per chicken
#   14   yes   0.294           15956     5171        1.96
#   15   no    0.177           10842     1404        1.52
#   16   no    0.056            3886     1216        0.39
#
# Feed is not a cost to minimise, it is the input that production scales with:
# skipping two feeds cut net revenue per chicken by 80%. So feed every run, with
# a trigger low enough that any hunger at all qualifies.
FEED_AT_HUNGER = 6           # effectively "feed whenever anyone is hungry"
FEED_URGENT_HUNGER = 60      # also triggers mop-up of individuals by id
FEED_COOLDOWN_RUNS = 0       # no cooldown: see the table above
HUNGER_STOP = 70             # production stops entirely here
HUNGER_ALARM = 66            # only alarm when genuinely close to the stop

# RAISED 2 -> 50 after the run 291 starvation (see below). 2/animal was sized
# for the steady state only: at 11,869 animals it bought 23,753 feed, and the
# herd burns ~1,200 feed/minute, so the whole reserve was ~20 minutes of buffer.
# The loop is scheduled by launchd StartInterval, which does NOT fire while the
# Mac is asleep. A 19.3-hour sleep gap between run 290 and run 291 therefore
# starved the herd within the first ~20 minutes: hunger hit 100, crossed
# HUNGER_STOP, and production stopped for ~19 hours while 2.9M coins sat idle.
# Feed costs 1 coin, so the entire outage was avoidable for ~600k coins.
#
# 50/animal at the current herd is ~593k feed, ~8 hours of buffer, ~17% of the
# coin balance. FEED_BUFFER_MIN_MINUTES is the real intent; the per-animal
# number is the cheap approximation the plan arithmetic uses.
# 30/animal is ~290 minutes of runway at the measured burn, comfortably above
# FEED_BUFFER_MIN_MINUTES while costing half of what 50/animal locked up. Feed
# capital that is not needed for the buffer belongs in animals, which is what
# actually scores.
FEED_PER_ANIMAL_RESERVE = 30
FEED_BUFFER_MIN_MINUTES = 240   # alert if the reserve is worth less than this
FEED_BURN_PER_ANIMAL_MIN = 0.104  # measured: ~1,235 feed/min at 11,869 animals
MAX_INDIVIDUAL_FEEDS = 25    # mop-up is only for animals at FEED_URGENT_HUNGER+

# How far under the reserve target we tolerate before treating it as an incident.
#
# The target is recomputed from the FINAL animal count, but buy_feed was sized
# from an earlier count, and experiments/expand.py adopts throughout the run. So
# growing fast structurally leaves us a few hundred feed short of a target that
# moved underneath us. That is not a starvation signal, and the remedy for this
# alert class halves the adopt cap.
#
# Runs 337-347: short by 390 of 789,135 (0.05%) cut the adopt cap 400 -> 50 over
# four runs while the runway was a healthy 288 minutes the whole time. 15 of 20
# firings across 120 runs were false alarms.
#
# Sized to absorb one cycle's worth of concurrent adoption: ~1,100 animals at
# 30 feed each. The runway detector (FEED_BUFFER_MIN_MINUTES) remains the real
# guard, because it is denominated in the unit of the threat.
FEED_RESERVE_TOLERANCE_MIN = 40000
FEED_RESERVE_TOLERANCE_FRACTION = 0.02

# --- production measurement -------------------------------------------------
# Production is NOT a global 5-minute tick: the event feed shows per-animal
# timers, so units collected depends on how long it has been since the last
# collection. Everything is therefore measured per chicken per MINUTE.
# Observed healthy range across runs 2-6: 0.09-0.63 units/chicken/min.
# Lower bound raised to catch hunger-driven degradation: a fed herd runs
# 0.28-0.40, and 0.056 was the signature of two skipped feeds.
UNITS_PER_CHICKEN_MIN_BAND = (0.10, 1.00)
MIN_INTERVAL_FOR_RATE_CHECK = 4.0   # minutes; shorter samples are meaningless
ZERO_COLLECT_RUNS_TO_ALARM = 3      # consecutive empty collections before alarm

# --- what actually scores ---------------------------------------------------
# Units collected is NOT the score. Two measured facts make it a lagging and
# sometimes badly wrong proxy:
#   1. Lifetime produce accrues as animals produce, not when we collect it. Run 25
#      gained 41,207 produce while a collect call returned 572 units.
#   2. collect_produce answers "Nothing to collect right now ... or make sure your
#      animals are fed" while any hunger is present, and the produce then appears
#      in the barn after feed_animals. Runs 50 and 51 recorded collected={} and
#      then sold 11,597 and 7,934 eggs in the same run.
# So the authoritative measure of "are we still producing" is the leaderboard
# produce delta per minute, and that is what the detector below judges. It also
# catches the one failure that can actually cost the game: the herd reaching
# hunger 70, where production stops entirely while collection still looks normal.
# Floor is ~40% of the measured 1,550/min plateau at this herd size, but it must
# scale: an early 1,177-animal farm produced ~180/min and a fixed floor would
# have called that an incident every run. Measured healthy output is ~0.135
# produce/animal/min, so 0.05 is a ~third of that - low enough never to fire on
# ordinary variation (observed 927-2,075/min at 11.9k animals), high enough to
# catch production actually stopping.
PRODUCE_PER_MIN_FLOOR = 600.0
PRODUCE_FLOOR_PER_ANIMAL = 0.05
MIN_INTERVAL_FOR_PRODUCE_CHECK = 3.0

# A low measured rate has two very different causes and only one is an incident:
#   1. production degraded (hunger, a server change)  -> must alarm
#   2. there was simply nothing left to collect       -> must NOT alarm
# Case 2 dominated at herd scale and generated an alert nearly every run: runs
# 27-29 collected 62-760 units but ended with only 666-3303 units still ready,
# i.e. the herd was drained, not broken. Backlog is the discriminator, so the
# throughput detector consults it before crying wolf.
READY_BACKLOG_FLOOR = 2000          # absolute backlog considered "drained"
READY_BACKLOG_PER_ANIMAL = 0.5      # plus half a unit per animal
MAX_COLLECT_PASSES = 3              # bounded drain when backlog is real
# Collect every Nth run instead of every run. collect_produce costs ~75s at
# 17,000 animals and grows with the herd, and it is the single largest block of
# server time the cycle spends. It does NOT create score: lifetime produce
# accrues as animals produce, and uncollected produce accumulates safely (run 25
# gained 41,207 produce while one collect returned 572 units). Its only purpose
# is converting produce into coins.
#
# Coins are not the binding constraint - adoption THROUGHPUT is. Revenue runs far
# ahead of feed burn plus adoption spend, so trading collection frequency for
# server capacity buys herd, which is what actually scores. One collect still
# drains the whole accumulated backlog.
# RAISED 3 -> 10 after measuring what collection actually costs at scale. At
# ~26,000 animals collect_produce takes ~97s and is one of only two calls that
# FAIL (504 Gateway Timeout); adopt_animal ran 1,483 times with zero failures in
# the same window. Collection banks coins, and coins are in gross surplus - 3.7M
# sat unspent while the herd stalled - so paying 97s and a 504 for money we
# cannot spend is the worst trade available. The backlog override in
# should_collect() still forces a drain if produce genuinely piles up.
COLLECT_EVERY = 10
# Collection exists to fund feed, so that is what gates it. The previous override
# used barn backlog, which was self-defeating at scale: collecting rarely makes
# the backlog grow, the backlog then forces a collect every run, and COLLECT_EVERY
# was nullified - observed as a ~97s collect on every single run with coins at
# 3.67M against a reserve need of 852k (4.3x covered).
#
# Uncollected produce is ALREADY scored: lifetime produce accrues as animals
# produce. So a backlog costs nothing but unbanked coins, and collect only has to
# run when coins stop comfortably covering the feed reserve. This self-regulates:
# reserve_target grows with the herd, so collection resumes on its own.
COLLECT_COIN_COVER = 2.0
# A generous absolute valve. There is no evidence that a large barn throttles
# production (produce kept accruing at 31,748 ready), but this bounds the unknown.
COLLECT_READY_CEILING = 500_000

# Measured cost of the two whole-herd calls, used to decide whether a collect can
# still fit inside the cycle budget. Bulk feed is a linear fit over runs 294-372
# (n=60): feed_seconds = 0.001755*herd + 23.4. Collect has measured ~97s flat at
# every herd size from 25k to 58k, which is the gateway giving up, not real work.
# Overhead is the observed cost of read + adopt + verify + leaderboard.
BULK_FEED_SECONDS_PER_ANIMAL = 0.001755
BULK_FEED_SECONDS_BASE = 23.4
COLLECT_OBSERVED_SECONDS = 97.0
CYCLE_OVERHEAD_SECONDS = 45.0

# Even a call we believe is dead gets retried occasionally, so that "collect does
# not work at this herd size" stays a measurement instead of becoming folklore.
# One attempt per this many runs costs ~97s and tells us if the server improved.
COLLECT_REPROBE_RUNS = 40

# --- expansion --------------------------------------------------------------
# Growth must leave enough of the 150s cycle budget for collection and feeding.
# At herd scale, a 2,000-call plan monopolizes the cycle, causes launchd skips,
# and turns a three-minute collection cadence into 15-30 minute gaps.
#
# This is the SAFETY ceiling only. The economic decision is separate and lives in
# growth_verdict() below: measurement showed total output stops responding to
# herd size, at which point the right cap is zero, not 25.
MAX_ADOPTIONS_PER_RUN = 400
# Raised 25 -> 400 in the run 291 recovery. 25/run was sized when the herd was
# a few hundred animals; it is now the binding constraint on catching up.
# adopt_animal is one call per animal and the limiter allows ~4.5-5 calls/s, so
# a ~90s adoption window supports ~400. adopt_chickens() still stops on the
# wall-clock deadline, so this is a ceiling and never a mandate.
# launchd cadence is 180s. Phase timing showed ~65-75s of every run is
# inherent server work (collect ~30-40s and bulk feed ~35s at this herd size)
# that no amount of adoption parallelism can shrink. Keep the full cycle below
# the scheduler interval so skipped launches do not stretch feed/collection
# intervals and depress production.
# MEASURED at ~17,000 animals: collect_produce takes ~75s and feed_animals("all")
# ~83s. Those two calls alone are ~158s, so a 150s budget and a 170s watchdog
# could not fit one honest cycle - runs 304-305 died on "exceeded 170s hard
# timeout", which silently costs a feeding. Both calls scale with herd size, so
# the budget has to be sized from the server's real latency, not from a tidy 180s
# cadence. Cadence is now 300s with a 260s budget: still one feed every ~5
# minutes, which measured hunger 0 at 5.75-9.1 minute intervals.
CYCLE_BUDGET_SECONDS = 260
# The scheduler cadence, restated here so detectors can reason about gaps.
# launchd StartInterval does not fire while the machine is asleep, so a gap is
# silent: run 290 -> 291 was 19.3 hours and nothing complained until the herd
# had already starved past HUNGER_STOP and the rank was lost.
CYCLE_INTERVAL_SECONDS = 300
RUN_GAP_ALARM_MINUTES = 30
# Call-rate ceiling, established by measurement from two directions:
#  - throughput: 6 workers gave 0.68s mean adopt latency and 4.19 calls/s;
#    8 workers gave 1.64s and 4.67 calls/s. The server queues instead of
#    scaling, so asking for more than ~5/s buys nothing and only adds load.
#  - errors: runs at 6/s were clean, 8/s produced transport retries.
# Note this file has two writers - a human/agent editing it directly and the
# hourly supervisor automation reacting to alerts. releases/ is the audit trail.
MAX_CALLS_PER_SECOND = 5.0      # global, shared across all workers
SLOW_CALL_SECONDS = 1.2         # mean adopt SERVICE latency that triggers a courtesy ease-off

# Measured server service time for a single call with the limiter wide open and
# no concurrency: median 0.670s over 6 samples (2026-08-23, herd 61,586).
# SLOW_CALL_SECONDS must stay clear of this, or the courtesy ease-off fires during
# normal operation and throttles the only call that scores. It previously fired
# every run because the measurement included the rate-limiter wait (~workers/rate
# = 2.4s at 6 workers and 2.5/s) rather than the server's own latency.
MEASURED_SERVICE_SECONDS = 0.670
# Sized against the 300s cadence and the measured ~158s of unavoidable server
# work (collect ~75s + bulk feed ~83s), with headroom for reads and adoption.
CYCLE_HARD_TIMEOUT = 285        # self-kill before the next 300s run is due
# RAISED 0.5 -> 2.5. A 504 Gateway Timeout on this server is about call WEIGHT,
# not call rate: list_farm is ~1.6MB at 25,000 animals and feed_animals("all")
# touches every animal. Slowing the call rate cannot make a heavy call lighter,
# so throttling was treating the wrong variable - and it ratcheted:
# 5.00 -> 4.00 -> 3.20 -> 2.56 -> 2.05 -> 1.64 -> 1.31 -> 1.05/s over a few
# hours, which crippled adoption while John grew 45,179 -> 56,048 animals.
# 2.5/s is a floor that still lets the farm compete if healing misfires again.
MIN_CALLS_PER_SECOND = 2.5      # floor after repeated server errors
TRANSPORT_RETRY_ALARM = 5       # single retries are noise, not incidents
# The ratio clause used to apply at any call volume, so a single retry in a
# 35-call run (2.9%) looked like an incident and also convinced the cycle that
# the previous run was "unclean", which pinned the rate limiter at the 0.5/s
# floor for runs on end. A ratio is only meaningful once there are enough calls.
TRANSPORT_RATIO = 0.02
TRANSPORT_RATIO_MIN_CALLS = 100
ADOPT_WORKERS = 6               # more workers only queue; see the note above
ADOPT_PARALLEL_THRESHOLD = 20   # below this, serial is simpler and fast enough
VERIFY_EVERY = 6                # full re-read cadence when nothing looks off
JOURNAL_EVERY = 20              # journal entries are generated in Python

# --- trades -----------------------------------------------------------------
RIVALS = ("Guillermo G.", "John", "Neill", "Moe", "Aaron")
PREFERRED_TRADE_TARGETS = ("Guillermo G.", "Neill", "Aaron", "John", "Moe")
MAX_OPEN_OFFERS = 3
OFFER_FEED_QTY = 5
OFFER_COIN_WANT = 10
OFFER_MIN_AGE_MINUTES = 60  # never withdraw an unanswered offer younger than this
DECLINE_PAUSE_THRESHOLD = 2

# --- prohibitions -----------------------------------------------------------
FOOD_CROPS_BANNED = True
NEVER_SELL = ("feed",)
THREAT_SHARE = 0.50  # rival units/tick at or above this share of ours escalates

# --- self-healing -----------------------------------------------------------
# The supervisor remediates recurring alert classes in Python instead of waking
# a model. Every knob below can only make the loop MORE conservative or make it
# do bounded extra work, so a healing decision can never be catastrophic. Knobs
# relax one step per clean run so a transient incident does not throttle the
# farm forever.
HEAL_ENABLED = True
HEAL_MAX_ATTEMPTS = {
    # Transport healing is capped hard. Each 504 burst used to be allowed 4 fresh
    # throttles, and HEAL_ATTEMPT_RESET_RUNS cleared the counter after 4 quiet
    # runs, so a flaky server could ratchet the rate ceiling down indefinitely.
    # Throttling never fixed the 504s (they are heavy-call timeouts), so one
    # courtesy step per window is all it gets.
    "transport": 1,
    "backpressure": 2,
    "throughput": 3,
    "hunger": 3,
    "feed_reserve": 3,
    "zero_collect": 2,
    "adopt_failures": 2,
    "individual_feeds": 3,
    "stale_loop": 5,
}
HEAL_ATTEMPT_RESET_RUNS = 4     # a class quiet this long starts over

# How long an alert stays actionable. An alert describes one instant; a remedy is
# applied to the farm as it is NOW, so evidence has to expire or the healer acts
# on conditions that no longer hold. Unbounded, the queue re-threw an alert from
# run 28 at a farm 350 runs later and throttled the call rate on it - twice,
# after both throttles had already been reset, because the justification never
# aged out. At a ~5 minute cadence this is roughly 24 runs of history.
ALERT_STALE_HOURS = 2.0
# An alert older than this describes a farm that no longer exists. Healing reads
# the LATEST row, so acting on a stale alert throttles current, healthy state:
# see the run 291 hunger alert that cut the adoption cap at run 295.
HEAL_ALERT_STALE_RUNS = 5
HEAL_SCHEDULER_MAX_REPAIRS_PER_HOUR = 4

# --- LLM cost model (estimates, for visibility only) ------------------------
# The whole point of the deterministic loop is that routine runs cost nothing.
# These figures price the exception path so the saving is measurable rather than
# asserted. Tokens are estimated from payload size; prices are per million.
CHARS_PER_TOKEN = 4.0
LLM_INPUT_COST_PER_MTOK = 3.00
LLM_OUTPUT_COST_PER_MTOK = 15.00
LLM_ESCALATION_CONTEXT_TOKENS = 9000   # system + runbook + tool defs per wake-up
LLM_ESCALATION_OUTPUT_TOKENS = 700     # typical investigation + reply


def feed_reserve_target(animal_count: int, committed_feed: int) -> int:
    """Feed we want on hand: FEED_PER_ANIMAL_RESERVE each plus open offers."""
    return FEED_PER_ANIMAL_RESERVE * animal_count + committed_feed


def feed_buffer_minutes(feed: int, animal_count: int) -> float:
    """How long the feed on hand lasts at the measured burn rate.

    This is the number that actually mattered in the run 291 post-mortem: the
    old reserve looked healthy as an absolute count (23,753) while being only
    ~20 minutes of runway. A buffer expressed in minutes can be compared
    directly against how long the loop might be asleep.
    """
    if animal_count <= 0:
        return float("inf")
    burn = FEED_BURN_PER_ANIMAL_MIN * animal_count
    if burn <= 0:
        return float("inf")
    return feed / burn


# The whole-herd calls. Both take one server round trip whose cost scales with
# the herd, and past ~25,000 animals both reliably exceed the gateway's ~97s
# ceiling and return 504 after burning all 3 retries.
#
# Crucially, feed_animals STILL COMPLETES server-side when it 504s: feed is
# debited, hunger resets, and the herd's max hunger has stayed between 6 and 24
# while the herd grew from 12k to 58k. The 504 is a gateway artifact, not a
# failure, and it is not something a lower call rate can fix - it is one call.
#
# They are therefore excluded from the signal used to throttle the call rate and
# the adoption workers. Including them cut our adoption in half for no reason
# (see mcp.Client.transport_errors_by_tool).
HEAVY_HERD_TOOLS = ("feed_animals", "collect_produce")


def core_transport_errors(by_tool: Optional[Dict[str, int]], total: int = 0) -> int:
    """Transport retries excluding the unavoidable whole-herd 504s.

    This is the number that should drive rate limiting, because it counts only
    failures a lower call rate could plausibly prevent. Falls back to `total`
    when per-tool attribution is missing (rows written before it existed).
    """
    if not by_tool:
        return int(total or 0)
    return sum(
        n for tool, n in by_tool.items() if tool not in HEAVY_HERD_TOOLS
    )


def transport_trouble(retries: int, calls: int) -> bool:
    """Whether transport retries are an incident rather than network noise.

    Shared by the detector and the cycle so that "clean enough to speed back up"
    and "quiet enough not to alarm" can never drift apart again.
    """
    retries = int(retries or 0)
    calls = int(calls or 0)
    if retries >= TRANSPORT_RETRY_ALARM:
        return True
    return calls >= TRANSPORT_RATIO_MIN_CALLS and retries > TRANSPORT_RATIO * calls


def backlog_drained(ready_units: int, animal_count: int) -> bool:
    """True when there was essentially nothing left to collect.

    A low units/chicken/min reading is only evidence of a production problem if
    produce is actually piling up. If the barn is drained, the loop is keeping
    up and the low reading is an artifact of a short or stretched interval.
    """
    allowance = max(READY_BACKLOG_FLOOR, READY_BACKLOG_PER_ANIMAL * (animal_count or 0))
    return (ready_units or 0) <= allowance


def produce_floor(animal_count: Optional[int]) -> float:
    """Minimum believable score rate for a farm of this size."""
    scaled = PRODUCE_FLOOR_PER_ANIMAL * float(animal_count or 0)
    return min(PRODUCE_PER_MIN_FLOOR, scaled)


def produce_rate_trouble(
    produce_delta: Optional[int],
    minutes: Optional[float],
    animal_count: Optional[int] = None,
) -> Optional[float]:
    """Score rate over a window, returned only when it is genuinely too low.

    None means "nothing to say": either the window is too short to judge, or the
    farm is producing normally. A float is the offending rate, and it means
    production itself has degraded - the only class of failure that can actually
    lose the game, because it is the one thing no amount of collecting fixes.
    """
    if produce_delta is None or minutes is None:
        return None
    if minutes < MIN_INTERVAL_FOR_PRODUCE_CHECK:
        return None
    rate = float(produce_delta) / float(minutes)
    return rate if rate < produce_floor(animal_count) else None


def adoptable(kind: str) -> bool:
    """Measured: adopting anything outside ADOPTABLE_KINDS buys feed cost only."""
    return kind in ADOPTABLE_KINDS


def _clamp(value, low, high, default, cast=float):
    try:
        value = cast(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, value))


def rate_ceiling(knobs: Dict[str, object]) -> float:
    """Healing may lower the call-rate ceiling, never raise it above measurement."""
    return _clamp(
        (knobs or {}).get("rate_ceiling", MAX_CALLS_PER_SECOND),
        MIN_CALLS_PER_SECOND,
        MAX_CALLS_PER_SECOND,
        MAX_CALLS_PER_SECOND,
    )


def adopt_cap(knobs: Dict[str, object]) -> int:
    return int(
        _clamp(
            (knobs or {}).get("adopt_cap", MAX_ADOPTIONS_PER_RUN),
            1,
            MAX_ADOPTIONS_PER_RUN,
            MAX_ADOPTIONS_PER_RUN,
            int,
        )
    )


def adopt_worker_count(knobs: Dict[str, object]) -> int:
    return int(
        _clamp((knobs or {}).get("adopt_workers", ADOPT_WORKERS), 1, ADOPT_WORKERS, ADOPT_WORKERS, int)
    )


def individual_feed_cap(knobs: Dict[str, object]) -> int:
    return int(
        _clamp(
            (knobs or {}).get("individual_feeds", MAX_INDIVIDUAL_FEEDS),
            MAX_INDIVIDUAL_FEEDS,
            4 * MAX_INDIVIDUAL_FEEDS,
            MAX_INDIVIDUAL_FEEDS,
            int,
        )
    )


def collect_passes(knobs: Dict[str, object]) -> int:
    return int(_clamp((knobs or {}).get("collect_passes", 1), 1, MAX_COLLECT_PASSES, 1, int))


def collect_fits_budget(animals: int) -> bool:
    """Whether a whole-herd collect can still finish inside the watchdog.

    `collect_produce` takes no arguments, so unlike adoption it cannot be split
    or parallelised: it is one call whose cost scales with the herd, and it has
    measured ~97s flat while returning 504 and banking nothing.

    Meanwhile bulk feed costs 0.001755*herd + 23.4 seconds and is NOT optional.
    Adding a 97s collect on top crosses the 285s watchdog at roughly 70,000
    animals - and we need ~106,000 to retake first place. Left alone, the cycle
    would start dying from timeout a couple of hours before the herd got big
    enough to win, which is the run-291 failure again: a call that gets slower
    with success until success kills it.

    Collection is also the one thing we can drop for free. Lifetime produce - the
    score - accrues whether or not produce is collected: it has risen ~7,700/min
    for hours while every collect returned 504 and banked 0 units. Collection
    only converts ready produce into coins, and the coin runway (~14 h) already
    outlasts the projected win (~8 h).

    So this is a budget check, not a preference: skip collect once it cannot fit
    alongside the feed we actually need. It re-enables itself automatically if
    the herd shrinks or bulk feed gets cheaper, and COLLECT_REPROBE_RUNS forces
    an occasional attempt so a server-side improvement is noticed.
    """
    feed_cost = BULK_FEED_SECONDS_PER_ANIMAL * max(0, int(animals or 0)) + BULK_FEED_SECONDS_BASE
    return feed_cost + COLLECT_OBSERVED_SECONDS + CYCLE_OVERHEAD_SECONDS <= CYCLE_BUDGET_SECONDS


def should_collect(
    run_no: int,
    ready_units: int,
    animals: int,
    coins: Optional[int] = None,
    reserve_target: Optional[int] = None,
) -> bool:
    """Collect on the cadence, or early if coins stop covering the feed reserve.

    See COLLECT_EVERY / COLLECT_COIN_COVER. Collection banks coins; it does not
    create score, and at herd scale it is the most expensive and least reliable
    call the cycle makes (~97s at 26,000 animals, and the only call observed to
    fail with 504 Gateway Timeout while adopt_animal failed 0 times in 1,483).
    """
    # Budget gate first: a collect that cannot finish is not a collect, it is a
    # dead 97s plus three retries and a watchdog kill. Re-probe occasionally so
    # this stays a measurement rather than a permanent assumption.
    if not collect_fits_budget(animals):
        if COLLECT_REPROBE_RUNS > 0 and (int(run_no) % int(COLLECT_REPROBE_RUNS)) == 0:
            return True
        return False
    if COLLECT_EVERY <= 1:
        return True
    if (ready_units or 0) >= COLLECT_READY_CEILING:
        return True
    if coins is not None and reserve_target:
        # The only real reason to bank produce: we are running out of money to
        # keep the herd fed.
        if coins < reserve_target * COLLECT_COIN_COVER:
            return True
    return (int(run_no) % int(COLLECT_EVERY)) == 0


def escalation_cost(payload_tokens: int = 0) -> Tuple[int, int, float]:
    """Estimated (input, output, usd) for one LLM wake-up carrying payload."""
    tokens_in = int(LLM_ESCALATION_CONTEXT_TOKENS + max(0, payload_tokens))
    tokens_out = int(LLM_ESCALATION_OUTPUT_TOKENS)
    usd = (
        tokens_in / 1_000_000.0 * LLM_INPUT_COST_PER_MTOK
        + tokens_out / 1_000_000.0 * LLM_OUTPUT_COST_PER_MTOK
    )
    return tokens_in, tokens_out, round(usd, 6)


def should_feed(max_hunger: int, any_called_hungry: bool, runs_since_feed: int = 99) -> bool:
    """Feed on urgency always, or routinely once the cooldown has elapsed."""
    if max_hunger >= FEED_URGENT_HUNGER or any_called_hungry:
        return True
    return max_hunger >= FEED_AT_HUNGER and runs_since_feed >= FEED_COOLDOWN_RUNS


def sell_plan(inventory: Dict[str, int]) -> List[Tuple[str, int]]:
    """Sell every saleable good, most valuable first. Never sell feed."""
    plan = []
    for item, qty in inventory.items():
        if item in NEVER_SELL or qty <= 0 or item not in ITEM_VALUE:
            continue
        plan.append((item, qty))
    plan.sort(key=lambda p: ITEM_VALUE.get(p[0], 0) * p[1], reverse=True)
    return plan


def expansion_plan(
    coins: int,
    animal_count: int,
    feed: int,
    committed_feed: int,
    cap: int = None,
) -> Dict[str, int]:
    """Jointly solve feed top-up and chicken count.

    Each new chicken costs 10 coins plus 2 coins of feed reserve, so the true
    marginal cost is 12. Buy feed first (step 3 beats step 7), then adopt.
    `cap` lets the supervisor throttle growth without editing strategy.
    """
    cost = ANIMAL_COST[PRIMARY_KIND]
    limit = MAX_ADOPTIONS_PER_RUN if cap is None else max(0, min(int(cap), MAX_ADOPTIONS_PER_RUN))
    best = {"adopt": 0, "buy_feed": 0}
    for n in range(min(limit, coins // cost), -1, -1):
        target = feed_reserve_target(animal_count + n, committed_feed)
        need_feed = max(0, target - feed)
        if need_feed * FEED_COST + n * cost <= coins:
            best = {"adopt": n, "buy_feed": need_feed}
            break
    return best


# --- growth saturation ------------------------------------------------------
# Measured over runs 2-43: total production is capped per farm, not per animal.
#
#   herd size        samples   total output      per chicken
#   4,000- 6,000        3      970 units/min       0.194
#   6,000- 8,000        3    1,135 units/min       0.162
#   8,000-10,000        4    1,646 units/min       0.183
#   10,000-10,800       3    1,487 units/min       0.143
#   10,800-11,500      18    1,540 units/min       0.138
#
# Regression above 8,000 animals: -0.028 units/min per extra chicken (r=-0.065),
# i.e. indistinguishable from zero. The last ~3,400 chickens produced nothing
# while feed rose from 20% to 40% of revenue. The falling per-chicken figure is
# arithmetic, not degradation: a flat numerator over a growing denominator.
#
# So adoption is gated on evidence that output still responds to herd size.
# Crucially this is re-measured every run: if the server ever lifts the ceiling,
# output at the current herd size climbs above the recorded plateau and growth
# resumes on its own, with no model in the loop.
GROWTH_SAMPLE_MIN_MINUTES = 3.0   # shorter windows measure noise, not output
GROWTH_MIN_SAMPLES = 3            # per cohort, before any verdict is trusted
GROWTH_RECENT_BAND = 0.95         # >= 95% of current herd counts as "now"
# The comparison cohort is a WINDOW just below the current herd, not an open
# ended tail. Comparing against the whole history compares 11,400 animals with
# 420 and always concludes growth works; the question is whether the *marginal*
# few thousand animals paid, so the baseline has to be a herd of similar order.
GROWTH_SMALLER_HIGH = 0.90        # upper edge of the comparison window
GROWTH_SMALLER_LOW = 0.70         # lower edge of the comparison window
# LOWERED 0.10 -> 0.0 after the run 291-292 post-mortem, which found this single
# constant had cost us first place.
#
# The comparison window is 70-90% of the current herd, so "now" is only an
# 11-43% larger herd. Demanding a 10% output gain from that is demanding roughly
# LINEAR scaling. Our own measured curve is sub-linear but strictly rising:
#
#   herd            produce/min     per animal/min
#    1,500- 2,999        642            0.285
#    3,000- 4,499        831            0.222
#    4,500- 5,999      1,014            0.193
#    6,000- 7,499      1,135            0.168
#    7,500- 8,999      1,450            0.176
#    9,000-10,499      1,520            0.156
#   10,500-11,999      1,629            0.145
#
# Total output never plateaued; only efficiency per animal fell. The old bar read
# that as a ceiling (1,645/min vs 1,553/min = +5.9% < 10%), set the adoption cap
# to MAINTENANCE_ADOPTIONS, and froze the herd at 11,869 for 246 runs while 3.2M
# coins piled up. Meanwhile John scaled to 42,859 animals and took first place at
# 2,391 produce/min against our 1,752 - with WORSE efficiency per animal
# (0.056 vs our 0.148). He simply never stopped growing.
#
# Coins are not the score; lifetime produce is. An idle coin is a wasted coin, so
# the only reason to stop adopting is output actually falling. 0.02 is a noise
# floor on a median of 3+ samples, not an economic hurdle: it rejects
# measurement jitter while still permitting the sub-linear growth above.
GROWTH_MIN_MARGINAL_GAIN = 0.02
GROWTH_RESUME_MARGIN = 0.15       # output this far above plateau => ceiling moved
GROWTH_MIN_HERD_TO_SATURATE = 2000  # never let early noise stop initial growth
# Never let the verdict latch growth off completely. With MAINTENANCE_ADOPTIONS
# at 0 the gate was a one-way ratchet: adoption stopped, the herd froze, and the
# only way back was more output from the very herd it had frozen - which cannot
# happen. A nonzero floor keeps the experiment alive, and it is close to free
# because expansion_plan reserves the feed budget before spending on animals.
MAINTENANCE_ADOPTIONS = 25


def median(values: List[float]) -> Optional[float]:
    values = sorted(v for v in values if v is not None)
    if not values:
        return None
    return values[len(values) // 2]


def clean_samples(
    raw: List[Tuple[int, float, int, int]]
) -> List[Tuple[int, float]]:
    """Filter (animals, minutes, produce_delta, max_hunger) into (animals, rate).

    Rejects windows too short to mean anything, windows with no production, and
    windows where the herd was starving (which measures feeding, not capacity).
    """
    out: List[Tuple[int, float]] = []
    for animals, minutes, produced, hunger in raw:
        if not animals or not minutes or minutes < GROWTH_SAMPLE_MIN_MINUTES:
            continue
        if produced is None or produced <= 0:
            continue
        if (hunger or 0) >= HUNGER_ALARM:
            continue
        out.append((int(animals), float(produced) / float(minutes)))
    return out


def growth_verdict(
    samples: List[Tuple[int, float]],
    current_animals: int,
    model: Optional[Dict[str, object]] = None,
) -> Dict[str, object]:
    """Does adding animals still add output? Pure function over measurements.

    Returns the verdict plus the plateau it is holding, so the caller can persist
    it. The plateau is recorded once, when saturation is first detected, and then
    left alone: continuously re-baselining it would make a genuine ceiling lift
    invisible.
    """
    model = model or {}
    was_saturated = bool(model.get("saturated"))
    plateau = model.get("plateau")
    plateau = float(plateau) if isinstance(plateau, (int, float)) else None

    recent = [rate for animals, rate in samples if animals >= current_animals * GROWTH_RECENT_BAND]
    smaller = [
        rate
        for animals, rate in samples
        if current_animals * GROWTH_SMALLER_LOW
        <= animals
        <= current_animals * GROWTH_SMALLER_HIGH
    ]
    recent_med = median(recent)
    smaller_med = median(smaller)

    def verdict(saturated, reason, keep_plateau):
        return {
            "saturated": bool(saturated),
            "reason": reason,
            "plateau": keep_plateau,
            "recent_units_per_min": round(recent_med, 1) if recent_med else None,
            "smaller_units_per_min": round(smaller_med, 1) if smaller_med else None,
            "recent_samples": len(recent),
            "smaller_samples": len(smaller),
            "herd": int(current_animals or 0),
        }

    # A lifted ceiling shows up as more output from the SAME herd. Check it before
    # anything else, because it is the one signal that should restart growth.
    if (
        was_saturated
        and plateau
        and recent_med
        and len(recent) >= GROWTH_MIN_SAMPLES
        and recent_med > plateau * (1 + GROWTH_RESUME_MARGIN)
    ):
        return verdict(
            False,
            "output %.0f/min is %.0f%% above the %.0f/min plateau - ceiling lifted, resuming growth"
            % (recent_med, 100.0 * (recent_med / plateau - 1.0), plateau),
            None,
        )

    if (current_animals or 0) < GROWTH_MIN_HERD_TO_SATURATE:
        return verdict(False, "herd below %d - growing" % GROWTH_MIN_HERD_TO_SATURATE, None)

    if (
        recent_med is None
        or smaller_med is None
        or len(recent) < GROWTH_MIN_SAMPLES
        or len(smaller) < GROWTH_MIN_SAMPLES
    ):
        # Hold the previous decision rather than flip-flopping on thin evidence.
        return verdict(
            was_saturated,
            "insufficient samples (%d recent, %d smaller) - holding previous verdict"
            % (len(recent), len(smaller)),
            plateau,
        )

    if recent_med <= smaller_med * (1 + GROWTH_MIN_MARGINAL_GAIN):
        return verdict(
            True,
            "output %.0f/min at %d animals vs %.0f/min at %d-%d - the marginal herd buys no output"
            % (
                recent_med,
                current_animals,
                smaller_med,
                int(current_animals * GROWTH_SMALLER_LOW),
                int(current_animals * GROWTH_SMALLER_HIGH),
            ),
            plateau if was_saturated else recent_med,
        )

    return verdict(
        False,
        "output %.0f/min vs %.0f/min at %d-%d animals - still responding, growing"
        % (
            recent_med,
            smaller_med,
            int(current_animals * GROWTH_SMALLER_LOW),
            int(current_animals * GROWTH_SMALLER_HIGH),
        ),
        None,
    )


def adoption_cap(verdict: Dict[str, object], knobs: Dict[str, object]) -> Tuple[int, str]:
    """Final adoptions allowed this run: the stricter of safety and economics."""
    safety = adopt_cap(knobs)
    if verdict.get("saturated"):
        return MAINTENANCE_ADOPTIONS, str(verdict.get("reason") or "saturated")
    return safety, str(verdict.get("reason") or "growing")


def trade_value(item: str, qty: int) -> int:
    return ITEM_VALUE.get(item, 0) * qty


def should_accept(offer_item: str, offer_qty: int, want_item: str, want_qty: int) -> bool:
    """Accept only when what we receive is worth at least what we give."""
    return trade_value(offer_item, offer_qty) >= trade_value(want_item, want_qty)


def offer_targets(current_recipients: List[str], paused: List[str]) -> List[str]:
    """Which farmers to send a fresh 5-feed-for-10-coin offer to."""
    have = {r.strip().lower() for r in current_recipients}
    blocked = {p.strip().lower() for p in paused}
    slots = MAX_OPEN_OFFERS - len(have)
    if slots <= 0:
        return []
    out = []
    for name in PREFERRED_TRADE_TARGETS:
        if len(out) >= slots:
            break
        key = name.strip().lower()
        if key not in have and key not in blocked:
            out.append(name)
    return out


# --- the objective ----------------------------------------------------------
# Everything above tunes a proxy: hunger, runway, throughput, call rate. None of
# it answers the only question that decides the game - are we going to pass the
# leader, and when?
#
# That absence is a real failure mode, not a cosmetic gap. The growth gate froze
# the herd for 246 runs while "healthy" on every proxy, and the healer ratcheted
# adoption down four times while the farm was in perfect condition. Both would
# have been caught immediately by a number that went the wrong way.
#
# The model is deliberately simple, because it is measured, not assumed:
#   - output is LINEAR in herd size (postmortem addendum: 0.175-0.187
#     produce/animal/min for both farms, no per-farm ceiling)
#   - so produce accumulates quadratically while the herd grows linearly
#
# For each side, with y = produce per animal per minute and g = animals per
# minute of adoption:
#
#   produce(t) = P + R*t + 0.5 * y * g * t**2
#
# We pass the leader at the first positive root of the difference. Behind on
# produce, we win only if our herd grows faster than theirs; if their rate is
# higher and they are growing at least as fast, there is no root and no plan.
WIN_ETA_ALARM_HOURS = 24.0   # a plausible ETA; beyond this we are not really racing
# A rival herd jump this large is a strategic event, not noise. Sized above the
# handful of animals a bankrupt rival adds by accident (John added 4 in 1.2h).
RIVAL_HERD_GROWTH_ALARM = 250
# The leader's produce is sampled in lumpy windows (John measured 884-8,321
# produce/min across runs 344-353 while his herd never moved), so the projection
# smooths it. 0.35 keeps ~3 runs of memory: responsive enough to catch a rival
# who genuinely wakes up, steady enough not to fire on one sample.
RIVAL_RATE_EWMA_ALPHA = 0.35


def win_projection(
    our_produce: int,
    our_rate: float,
    our_herd: int,
    our_growth_per_min: float,
    rival_produce: int,
    rival_rate: float,
    rival_herd: int,
    rival_growth_per_min: float = 0.0,
) -> Dict[str, Any]:
    """Minutes until we pass a rival on lifetime produce.

    Returns `eta_min=None` when the projection has no positive root, i.e. no
    amount of waiting wins and something has to change. `deficit_rate` is how
    much produce/min they are currently beating us by (negative = we are ahead
    on rate), which is the actionable half of the answer.
    """
    lead = (rival_produce or 0) - (our_produce or 0)
    our_yield = (our_rate / our_herd) if our_herd else 0.0
    rival_yield = (rival_rate / rival_herd) if rival_herd else 0.0

    # Quadratic: a*t^2 + b*t - lead = 0
    a = 0.5 * (our_yield * max(our_growth_per_min, 0.0)
               - rival_yield * max(rival_growth_per_min, 0.0))
    b = (our_rate or 0.0) - (rival_rate or 0.0)

    out = {
        "lead": lead,               # how far AHEAD the rival is (negative = we lead)
        "deficit_rate": -b,         # produce/min they are gaining on us
        "our_yield": round(our_yield, 4),
        "rival_yield": round(rival_yield, 4),
        "accel": round(a, 4),       # our quadratic edge from out-adopting them
        "eta_min": None,
        "ahead": lead < 0,
    }
    if lead < 0:
        out["eta_min"] = 0.0        # already ahead
        return out

    if abs(a) < 1e-9:
        # No growth edge: purely a race of constant rates.
        out["eta_min"] = (lead / b) if b > 0 else None
        return out

    disc = b * b + 4.0 * a * lead
    if disc < 0 or a <= 0 and b <= 0:
        return out                  # never, on current settings
    root = (-b + math.sqrt(disc)) / (2.0 * a)
    out["eta_min"] = root if root > 0 else None
    return out


def herd_to_out_rate(rival_rate: float, our_yield: float) -> int:
    """Herd size at which we merely MATCH the rival's current produce rate.

    Useful as a floor: below this, the gap is still widening no matter how long
    we run, so adoption throughput - not coins - is the thing to fix.
    """
    if our_yield <= 0:
        return 0
    return int(rival_rate / our_yield)


def affordable_adoptions(coins: int, herd: int, feed_on_hand: int = 0) -> int:
    """How many animals we can adopt and still keep the whole herd fed.

    Every adopted animal costs its price now, plus a feed reserve for itself:

        coins >= n * ANIMAL_COST + reserve_shortfall(herd + n)

    The subtlety is `reserve_shortfall`. The obvious version charges coins for
    the reserve of the ENTIRE herd:

        spendable = coins - FEED_PER_ANIMAL_RESERVE * herd

    which double-counts, because that feed is usually already sitting in the
    barn. At run 379 it reserved 1,905,660 coins to buy feed against a barn that
    already held 2,222,305 - 538 minutes of runway at the measured burn - and so
    reported that only 1,048 more animals were affordable while 1.9M coins sat
    idle. Coins and feed were both treated as if only coins existed.

    Feed already owned is feed we do not have to buy. So the floor is the
    SHORTFALL between the reserve the herd should have and the reserve it does
    have, and everything above that funds growth. New animals are still charged
    their full reserve up front, which keeps the conservative behaviour that
    matters: we never adopt an animal we cannot also feed.

    At run 379 this frees the balance to fund ~48,690 more animals (herd
    ~112,000), which experiments/endgame.py simulates as passing John in 6.4
    hours without ever starving. The old floor capped the herd at ~64,570, which
    the same simulation shows never wins at all.
    """
    cost = ANIMAL_COST[PRIMARY_KIND]
    per_animal = cost + FEED_PER_ANIMAL_RESERVE * FEED_COST
    shortfall = max(0, FEED_PER_ANIMAL_RESERVE * int(herd or 0) - int(feed_on_hand or 0))
    spendable = int(coins or 0) - shortfall * FEED_COST
    if spendable <= 0:
        return 0
    return int(spendable // per_animal)


# --- the hunger wall --------------------------------------------------------
# `feed_animals("all")` is one call whose cost scales with the herd, and past
# ~25,000 animals the gateway gives up (504) before the server finishes the whole
# herd. Feeding therefore covers a shrinking FRACTION of the herd as it grows,
# and the unfed tail's hunger creeps up. Measured across 52 runs with herd above
# 25,000:
#
#     max_hunger = 0.000614 * herd - 7.14
#
#   herd  42,354 -> max hunger 18       herd  66,895 -> max hunger 36
#
# Production stops entirely at HUNGER_STOP, which that line reaches at about
# 125,700 animals. This is the mirror image of the run-291 starvation: not too
# little feed in the barn, but a herd too large to hand it out in time. Adopting
# past this point converts coins into animals that produce nothing and still
# have to be fed.
#
# experiments/expand.py was launched with --target 250000, i.e. twice the wall.
HUNGER_PER_ANIMAL_SLOPE = 0.000614
HUNGER_HERD_INTERCEPT = -7.14


def projected_max_hunger(herd: int) -> float:
    """Expected worst-case hunger at a given herd size, from the measured fit."""
    return HUNGER_PER_ANIMAL_SLOPE * max(0, int(herd or 0)) + HUNGER_HERD_INTERCEPT


def hunger_safe_herd_ceiling(limit: Optional[int] = None) -> int:
    """Largest herd whose worst-case hunger still stays under `limit`.

    Defaults to HUNGER_ALARM rather than HUNGER_STOP: stopping at the alarm keeps
    a whole band of headroom between the biggest herd we will build and the point
    where animals stop producing, which matters because the fit is a projection
    and the tail is what bites first.

    ~119,000 at the measured slope. The endgame plan needs ~112,000 to retake
    first place, so this does not constrain winning - it only stops us from
    adopting past the win into a herd we cannot feed.
    """
    limit = HUNGER_ALARM if limit is None else limit
    if HUNGER_PER_ANIMAL_SLOPE <= 0:
        return 10 ** 9
    return int((limit - HUNGER_HERD_INTERCEPT) / HUNGER_PER_ANIMAL_SLOPE)
