#!/usr/bin/env python3
"""The measured findings, as data rather than as prose.

Everything this project knows about the farm was learned by measurement, and all
of it currently lives in the README - which means it is unreadable from the
dashboard, cannot be recomputed, and quietly goes stale the moment the farm does
something new. This module is the machine-readable version.

Two kinds of entry, deliberately kept apart:

- **derived**: recomputed from `state/history.ndjson` on every request, so the
  herd-vs-output table and the species tallies are whatever the farm has actually
  done up to this minute. If the ceiling ever lifts, these move on their own.
- **recorded**: one-off experiments that cannot be re-derived from history because
  the evidence is the *absence* of a row (crop timers that never advanced, species
  that never produced) or because it predates the current ledger. Each carries the
  run number it was measured at, so it can be checked rather than believed.

Nothing here is on the cycle path: `run.py` never imports it, and a failure can
only cost the dashboard a panel.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from . import rules
except ImportError:  # direct `python3 farm/evidence.py`, useful while designing the tab
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from farm import rules

PROJECT = Path(__file__).resolve().parent.parent
HISTORY = PROJECT / "state" / "history.ndjson"
TOKEN_LEDGER = PROJECT / "state" / "tokens.ndjson"

# Which produce each species is supposed to yield. The point of the table is the
# rows that stay at zero forever.
KIND_PRODUCE = {
    "chicken": "egg",
    "pig": "truffle",
    "beehive": "honey",
    "sheep": "wool",
    "cow": "milk",
}

# Measured over 46 LLM-driven runs on 2026-08-20, before the loop was rewritten in
# Python. The range is real: cost per run depended on how much of `list_farm` the
# model re-read, which grew with the herd.
LLM_ERA = {
    "runs_measured": 46,
    "date": "2026-08-20",
    "input_tokens_low": 150_000,
    "input_tokens_high": 600_000,
    "tool_text_tokens": 62_000,
    "thinking_tokens": 59_000,
    "assistant_turns": 21,
    "cadence_seconds": 300,
    "note": "62k/run of raw tool text and 59k of thinking, re-sent across ~21 turns. "
            "list_farm alone grows ~65 bytes per animal and was read three or four "
            "times per run.",
}

# Public list pricing, the same constants farm/tokens.py bills the exception path
# with, so the counterfactual and the real ledger cannot disagree.
PRICE_PER_MTOK_IN = rules.LLM_INPUT_COST_PER_MTOK
PRICE_PER_MTOK_OUT = rules.LLM_OUTPUT_COST_PER_MTOK


def _history(limit: int = 400) -> List[Dict[str, Any]]:
    try:
        lines = HISTORY.read_text(encoding="utf-8").splitlines()
    except (FileNotFoundError, OSError):
        return []
    rows: List[Dict[str, Any]] = []
    for line in lines[-limit:]:
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def _regression(points: List[tuple]) -> Dict[str, Optional[float]]:
    """Least squares slope of y on x, plus Pearson r. Both or neither."""
    n = len(points)
    if n < 3:
        return {"slope": None, "r": None, "n": n}
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    mx = sum(xs) / n
    my = sum(ys) / n
    sxy = sum((x - mx) * (y - my) for x, y in points)
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx <= 0 or syy <= 0:
        return {"slope": None, "r": None, "n": n}
    slope = sxy / sxx
    r = sxy / ((sxx * syy) ** 0.5)
    return {"slope": round(slope, 5), "r": round(r, 3), "n": n}


def _rate_samples(rows: List[Dict[str, Any]]) -> List[tuple]:
    """(herd, units/min) for every run that can be measured, oldest first.

    `produce_per_min` was only added to the history row at run 58, and the runs
    before it are the entire growth curve - the ones where the herd was still
    changing. Dropping them would leave a "table" with one bucket in it, which
    proves nothing. So earlier runs are measured the way the original analysis was:
    the lifetime-produce delta between consecutive rows over the wall-clock gap.

    Pairs are rejected when the gap is implausible (a stopped scheduler, a clock
    change) or the delta is negative, because a bad pair here becomes a fake
    data point in the argument that stopped adoption.
    """
    from datetime import datetime, timezone

    def when(row: Dict[str, Any]):
        try:
            return datetime.strptime(str(row.get("ts")), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            return None

    samples: List[tuple] = []
    previous: Optional[Dict[str, Any]] = None
    for row in rows:
        herd = row.get("animals")
        if not isinstance(herd, int) or herd <= 0:
            previous = row
            continue
        rate = row.get("produce_per_min")
        if not isinstance(rate, (int, float)):
            rate = None
            if previous is not None:
                start, end = when(previous), when(row)
                before, after = previous.get("produce"), row.get("produce")
                if start and end and isinstance(before, int) and isinstance(after, int):
                    minutes = (end - start).total_seconds() / 60.0
                    if 1.0 <= minutes <= 30.0 and after >= before:
                        rate = (after - before) / minutes
        if isinstance(rate, (int, float)) and rate >= 0:
            samples.append((herd, float(rate)))
        previous = row
    return samples


def ceiling(rows: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Herd size against total output, bucketed - the argument for the growth gate.

    This is the table that stopped adoption. It is bucketed rather than plotted
    per run because output arrives in bursts: single runs read anywhere from 105 to
    2,000 units/min at an unchanged herd size, so a per-run scatter argues for
    whatever you already believed.

    The per-animal column falls across every bucket, which looks like degradation
    and is not: it is a flat numerator over a growing denominator. That reading is
    exactly what made the throughput detector fire every run for a non-incident.
    """
    rows = rows if rows is not None else _history()
    samples = _rate_samples(rows)
    if not samples:
        return {"buckets": [], "regression": {"slope": None, "r": None, "n": 0}, "samples": 0}

    edges = [0, 2000, 4000, 6000, 8000, 10000, 10800, 11500, 10 ** 9]
    buckets = []
    for low, high in zip(edges, edges[1:]):
        inside = [s for s in samples if low <= s[0] < high]
        if not inside:
            continue
        total = sum(s[1] for s in inside) / len(inside)
        herd = sum(s[0] for s in inside) / len(inside)
        buckets.append(
            {
                "label": f"{low:,}-{high:,}" if high < 10 ** 9 else f"{low:,}+",
                "low": low,
                "high": None if high >= 10 ** 9 else high,
                "samples": len(inside),
                "herd": round(herd),
                "units_per_min": round(total, 1),
                "per_animal": round(total / herd, 4) if herd else None,
            }
        )

    # The regression is deliberately limited to the far side of 8,000 animals.
    # Fitting the whole range answers a different question ("does a farm with
    # animals out-produce a farm with none"), which nobody was asking.
    above = [s for s in samples if s[0] >= 8000]
    plateau = sorted(s[1] for s in above)
    below = [s for s in samples if s[0] < 8000]
    return {
        "buckets": buckets,
        "samples": len(samples),
        "regression": _regression(above),
        "regression_from": 8000,
        "regression_below": _regression(below),
        "plateau_median": round(plateau[len(plateau) // 2], 1) if plateau else None,
        "herd_now": samples[-1][0],
        "output_now": round(samples[-1][1], 1),
        "claim": "Production is capped per farm, not per animal. Above 8,000 animals the "
                 "marginal chicken buys no output, while feed climbed from 20% to 40% of revenue.",
    }


def species(rows: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """What each species has ever produced, against how many of it we own.

    The run-50 experiment bought 100 each of pig, sheep, cow and beehive to
    distinguish a per-farm cap from a per-kind one. Had the cap been per kind,
    total produce was pinned near a fifth of the farm's potential - so this was
    the largest open question about the ceiling, and it is answered by two rows
    that never move off zero.
    """
    rows = rows if rows is not None else _history()
    latest_kinds: Dict[str, int] = {}
    for row in rows:
        by_kind = row.get("by_kind")
        if isinstance(by_kind, dict) and by_kind:
            latest_kinds = {str(k): int(v) for k, v in by_kind.items()}
    totals: Dict[str, int] = {}
    for row in rows:
        for produce, units in (row.get("collected") or {}).items():
            try:
                totals[str(produce)] = totals.get(str(produce), 0) + int(units)
            except (TypeError, ValueError):
                continue

    grand = sum(totals.values()) or 1
    table = []
    for kind, produce in KIND_PRODUCE.items():
        owned = latest_kinds.get(kind, 0)
        collected = totals.get(produce, 0)
        share = collected / grand
        if collected == 0:
            verdict = "never produced, ever"
        elif share >= 0.9:
            verdict = "effectively the entire farm"
        elif share >= 0.001:
            verdict = "a rounding error"
        else:
            verdict = "indistinguishable from zero"
        table.append(
            {
                "kind": kind,
                "produce": produce,
                "owned": owned,
                "collected": collected,
                "share": round(share, 6),
                "per_animal": round(collected / owned, 3) if owned else None,
                "verdict": verdict,
            }
        )
    table.sort(key=lambda r: -r["collected"])
    return {
        "table": table,
        "total_collected": grand,
        "runs_observed": len(rows),
        "banned": [r["kind"] for r in table if r["collected"] == 0],
        "claim": "The cap is per farm and already saturated: an animal of any kind added "
                 "past saturation produces nothing. Tested by experiment at run 50, not inferred.",
    }


def crops() -> Dict[str, Any]:
    """A recorded negative result: the timers never advance.

    Cannot be derived from history, because the finding is that nothing ever
    entered it. `plant()` will happily create unlimited plots, so a coin sink that
    never yields would have scaled badly.
    """
    return {
        "run": 50,
        "waited_minutes": 27,
        "plots": [
            {"crop": "wheat", "reading": "0% grown, about 15 min left"},
            {"crop": "corn", "reading": "0% grown, about 20 min left"},
            {"crop": "pumpkin", "reading": "0% grown, about 30 min left"},
        ],
        "claim": "27 minutes after planting, all three plots still read 0% grown. "
                 "The timers never advance, so a plot is a coin sink with no yield.",
    }


def collection() -> Dict[str, Any]:
    """Why 'units collected' is not the score, with the two runs that proved it."""
    return {
        "claim": "Produce accrues as animals produce, not when we collect - so the "
                 "authoritative signal is the leaderboard produce delta per minute.",
        "cases": [
            {
                "run": 25,
                "text": "gained 41,207 lifetime produce while a collect call returned 572 units",
            },
            {
                "run": 50,
                "text": "recorded collected={} and sold 11,597 eggs in the same run - "
                        "collect_produce refuses while any hunger is present, and the "
                        "produce appears in the barn during feed_animals instead",
            },
            {
                "run": 51,
                "text": "same shape again: collected={}, 7,934 eggs sold",
            },
        ],
        "consequence": "The loop's real job is narrower than it looks: keep the herd fed "
                       "and never stall long enough for hunger to reach 70. At saturation, "
                       "collecting, selling and adopting cannot raise the score.",
    }


def detectors() -> Dict[str, Any]:
    """The two detectors that were firing almost every run for non-incidents.

    Worth its own panel because the fix removed most of the LLM spend, and because
    both were wrong in the same way: a ratio read without the context that makes it
    mean something.
    """
    return [
        {
            "name": "throughput",
            "was": "units/chicken/min below a fixed band",
            "why_wrong": "the denominator grows while a per-farm cap holds the numerator "
                         "flat, so the ratio falls on a perfectly healthy farm",
            "fix": "consult the backlog: a low reading is only an incident if produce is "
                   "piling up",
            "evidence": "runs 27-29 collected 62-760 units but ended with only 666-3,303 "
                        "ready - the herd was drained, not broken",
        },
        {
            "name": "transport retries",
            "was": "any retry rate above a percentage threshold",
            "why_wrong": "one retry in a 35-call run is 2.9% and reads as an incident",
            "fix": "a call-volume floor, with rules.transport_trouble as the single "
                   "definition shared by the detector and the cycle's rate recovery",
            "evidence": "it also convinced the cycle the previous run was unclean, which "
                        "pinned the rate limiter at its 0.5/s floor for runs on end",
        },
        {
            "name": "production stall",
            "was": "one low produce/min window",
            "why_wrong": "produce arrives in bursts; replaying all 56 runs of history, runs "
                         "40, 46 and 55 each read 105-246/min immediately before a "
                         "1,600-2,000/min window",
            "fix": "require two consecutive low windows, scaled per animal",
            "evidence": "one window would have woken a model three times for nothing; two "
                        "windows fires on none of them and still catches a real stall one "
                        "cycle (~4 min) later",
        },
    ]


def timeline() -> List[Dict[str, Any]]:
    """The findings in the order they were learned, each with its run number."""
    return [
        {"run": 2, "kind": "correction", "title": "Production is per-animal, not a global tick",
         "text": "980 units appeared 2.5 minutes after a collection that returned nothing, "
                 "so the loop never aligns to a tick and measures units/chicken/minute over "
                 "the real interval."},
        {"run": 25, "kind": "correction", "title": "Collected units are not the score",
         "text": "41,207 lifetime produce arrived while a collect call returned 572 units."},
        {"run": 29, "kind": "detector", "title": "Throughput alarms were arithmetic, not incidents",
         "text": "A falling per-chicken figure is a flat numerator over a growing denominator."},
        {"run": 46, "kind": "policy", "title": "Growth gated on evidence",
         "text": "Adoptions 25 -> 0, server calls 30 -> 8, throughput back inside the band, "
                 "rank unchanged at #1. The last ~3,400 chickens produced nothing while feed "
                 "climbed from 20% to 40% of revenue."},
        {"run": 50, "kind": "experiment", "title": "The cap is per farm, not per kind",
         "text": "100 each of pig, sheep, cow and beehive for 9,517 coins. Six runs later: "
                 "0 wool, 0 milk, and pigs and hives unchanged. Total output stayed ~1,550/min."},
        {"run": 50, "kind": "experiment", "title": "Crops are a coin sink",
         "text": "Wheat, corn and pumpkin all still read 0% grown 27 minutes after planting."},
        {"run": 51, "kind": "correction", "title": "collect_produce lies while the herd is hungry",
         "text": "collected={} and 7,934 eggs sold in the same run. The produce banks during "
                 "the feed call."},
        {"run": 56, "kind": "detector", "title": "Stalls need two windows, not one",
         "text": "Replaying every run of history, a single-window rule would have woken a "
                 "model three times for nothing."},
    ]


def _token_rows(limit: int = 5000) -> List[Dict[str, Any]]:
    """Read the full cost ledger with the same corrupt-tail tolerance as history."""
    try:
        lines = TOKEN_LEDGER.read_text(encoding="utf-8").splitlines()
    except (FileNotFoundError, OSError):
        return []
    out: List[Dict[str, Any]] = []
    for line in lines[-limit:]:
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            out.append(value)
    return out


def cost_history() -> Dict[str, Any]:
    """Actual Python-era ledger against the measured LLM-era counterfactual.

    The ledger began with deterministic execution, so it would be dishonest to
    draw the old model spend as actual ledger rows. Instead every Python run has
    two series:

    * actual: exactly what state/tokens.ndjson booked;
    * counterfactual: what that same number of cycles would have cost at the
      measured old-loop low/mid/high token load.

    This makes the visual claim strong without manufacturing historical precision
    that does not exist. If a future alert wakes a model, the green actual line
    will move automatically.
    """
    rows = _token_rows()
    per_run: Dict[int, Dict[str, Any]] = {}
    for row in rows:
        run = row.get("run")
        if run is None:
            continue
        try:
            number = int(run)
        except (TypeError, ValueError):
            continue
        bucket = per_run.setdefault(
            number,
            {
                "run": number,
                "ts": row.get("ts"),
                "tokens": 0,
                "tokens_in": 0,
                "tokens_out": 0,
                "cost_usd": 0.0,
                "healed": 0,
                "escalations": 0,
                "kinds": [],
            },
        )
        bucket["ts"] = row.get("ts") or bucket["ts"]
        bucket["tokens"] += int(row.get("tokens") or 0)
        bucket["tokens_in"] += int(row.get("tokens_in") or 0)
        bucket["tokens_out"] += int(row.get("tokens_out") or 0)
        bucket["cost_usd"] += float(row.get("cost_usd") or 0.0)
        bucket["healed"] += int(row.get("healed") or 0)
        bucket["escalations"] += 1 if row.get("escalated") else 0
        if row.get("kind"):
            bucket["kinds"].append(str(row["kind"]))

    input_low = int(LLM_ERA["input_tokens_low"])
    input_high = int(LLM_ERA["input_tokens_high"])
    input_mid = round((input_low + input_high) / 2)
    output = int(LLM_ERA["thinking_tokens"])
    token_low, token_mid, token_high = input_low + output, input_mid + output, input_high + output
    cost_low = input_low / 1_000_000 * PRICE_PER_MTOK_IN + output / 1_000_000 * PRICE_PER_MTOK_OUT
    cost_mid = input_mid / 1_000_000 * PRICE_PER_MTOK_IN + output / 1_000_000 * PRICE_PER_MTOK_OUT
    cost_high = input_high / 1_000_000 * PRICE_PER_MTOK_IN + output / 1_000_000 * PRICE_PER_MTOK_OUT

    points: List[Dict[str, Any]] = []
    actual_tokens = 0
    actual_cost = 0.0
    healed = 0
    escalations = 0
    for index, run in enumerate(sorted(per_run), start=1):
        row = per_run[run]
        actual_tokens += int(row["tokens"])
        actual_cost += float(row["cost_usd"])
        healed += int(row["healed"])
        escalations += int(row["escalations"])
        points.append(
            {
                "run": run,
                "ts": row["ts"],
                "actual_tokens": int(row["tokens"]),
                "actual_cost": round(float(row["cost_usd"]), 6),
                "healed": int(row["healed"]),
                "escalations": int(row["escalations"]),
                "kinds": sorted(set(row["kinds"])),
                "cumulative_actual_tokens": actual_tokens,
                "cumulative_actual_cost": round(actual_cost, 6),
                "cumulative_healed": healed,
                "cumulative_escalations": escalations,
                "counterfactual_tokens_low": token_low * index,
                "counterfactual_tokens_mid": token_mid * index,
                "counterfactual_tokens_high": token_high * index,
                "counterfactual_cost_low": round(cost_low * index, 3),
                "counterfactual_cost_mid": round(cost_mid * index, 3),
                "counterfactual_cost_high": round(cost_high * index, 3),
            }
        )

    count = len(points)
    zero_runs = sum(1 for row in per_run.values() if not row["tokens"] and not row["cost_usd"])
    charged_runs = count - zero_runs
    month_runs = round(86_400 / int(LLM_ERA["cadence_seconds"]) * 30)
    midpoint_input_other = max(0, input_mid - int(LLM_ERA["tool_text_tokens"]))
    return {
        "points": points,
        "stats": {
            "ledger_runs": count,
            "first_run": points[0]["run"] if points else None,
            "last_run": points[-1]["run"] if points else None,
            "zero_runs": zero_runs,
            "charged_runs": charged_runs,
            "actual_tokens": actual_tokens,
            "actual_cost": round(actual_cost, 6),
            "healed": healed,
            "escalations": escalations,
            "healing_cost_avoided": round(healed * rules.escalation_cost(200)[2], 6),
            "counterfactual_tokens_mid": token_mid * count,
            "counterfactual_cost_low": round(cost_low * count, 2),
            "counterfactual_cost_mid": round(cost_mid * count, 2),
            "counterfactual_cost_high": round(cost_high * count, 2),
            "reduction_pct": round((1 - actual_cost / (cost_mid * count)) * 100, 3)
                             if count and cost_mid else None,
            "old_monthly_cost_low": round(cost_low * month_runs),
            "old_monthly_cost_mid": round(cost_mid * month_runs),
            "old_monthly_cost_high": round(cost_high * month_runs),
        },
        "per_run_assumption": {
            "input_tokens_low": input_low,
            "input_tokens_mid": input_mid,
            "input_tokens_high": input_high,
            "thinking_output_tokens": output,
            "tokens_low": token_low,
            "tokens_mid": token_mid,
            "tokens_high": token_high,
            "cost_low": round(cost_low, 3),
            "cost_mid": round(cost_mid, 3),
            "cost_high": round(cost_high, 3),
            "source": "46 measured LLM-driven runs on 2026-08-20",
        },
        "token_sources": [
            {"name": "repeated prompt + context", "tokens": midpoint_input_other,
             "note": "farm state and instructions re-sent across ~21 turns"},
            {"name": "raw tool text", "tokens": int(LLM_ERA["tool_text_tokens"]),
             "note": "including list_farm, which grows with every animal"},
            {"name": "thinking / output", "tokens": output,
             "note": "reasoning over thresholds now encoded directly in rules.py"},
        ],
        "changes": [
            {
                "era": "LLM-driven execution",
                "when": "2026-08-20 · 46 measured runs",
                "icon": "🧠",
                "kind": "before",
                "change": "A model re-read the farm, reasoned over the same thresholds, and drove every tool call every five minutes.",
                "impact": f"{input_low // 1000}k-{input_high // 1000}k billed input tokens per cycle; about ${cost_low:.2f}-${cost_high:.2f} including measured thinking/output.",
                "code": "prompt + repeated list_farm",
            },
            {
                "era": "Deterministic Python cycle",
                "when": "Python cutover · ledger begins at run 32",
                "icon": "🐍",
                "kind": "cutover",
                "change": "MCP transport, strict parsing, prices, reserves, budgets and the full action plan moved into small testable Python modules.",
                "impact": "Routine execution dropped to an explicit 0 tokens per cycle; cadence improved from 300s to 180s without increasing model spend.",
                "code": "mcp.py → parse.py → rules.py → cycle.py",
            },
            {
                "era": "Exception-only intelligence",
                "when": "watch.py + compact --alerts",
                "icon": "🔎",
                "kind": "python",
                "change": "The model stopped supervising normal runs. Deterministic detectors now decide whether anything deserves attention.",
                "impact": "The full farm state never enters a prompt during healthy operation; only a compact surviving alert can wake a model.",
                "code": "watch.py → journal.py → --alerts",
            },
            {
                "era": "Self-healing supervisor",
                "when": "first measured remedies · runs 32-33",
                "icon": "🛠️",
                "kind": "python",
                "change": "Transport, backpressure and feed-reserve failures gained bounded Python remedies before escalation.",
                "impact": f"{healed} alerts healed in the current ledger with {escalations} model wake-ups.",
                "code": "heal.py + 60s supervisor",
            },
            {
                "era": "Evidence-gated growth",
                "when": "run 46",
                "icon": "📉",
                "kind": "python",
                "change": "Adoption stopped when a larger herd failed to buy at least 10% more output.",
                "impact": "Adoptions fell 25 → 0 and server calls 30 → 8 while rank remained #1; state stopped growing for no return.",
                "code": "growth.py + rules.adoption_cap",
            },
            {
                "era": "Auditable cost, not a claim",
                "when": f"runs {points[0]['run'] if points else '—'}-{points[-1]['run'] if points else '—'}",
                "icon": "🧾",
                "kind": "proof",
                "change": "Every deterministic cycle and every remedy writes a ledger row, including zeros.",
                "impact": f"{zero_runs}/{count} Python-era runs at $0; any future escalation will move the actual line automatically.",
                "code": "tokens.py → state/tokens.ndjson",
            },
        ],
        "disclosure": "The green actual series is the ledger. The amber counterfactual is a range derived from "
                      "46 measured pre-Python runs, not reconstructed invoices. Thinking tokens are priced at "
                      "the configured output rate; billed input uses the measured 150k-600k range.",
    }


def cost_model(rows: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Inputs for the counterfactual: what the old loop would cost at this cadence.

    The front end multiplies these out against a runs-per-day slider, because the
    interesting number is not one run's price - it is what a 5-minute cadence
    compounds to over a month, which is the whole reason the strategy moved into
    `rules.py`.
    """
    rows = rows if rows is not None else _history()
    return {
        "llm_era": LLM_ERA,
        "now": {
            "cadence_seconds": 180,
            "input_tokens": 0,
            "runs_recorded": len(rows),
            "note": "Every cycle writes an explicit zero to state/tokens.ndjson. The only "
                    "rows with a cost are LLM wake-ups, booked when --alerts prints.",
        },
        "price_per_mtok_in": PRICE_PER_MTOK_IN,
        "price_per_mtok_out": PRICE_PER_MTOK_OUT,
        "claim": "The strategy is arithmetic against fixed thresholds, so it lives in "
                 "farm/rules.py and runs for free. Nothing about the reasoning was necessary.",
    }


def report() -> Dict[str, Any]:
    """Everything, for one cached fetch by the dashboard.

    Served from its own endpoint rather than folded into /api/state: the state poll
    runs every 2 seconds and none of this changes at that rate.
    """
    rows = _history()
    return {
        "ceiling": ceiling(rows),
        "species": species(rows),
        "crops": crops(),
        "collection": collection(),
        "detectors": detectors(),
        "timeline": timeline(),
        "cost": cost_model(rows),
        "cost_history": cost_history(),
    }


if __name__ == "__main__":
    print(json.dumps(report(), indent=1, sort_keys=True))
