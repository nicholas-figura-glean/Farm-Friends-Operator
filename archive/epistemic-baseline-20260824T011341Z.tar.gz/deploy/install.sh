#!/bin/bash
# Install (or reinstall) the Farm Friends agents as launchd user agents:
#   com.nickfigura.farmfriends            the 180s cycle
#   com.nickfigura.farmfriends.supervisor the 60s self-healing pass
#   com.nickfigura.farmfriends.expand     the 300s bounded expansion sprint
# Each agent repairs the other, so the loop survives one of them being stopped.
# Usage: deploy/install.sh [--uninstall]
set -euo pipefail

LABEL="com.nickfigura.farmfriends"
SUPERVISOR="$LABEL.supervisor"
EXPAND="$LABEL.expand"
PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
AGENT_DIR="$HOME/Library/LaunchAgents"
PLIST="$AGENT_DIR/$LABEL.plist"
SUPERVISOR_PLIST="$AGENT_DIR/$SUPERVISOR.plist"
EXPAND_PLIST="$AGENT_DIR/$EXPAND.plist"
DOMAIN="gui/$(id -u)"

if [[ "${1:-}" == "--uninstall" ]]; then
  # Bootout the supervisor FIRST: otherwise it would notice the cycle agent
  # disappearing and dutifully reinstall it.
  launchctl bootout "$DOMAIN/$SUPERVISOR" 2>/dev/null || true
  launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || true
  launchctl bootout "$DOMAIN/$EXPAND" 2>/dev/null || true
  rm -f "$PLIST" "$SUPERVISOR_PLIST" "$EXPAND_PLIST"
  echo "uninstalled $LABEL, $SUPERVISOR and $EXPAND"
  exit 0
fi

# Fail fast if the operator itself is broken, then publish a release for
# launchd to execute (never the working tree).
/usr/bin/python3 "$PROJECT/run.py" --self-test
"$PROJECT/deploy/release.sh"

mkdir -p "$AGENT_DIR" "$PROJECT/state"
for label in "$LABEL" "$SUPERVISOR" "$EXPAND"; do
  sed "s|__PROJECT__|$PROJECT|g" "$PROJECT/deploy/$label.plist" > "$AGENT_DIR/$label.plist"
  plutil -lint "$AGENT_DIR/$label.plist"
  launchctl bootout "$DOMAIN/$label" 2>/dev/null || true
  launchctl bootstrap "$DOMAIN" "$AGENT_DIR/$label.plist"
  launchctl enable "$DOMAIN/$label"
done

echo "installed $LABEL -> every 180s from $PROJECT/release"
echo "installed $SUPERVISOR -> every 60s (self-healing)"
echo "installed $EXPAND -> every 300s (bounded 240s adoption sprint)"
launchctl print "$DOMAIN/$LABEL" | sed -n '1,6p;/state =/p;/runs =/p'
