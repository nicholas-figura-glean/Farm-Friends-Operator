#!/usr/bin/env python3
"""Regression checks for the machine-readable farm findings.

The Findings tab is only useful if it cannot quietly drift into a better story
than the ledger supports. These tests assert the shape of the argument, not exact
rates (which move every time a run is appended): early growth is positive, the
slope flattens after 8k, zero-output species stay explicit, and the whole report
is JSON transport-safe.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

from farm import evidence  # noqa: E402


checks = []
failures = []


def ok(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, bool(condition), detail))
    if not condition:
        failures.append(name + (f" [{detail}]" if detail else ""))


def main() -> int:
    rows = evidence._history()  # the derivation input, intentionally exercised
    samples = evidence._rate_samples(rows)
    report = evidence.report()
    ceiling = report["ceiling"]

    ok("history exists", len(rows) >= 50, f"{len(rows)} rows")
    ok("pre-rate rows are reconstructed", any(herd < 1_000 for herd, _ in samples),
       f"minimum measured herd {min((h for h, _ in samples), default='none')}")
    ok("the ceiling covers the growth curve", len(ceiling["buckets"]) >= 6,
       f"{len(ceiling['buckets'])} buckets")
    ok("early herd had a positive slope", (ceiling["regression_below"]["slope"] or 0) > 0,
       str(ceiling["regression_below"]))
    below = abs(ceiling["regression_below"]["slope"] or 0)
    above = abs(ceiling["regression"]["slope"] or 0)
    # This assertion used to read `above < below * 0.35`: it encoded the plateau
    # hypothesis that justified the growth gate, froze the herd for 246 runs and
    # lost first place. With 355 samples spanning 648 to 58,000 animals the slope
    # above 8k is 0.178 (r=0.908) against 0.199 below it - the same number, not a
    # collapse. Output is linear in herd size, so the honest test is that the
    # marginal animal still pays and the two regimes agree.
    #
    # The per-animal column still falls, for the reason evidence.ceiling's
    # docstring gives: it is a flat COLLECTED numerator over a growing herd, and
    # collected units are capped by a whole-herd call that now always times out.
    # Lifetime produce - the score - never stopped scaling.
    ok("the marginal animal still pays above 8k", above > 0.05,
       f"slope above 8k = {above:.5f} produce/min per animal")
    ok("no plateau: the two regimes agree within a factor of two",
       below > 0 and 0.5 <= above / below <= 2.0,
       f"below={below:.5f}, above={above:.5f}, ratio={above/below:.3f}" if below else "below=0")
    ok("the linear fit above 8k is strong", (ceiling["regression"].get("r") or 0) > 0.8,
       str(ceiling["regression"]))
    ok("plateau is still around the measured band",
       1_000 <= (ceiling["plateau_median"] or 0) <= 2_200,
       str(ceiling["plateau_median"]))

    species = {row["kind"]: row for row in report["species"]["table"]}
    ok("all five species are represented", set(species) == set(evidence.KIND_PRODUCE),
       ",".join(sorted(species)))
    # These asserted `collected == 0` literally. Sheep and cows have since
    # collected 235 and 329 units across hundreds of runs, which is not a change
    # of finding - their share of output is 0.015% and 0.02% off 100 animals
    # each, still indistinguishable from zero next to chickens. Test the verdict
    # the evidence reaches, not a snapshot that ages into a false alarm.
    ok("sheep remain indistinguishable from zero",
       species["sheep"]["share"] < 0.01, str(species["sheep"]))
    ok("cows remain indistinguishable from zero",
       species["cow"]["share"] < 0.01, str(species["cow"]))
    ok("chickens dominate measured output", species["chicken"]["share"] > 0.99,
       f"share={species['chicken']['share']}")

    ok("crop negative result names all probes", len(report["crops"]["plots"]) == 3)
    ok("crop probe waited beyond the shortest timer", report["crops"]["waited_minutes"] > 15)
    ok("collection correction carries multiple reproductions",
       len(report["collection"]["cases"]) >= 3)
    ok("detector fixes are concrete", all(d.get("was") and d.get("fix") and d.get("evidence")
                                           for d in report["detectors"]))
    ok("timeline is chronological",
       [x["run"] for x in report["timeline"]] == sorted(x["run"] for x in report["timeline"]))

    cost = report["cost"]
    history = report["cost_history"]
    hstats = history["stats"]
    ok("cost history covers the audited Python era", hstats["ledger_runs"] >= 100,
       f"{hstats['ledger_runs']} runs")
    ok("zero and charged classifications cover every run",
       hstats["zero_runs"] + hstats["charged_runs"] == hstats["ledger_runs"])
    ok("cost history is ordered by run",
       [p["run"] for p in history["points"]] == sorted(p["run"] for p in history["points"]))
    ok("counterfactual range preserves uncertainty",
       hstats["counterfactual_cost_low"] < hstats["counterfactual_cost_mid"]
       < hstats["counterfactual_cost_high"], str(hstats))
    ok("actual cost never exceeds the old-loop midpoint",
       hstats["actual_cost"] <= hstats["counterfactual_cost_mid"])
    ok("cost history names the deterministic cutover",
       any(c["era"] == "Deterministic Python cycle" for c in history["changes"]))
    ok("token composition adds to the midpoint",
       sum(s["tokens"] for s in history["token_sources"])
       == history["per_run_assumption"]["tokens_mid"])
    ok("old loop range is measured, not a point guess",
       cost["llm_era"]["input_tokens_high"] > cost["llm_era"]["input_tokens_low"] > 0)
    ok("routine loop has zero token input", cost["now"]["input_tokens"] == 0)
    try:
        encoded = json.dumps(report, separators=(",", ":"), allow_nan=False)
        transport_safe = len(encoded) > 1_000
    except (TypeError, ValueError) as exc:
        transport_safe = False
        encoded = str(exc)
    ok("the API report is strict JSON", transport_safe, f"{len(encoded)} bytes")

    for name, passed, detail in checks:
        suffix = f"  [{detail}]" if detail and not passed else ""
        print(f"  {'ok' if passed else 'FAIL':4} {name}{suffix}")
    print()
    if failures:
        print(f"EVIDENCE TEST FAILED: {len(failures)} of {len(checks)} checks")
        for failure in failures:
            print(f"  - {failure}")
        return 1
    print(f"EVIDENCE TEST PASSED: {len(checks)} checks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
