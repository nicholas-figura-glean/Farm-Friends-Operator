#!/usr/bin/env python3
"""Read-only local Farm Friends monitor.

Run with: python3 monitor.py
The monitor only reads state files and launchd metadata. It never calls the
farm API and has no controls that can mutate the farm.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import urlparse

PROJECT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT))

# Reuse the operator's own modules so the dashboard can never disagree with the
# loop about knobs, cost, or which agents are supposed to exist.
from farm import evidence, growth, heal, progress, release as release_info, scheduler, tokens, topology  # noqa: E402

STATE = PROJECT / "state"
HISTORY = STATE / "history.ndjson"
INTENTS = STATE / "intents.ndjson"
TOOL_CALLS = STATE / "tool_calls.ndjson"
ALERTS = STATE / "alerts.ndjson"
LOG = STATE / "launchd.log"
LABEL = "com.nickfigura.farmfriends"
APP_ID = "farmfriends-monitor"   # identity marker in /api/state, so a launcher can
                                # tell our dashboard from anything else on the port
DEFAULT_PORT = 8765
PORT_SEARCH = 10                 # how far past the requested port to look
CADENCE_SECONDS = 180


def _json_lines(path: Path, limit: int = 100) -> List[Dict[str, Any]]:
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except (FileNotFoundError, OSError):
        return []
    rows: List[Dict[str, Any]] = []
    for line in lines[-limit:]:
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict):
            rows.append(value)
    return rows


def _timestamp(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _age_seconds(value: Optional[str]) -> Optional[int]:
    parsed = _timestamp(value)
    if not parsed:
        return None
    return max(0, int((datetime.now(timezone.utc) - parsed).total_seconds()))


def _launchd() -> Dict[str, Any]:
    """Status of both agents, via the operator's own scheduler module."""
    try:
        cycle_agent = scheduler.status(scheduler.CYCLE_LABEL)
        supervisor = scheduler.status(scheduler.SUPERVISOR_LABEL)
    except Exception as exc:  # noqa: BLE001
        return {"loaded": False, "state": "unknown", "detail": str(exc)[:120], "supervisor": {}}
    cycle_agent["supervisor"] = supervisor
    return cycle_agent


def _match(text: str, pattern: str) -> Optional[str]:
    found = re.search(pattern, text, re.MULTILINE)
    return found.group(1) if found else None


def _current_intent(intents: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Infer the current stage from start/done intent pairs."""
    active: Dict[str, Dict[str, Any]] = {}
    latest: Optional[Dict[str, Any]] = None
    for item in intents:
        action = str(item.get("action", ""))
        latest = item
        if action.endswith("_start"):
            active[action[:-6]] = item
        elif action.endswith("_done"):
            active.pop(action[:-5], None)
    if active:
        key, item = next(reversed(active.items()))
        return {
            "active": True,
            "stage": key.replace("_", " "),
            "ts": item.get("ts"),
            "detail": item.get("detail") or {},
        }
    return {
        "active": False,
        "stage": "idle",
        "ts": latest.get("ts") if latest else None,
        "detail": latest.get("detail") if latest else {},
    }


def _log_tail(limit: int = 12) -> List[str]:
    try:
        return LOG.read_text(encoding="utf-8").splitlines()[-limit:]
    except (FileNotFoundError, OSError):
        return []


def _blockers(
    latest: Dict[str, Any],
    launchd: Dict[str, Any],
    current: Dict[str, Any],
    release: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, str]]:
    blockers: List[Dict[str, str]] = []
    anomalies = latest.get("anomalies") or []
    for anomaly in anomalies:
        blockers.append({"level": "error", "text": str(anomaly)})

    # Not a farm failure, but the dashboard would otherwise show numbers computed
    # by rules the live loop is not running yet.
    if (release or {}).get("diverged"):
        blockers.append(
            {
                "level": "warn",
                "text": "Working tree differs from the live release "
                        f"({release.get('revision')}) - these panels use unreleased "
                        "rules until deploy/release.sh publishes them",
            }
        )

    feed = latest.get("feed")
    reserve = latest.get("reserve_target")
    if feed is not None and reserve is not None and feed < reserve:
        blockers.append({"level": "error", "text": f"Feed below reserve: {feed:,} / {reserve:,}"})

    if latest.get("rank") not in (None, 1):
        blockers.append({"level": "error", "text": f"Leaderboard position is #{latest.get('rank')}"})

    age = _age_seconds(latest.get("ts"))
    if age is None:
        blockers.append({"level": "error", "text": "No completed farm run recorded"})
    elif age > CADENCE_SECONDS * 2 and not current.get("active"):
        blockers.append({"level": "error", "text": f"Last completed run is {age // 60}m old"})

    if not launchd.get("loaded"):
        blockers.append({"level": "error", "text": "launchd cycle agent is not loaded"})
    if not (launchd.get("supervisor") or {}).get("loaded"):
        blockers.append(
            {"level": "error", "text": "supervisor agent is not loaded - no self-healing"}
        )

    if not blockers:
        blockers.append({"level": "ok", "text": "No active blockers"})
    return blockers


def snapshot() -> Dict[str, Any]:
    history = _json_lines(HISTORY, 100)
    intents = _json_lines(INTENTS, 80)
    latest = history[-1] if history else {}
    previous = history[-2] if len(history) > 1 else {}
    launchd = _launchd()
    current = _current_intent(intents)
    release = _release_info()
    age = _age_seconds(latest.get("ts"))
    if current["active"]:
        health = "running"
    elif not launchd["loaded"]:
        health = "offline"
    elif age is not None and age <= CADENCE_SECONDS * 2:
        health = "healthy"
    else:
        health = "stale"

    rivals = latest.get("rivals") or {}
    rival_rows = []
    previous_rivals = previous.get("rivals") or {}
    for name, produce in sorted(rivals.items(), key=lambda pair: (-pair[1], pair[0].lower())):
        rival_rows.append(
            {
                "name": name,
                "produce": produce,
                "delta": produce - previous_rivals.get(name, produce),
                "gap": (latest.get("produce") or 0) - produce,
            }
        )

    return {
        "app": APP_ID,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "health": health,
        "cadence_seconds": CADENCE_SECONDS,
        "latest": latest,
        "trend": history[-20:],
        "leaderboard": rival_rows,
        "current": current,
        "launchd": launchd,
        "blockers": _blockers(latest, launchd, current, release),
        "log_tail": _log_tail(),
        "release": release,
        "tokens": _tokens_summary(),
        "heal": _heal_summary(),
        "pipeline": _pipeline(),
        "trace": _trace(),
        "growth": _growth_summary(),
        "cost": _cost_detail(history),
        "signals": _signals(latest, previous),
        "scene": _scene(latest, previous),
    }


def _scene(latest: Dict[str, Any], previous: Dict[str, Any]) -> Dict[str, Any]:
    """Numbers the farm view draws itself from, normalised to 0..1 where it helps.

    The panel is a picture, but it is a picture of measurements: every element on
    it is one of these fields and nothing on it is decorative. Doing the
    normalisation here rather than in JavaScript keeps the thresholds next to the
    rules that define them - a silo that looks full at 80% of a reserve target the
    loop has since changed would be a lie told in CSS.
    """
    from farm import rules

    by_kind = latest.get("by_kind") or {}
    feed = latest.get("feed")
    reserve = latest.get("reserve_target")
    hunger = latest.get("max_hunger")
    ready = latest.get("ready_units")
    produce = latest.get("produce")
    before = previous.get("produce") if previous else None
    return {
        "animals": latest.get("animals"),
        "by_kind": by_kind,
        # The species that were measured to produce nothing, so the scene can show
        # them standing idle instead of implying they contribute.
        "idle_kinds": [k for k in evidence.species().get("banned", []) if k in by_kind],
        "feed": feed,
        "reserve_target": reserve,
        "feed_fill": None if not reserve else max(0.0, min(1.0, (feed or 0) / reserve)),
        "hunger": hunger,
        "hunger_stop": rules.HUNGER_STOP,
        "hunger_fill": None if hunger is None else max(0.0, min(1.0, hunger / rules.HUNGER_STOP)),
        "ready_units": ready,
        "coins": latest.get("coins"),
        "rank": latest.get("rank"),
        "produce": produce,
        # Produce per second, for interpolating the counter between polls. The
        # rate is measured over the real interval, not assumed from the cadence.
        "produce_per_sec": (round(latest["produce_per_min"] / 60.0, 3)
                            if isinstance(latest.get("produce_per_min"), (int, float)) else None),
        "produce_delta": (produce - before) if isinstance(produce, int) and isinstance(before, int) else None,
        "ts": latest.get("ts"),
        "fed": latest.get("fed"),
        "harvested": latest.get("harvested"),
        "revenue": latest.get("revenue"),
        "feed_share": latest.get("feed_share"),
    }


def _cost_detail(history: List[Dict[str, Any]], recent: int = 5) -> Dict[str, Any]:
    """Per-run LLM spend, plus what the healer did instead of spending it.

    The ledger is the point of this panel: routine runs write an explicit zero, so
    "it costs nothing" is a measurement rather than a claim. A row only carries a
    cost when an alert survived healing and woke a model.
    """
    try:
        ledger = tokens.tail(400)
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120], "runs": []}

    by_run: Dict[int, Dict[str, Any]] = {}
    for row in ledger:
        run = row.get("run")
        if run is None:
            continue
        entry = by_run.setdefault(
            int(run),
            {"run": int(run), "tokens": 0, "tokens_in": 0, "tokens_out": 0,
             "cost_usd": 0.0, "escalations": 0, "healed": 0, "ts": row.get("ts"),
             "kinds": [], "notes": []},
        )
        entry["tokens"] += int(row.get("tokens") or 0)
        entry["tokens_in"] += int(row.get("tokens_in") or 0)
        entry["tokens_out"] += int(row.get("tokens_out") or 0)
        entry["cost_usd"] += float(row.get("cost_usd") or 0.0)
        entry["escalations"] += 1 if row.get("escalated") else 0
        entry["healed"] += int(row.get("healed") or 0)
        entry["ts"] = row.get("ts") or entry["ts"]
        if row.get("kind"):
            entry["kinds"].append(str(row["kind"]))
        if row.get("note"):
            entry["notes"].append(str(row["note"]))

    # Alerts recorded per run give the "why" behind any non-zero row, and show
    # what was raised even on runs the healer settled for free.
    raised: Dict[int, List[str]] = {}
    for row in _json_lines(ALERTS, 200):
        run = row.get("run")
        if run is None:
            continue
        raised.setdefault(int(run), []).append(str(row.get("alert") or ""))

    runs = sorted(by_run)[-recent:]
    recent_rows = []
    for run in runs:
        entry = dict(by_run[run])
        entry["cost_usd"] = round(entry["cost_usd"], 6)
        entry["kinds"] = sorted(set(entry["kinds"]))
        entry["alerts"] = raised.get(run, [])
        recent_rows.append(entry)

    charged = [r for r in by_run.values() if r["cost_usd"] > 0]
    return {
        "runs": recent_rows[::-1],
        "recent_window": len(recent_rows),
        "recent_cost_usd": round(sum(r["cost_usd"] for r in recent_rows), 6),
        "recent_tokens": sum(r["tokens"] for r in recent_rows),
        "ledger_runs": len(by_run),
        "charged_runs": len(charged),
        "free_runs": len(by_run) - len(charged),
        "first_ts": (ledger[0].get("ts") if ledger else None),
    }


def _signals(latest: Dict[str, Any], previous: Dict[str, Any]) -> Dict[str, Any]:
    """The measures the loop actually judges itself by, for the pipeline tab.

    Score rate leads deliberately: lifetime produce accrues as animals produce,
    while collect_produce returns nothing whenever the herd is hungry (the produce
    banks during the feed call instead). Collection counts are therefore a lagging
    proxy, and a run can bank thousands of eggs while recording collected={}.
    """
    from farm import rules  # local import keeps the module list in one place

    rate = latest.get("produce_per_min")
    if rate is None and previous and latest.get("produce") and previous.get("produce"):
        minutes = latest.get("interval_min") or 0
        if minutes:
            rate = round((latest["produce"] - previous["produce"]) / minutes, 1)
    animals = latest.get("animals")
    floor = rules.produce_floor(animals)
    prev_rate = previous.get("produce_per_min") if previous else None
    return {
        "produce_per_min": rate,
        "floor": round(floor, 1),
        "prev_produce_per_min": prev_rate,
        "below_floor": rate is not None and rate < floor,
        "prev_below_floor": prev_rate is not None and prev_rate < floor,
        "hunger": latest.get("max_hunger"),
        "hunger_stop": rules.HUNGER_STOP,
        "hunger_alarm": rules.HUNGER_ALARM,
        "feed": latest.get("feed"),
        "reserve_target": latest.get("reserve_target"),
        "units_collected": latest.get("units_collected"),
        "soft": latest.get("notes_soft") or [],
        "calls": latest.get("calls"),
        "call_rate": latest.get("call_rate"),
    }


def _growth_summary() -> Dict[str, Any]:
    try:
        return growth.status()
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120]}


def _pipeline() -> Dict[str, Any]:
    try:
        data = progress.read()
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120], "steps": []}
    # Median duration per step across recent runs gives each bar a baseline to
    # compare against, which is what makes a slow step obvious at a glance.
    history = _json_lines(HISTORY, 30)
    samples: Dict[str, List[float]] = {}
    for row in history[-12:]:
        for name, seconds in (row.get("phases") or {}).items():
            samples.setdefault(name, []).append(float(seconds))
    baseline = {}
    for name, values in samples.items():
        values.sort()
        baseline[name] = round(values[len(values) // 2], 1)
    data["baseline"] = baseline
    return data


# Before full boundary tracing was added to farm/mcp.py, selected mutations were
# recorded as intent start/end pairs. They remain the fallback for releases that
# predate state/tool_calls.ndjson; the UI labels that coverage "mutations only"
# instead of implying that read-only calls were observed.
INTENT_TOOLS = {
    "sell": ("sell", "sell"),
    "buy_feed": ("buy_feed", "buy_feed"),
    "feed_animals": ("feed_animals", "feed"),
    "backstop_feed": ("feed_animals", "feed"),
    "adopt_batch_start": ("adopt_animal", "adopt"),
    "respond_to_trade": ("respond_to_trade", "trades"),
    "propose_trade": ("propose_trade", "offers"),
}
INTENT_ENDS = {
    "sell_done": "sell",
    "buy_feed_done": "buy_feed",
    "feed_animals_done": "feed_animals",
    "adopt_batch_done": "adopt_batch_start",
}


def _trace_epoch(value: Any) -> Optional[float]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return None


def _call_step(call_ts: Optional[float], tool: str, pipeline: Dict[str, Any],
               graph: Dict[str, Any]) -> Optional[str]:
    """Assign a boundary span to the measured step containing its start time."""
    if call_ts is not None:
        owner = None
        latest_start = float("-inf")
        for step in pipeline.get("steps") or []:
            start = _trace_epoch(step.get("started_ts"))
            end = _trace_epoch(step.get("ended_ts") or pipeline.get("updated_ts"))
            if (start is not None and call_ts >= start - 0.2
                    and (end is None or call_ts <= end + 0.5)
                    and start > latest_start):
                # Adjacent progress timestamps can be equal to the second. The
                # latest matching start owns the call, not the step that just
                # ended and happened to appear first in the list.
                owner = step.get("name")
                latest_start = start
        if owner:
            return owner
    # A timestamp can land in the sub-second gap between progress writes. Static
    # reachability is an honest fallback only when exactly one step owns the tool.
    owners = []
    for node in graph.get("nodes") or []:
        if node.get("kind") == "tool" and node.get("label") == tool:
            owners = list(node.get("steps") or [])
            break
    return owners[0] if len(owners) == 1 else None


def _boundary_calls(pipeline: Dict[str, Any], graph: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Pair best-effort MCP start/end rows into spans for the current run."""
    run_start = _trace_epoch(pipeline.get("started_ts"))
    calls: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []
    # The cycle budget permits roughly 600 calls at the limiter's maximum rate;
    # read enough start/end rows to preserve every call in even that worst case.
    for row in _json_lines(TOOL_CALLS, 2400):
        call_id = str(row.get("id") or "")
        if not call_id:
            continue
        ts = _trace_epoch(row.get("ts"))
        if run_start is not None and ts is not None and ts < run_start - 1:
            continue
        if row.get("event") == "start":
            calls[call_id] = {
                "id": call_id,
                "tool": str(row.get("tool") or "unknown"),
                "started_ts": row.get("ts"),
                "ended_ts": None,
                "duration_ms": None,
                "status": "active",
                "arguments": row.get("arguments") or {},
                "result": None,
                "error": None,
                "source": "boundary",
            }
            order.append(call_id)
        elif row.get("event") == "end":
            call = calls.get(call_id)
            if call is None:
                continue
            call.update({
                "ended_ts": row.get("ts"),
                "duration_ms": row.get("duration_ms"),
                "status": "ok" if row.get("ok") else "error",
                "result": row.get("result"),
                "error": row.get("error"),
            })
    result = []
    for call_id in order:
        call = calls.get(call_id)
        if not call:
            continue
        call["step"] = _call_step(_trace_epoch(call.get("started_ts")), call["tool"], pipeline, graph)
        result.append(call)
    return result[-1000:]


def _intent_calls(pipeline: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Legacy mutation spans. Useful, but explicitly incomplete."""
    run_start = _trace_epoch(pipeline.get("started_ts"))
    calls: List[Dict[str, Any]] = []
    open_by_action: Dict[str, List[Dict[str, Any]]] = {}
    for index, row in enumerate(_json_lines(INTENTS, 400)):
        ts = _trace_epoch(row.get("ts"))
        if run_start is not None and ts is not None and ts < run_start - 1:
            continue
        action = str(row.get("action") or "")
        if action in INTENT_TOOLS:
            tool, step = INTENT_TOOLS[action]
            call = {
                "id": "intent-%s-%d" % (row.get("ts") or "", index),
                "tool": tool,
                "step": step,
                "started_ts": row.get("ts"),
                "ended_ts": None,
                "duration_ms": None,
                "status": "active",
                "arguments": row.get("detail") or {},
                "result": None,
                "error": None,
                "source": "intent",
            }
            calls.append(call)
            open_by_action.setdefault(action, []).append(call)
            continue
        start_action = INTENT_ENDS.get(action)
        if not start_action:
            continue
        candidates = open_by_action.get(start_action) or []
        if not candidates and start_action == "feed_animals":
            candidates = open_by_action.get("backstop_feed") or []
        if not candidates:
            continue
        call = candidates.pop(0)
        call["ended_ts"] = row.get("ts")
        end = _trace_epoch(row.get("ts"))
        start = _trace_epoch(call.get("started_ts"))
        call["duration_ms"] = round(max(0, end - start) * 1000, 1) if end is not None and start is not None else None
        call["status"] = "ok"
        call["result"] = row.get("detail") or {}
    return calls[-1000:]


def snapshot_trace_fingerprint() -> Optional[str]:
    """The fingerprint /api/state advertises, so both endpoints agree."""
    try:
        return hashlib.sha1(repr(topology.signature()).encode("utf-8")).hexdigest()[:12]
    except Exception:  # noqa: BLE001
        return None


def _trace() -> Dict[str, Any]:
    """The small, per-poll half of the 2D run trace.

    Static reachability remains on /api/topology. This payload contains only
    measured run state: paired MCP boundary spans when the deployed client emits
    them, or the older mutation-intent pairs with an explicit coverage warning.
    """
    try:
        fingerprint = snapshot_trace_fingerprint()
        pipeline = progress.read() or {}
        graph = topology.cached_graph()
        calls = _boundary_calls(pipeline, graph)
        coverage = "full" if calls else "mutations_only"
        if not calls:
            calls = _intent_calls(pipeline)
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120], "fingerprint": None, "calls": [],
                "coverage": "unavailable", "activity": []}

    # Compatibility for an older dashboard bundle during a monitor restart. New
    # clients consume calls; old ones still turn activity into packets.
    activity = []
    for call in calls:
        arguments = call.get("arguments") if isinstance(call.get("arguments"), dict) else {}
        label = call.get("tool") or "tool"
        if arguments.get("item"):
            label = "%s %s" % (label, arguments["item"])
        elif arguments.get("qty") is not None:
            label = "%s %s" % (label, arguments["qty"])
        activity.append({
            "key": call.get("id"),
            "ts": call.get("started_ts"),
            "tool": call.get("tool"),
            "step": call.get("step"),
            "label": label,
        })
    return {
        "fingerprint": fingerprint,
        "calls": calls,
        "coverage": coverage,
        "activity": activity[-40:],
        "run_started_ts": pipeline.get("started_ts"),
    }


def _tokens_summary() -> Dict[str, Any]:
    try:
        return tokens.summary()
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120]}


def _heal_summary() -> Dict[str, Any]:
    try:
        log = heal.recent(40)[::-1]
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:120]}
    # Group by alert class: several queued copies of one alert describe one
    # condition, so the class is the unit an operator actually reasons about.
    classes: Dict[str, Dict[str, Any]] = {}
    for item in log:
        name = str(item.get("class") or "unknown")
        entry = classes.setdefault(
            name, {"class": name, "count": 0, "last_ts": None, "last_run": None,
                   "last_action": None, "alerts": []}
        )
        entry["count"] += 1
        if entry["last_ts"] is None:
            entry["last_ts"] = item.get("ts")
            entry["last_run"] = item.get("run")
            entry["last_action"] = item.get("action")
        alert = item.get("alert")
        if alert and alert not in entry["alerts"]:
            entry["alerts"].append(str(alert)[:160])
    try:
        knobs = heal.effective_knobs()
    except Exception as exc:  # noqa: BLE001
        knobs = {"error": str(exc)[:120]}
    return {
        "knobs": knobs,
        "recent": log[:12],
        "classes": sorted(classes.values(), key=lambda x: -x["count"]),
        "total": len(log),
    }


def _release_info() -> Dict[str, Any]:
    """Which code is live, and whether this dashboard agrees with it.

    The dashboard imports farm/* from its OWN directory, so running it from the
    working tree means state written by the released loop is being interpreted by
    possibly-unreleased rules (a produce floor or knob clamp you just edited).
    That is worth saying out loud rather than silently mixing the two.
    """
    live = PROJECT / "release"
    try:
        target = live.resolve()
    except OSError:
        target = live
    try:
        revision = (target / "RELEASED").read_text(encoding="utf-8").strip()
    except OSError:
        revision = "unpublished"
    live_fp = release_info.fingerprint(str(target))
    tree_fp = release_info.fingerprint(str(PROJECT))
    return {
        "revision": revision,
        "target": str(target),
        "live_fingerprint": live_fp,
        "tree_fingerprint": tree_fp,
        "diverged": bool(live_fp and tree_fp and live_fp != tree_fp),
        "dashboard_root": str(PROJECT),
    }


GAME_DIR = PROJECT / "game"
def _game_asset(name: str) -> str:
    """Read a game asset, or return a visible stub rather than a broken tab.

    The game lives in game/ as real .css/.html/.js files instead of inside this
    module's HTML string: it is now an incremental game with a simulation worth
    unit-testing, and a 600-line string literal is not somewhere you can do that.
    Both the dashboard tab and the standalone export compose from these same
    files, so the two can never drift.
    """
    try:
        return (GAME_DIR / name).read_text(encoding="utf-8")
    except OSError as exc:
        return "/* missing game asset %s: %s */" % (name, exc)


GAME_CSS = _game_asset("coop_rush.css")
GAME_MARKUP = _game_asset("coop_rush.html")
GAME_JS = _game_asset("coop_rush.js") + "\n" + _game_asset("coop_rush_ui.js")

DASHBOARD_DIR = PROJECT / "dashboard"


def _dashboard_asset(name: str) -> str:
    """Read a dashboard asset, or a visible stub rather than a broken panel.

    The trace explorer lives in dashboard/ for the same reason the game does:
    span derivation and call-path routing are logic worth unit-testing in
    JavaScriptCore, while logic inside a Python string literal can only be hoped
    about.
    """
    try:
        return (DASHBOARD_DIR / name).read_text(encoding="utf-8")
    except OSError as exc:
        return "/* missing dashboard asset %s: %s */" % (name, exc)


TRACE_CSS = _dashboard_asset("trace_explorer.css")
TRACE_JS = _dashboard_asset("trace_explorer.js")


HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nick's Farm Friends Monitor</title>
<style>
:root { color-scheme: dark; --bg:#101714; --panel:#18231e; --panel2:#1e2d26; --line:#30463a; --text:#edf7ef; --muted:#9cb4a4; --green:#72e09a; --yellow:#f5cc75; --red:#ff8a83; --blue:#8fc8ff; }
* { box-sizing:border-box; } body { margin:0; background:radial-gradient(circle at 20% 0%,#1d3528 0,#101714 42%); color:var(--text); font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
main { max-width:1400px; margin:0 auto; padding:24px; } header { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin-bottom:22px; }
h1 { margin:0 0 4px; font-size:26px; letter-spacing:-.03em; } .subtitle { color:var(--muted); } .refresh { color:var(--muted); font-size:12px; text-align:right; }
.grid { display:grid; gap:14px; grid-template-columns:repeat(12,1fr); } .card { min-width:0; background:rgba(24,35,30,.9); border:1px solid var(--line); border-radius:14px; padding:16px; box-shadow:0 8px 28px #0002; }
.status { grid-column:span 3; } .blockers { grid-column:span 5; } .release { grid-column:span 4; } .wide { grid-column:span 8; } .side { grid-column:span 4; } .full { grid-column:1/-1; } .cost { grid-column:span 6; } .healing { grid-column:span 6; }
.card h2 { margin:0 0 13px; font-size:14px; text-transform:uppercase; letter-spacing:.1em; color:var(--muted); } .big { font-size:32px; font-weight:750; letter-spacing:-.04em; }
.pill { display:inline-flex; align-items:center; gap:7px; border-radius:99px; padding:5px 10px; font-weight:700; font-size:12px; text-transform:uppercase; letter-spacing:.06em; } .pill:before { content:""; width:8px; height:8px; border-radius:50%; background:currentColor; box-shadow:0 0 12px currentColor; }
.running,.healthy,.ok { color:var(--green); } .offline,.error,.stale { color:var(--red); } .waiting,.warn { color:var(--yellow); }
.alert.warn .alert-dot { background:var(--yellow); }
.metrics { display:grid; grid-template-columns:repeat(2,1fr); gap:12px; margin-top:16px; } .metric label { display:block; color:var(--muted); font-size:12px; } .metric strong { display:block; font-size:20px; margin-top:2px; }
.kv { display:grid; grid-template-columns:1fr 1fr; gap:8px 18px; } .kv div { display:flex; justify-content:space-between; gap:12px; border-bottom:1px solid #ffffff0d; padding:4px 0; } .kv span:first-child { color:var(--muted); } .kv span:last-child { text-align:right; font-weight:650; }
ul { list-style:none; padding:0; margin:0; } li { padding:8px 0; border-bottom:1px solid #ffffff0d; } li:last-child { border-bottom:0; }
.alert { display:flex; gap:9px; align-items:flex-start; } .alert-dot { flex:0 0 8px; height:8px; margin-top:6px; border-radius:50%; background:var(--red); } .alert.ok .alert-dot { background:var(--green); }
table { width:100%; border-collapse:collapse; font-variant-numeric:tabular-nums; } th,td { text-align:right; padding:8px 7px; border-bottom:1px solid #ffffff0d; white-space:nowrap; } th:first-child,td:first-child, th:nth-child(2),td:nth-child(2) { text-align:left; } th { color:var(--muted); font-size:11px; text-transform:uppercase; letter-spacing:.06em; } td.bad { color:var(--red); } td.good { color:var(--green); }
.chart { height:150px; width:100%; } svg { width:100%; height:100%; overflow:visible; } .axis { stroke:var(--line); stroke-width:1; } .line { fill:none; stroke:var(--green); stroke-width:3; stroke-linecap:round; stroke-linejoin:round; } .empty { color:var(--muted); padding:18px 0; }
.log { color:#b8cabc; font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace; white-space:pre-wrap; max-height:220px; overflow:auto; background:#0b100d; border-radius:9px; padding:10px; }
nav.tabs { display:flex; gap:6px; margin:0 0 18px; border-bottom:1px solid var(--line); overflow-x:auto; scrollbar-width:thin; }
nav.tabs button { appearance:none; flex:0 0 auto; white-space:nowrap; background:none; border:0; border-bottom:2px solid transparent; color:var(--muted); font:600 14px/1 inherit; padding:10px 14px; cursor:pointer; letter-spacing:.01em; }
nav.tabs button:hover { color:var(--text); } nav.tabs button[aria-selected="true"] { color:var(--green); border-bottom-color:var(--green); }
.tab[hidden] { display:none; }
.pipe { display:flex; flex-direction:column; gap:0; }
.pstep { display:grid; grid-template-columns:26px 190px 1fr 84px; gap:12px; align-items:center; padding:9px 0; border-bottom:1px solid #ffffff0d; }
.pstep:last-child { border-bottom:0; }
.dot { width:14px; height:14px; border-radius:50%; border:2px solid var(--line); position:relative; }
.pstep.done .dot { background:var(--green); border-color:var(--green); }
.pstep.active .dot { background:var(--yellow); border-color:var(--yellow); animation:pulse 1.1s ease-in-out infinite; }
.pstep.failed .dot { background:var(--red); border-color:var(--red); }
.pstep.skipped .dot { background:#3a4a41; border-color:#3a4a41; }
@keyframes pulse { 0%,100% { box-shadow:0 0 0 0 #f5cc7566; } 50% { box-shadow:0 0 0 7px #f5cc7500; } }
.pname { font-weight:650; } .pname small { display:block; color:var(--muted); font-weight:400; font-size:11.5px; }
.pstep.pending .pname, .pstep.pending .pmeta { opacity:.45; }
.pmeta { color:var(--muted); font-size:12.5px; }
.pmeta b { color:var(--text); font-weight:650; }
.pbar { height:6px; background:#ffffff12; border-radius:99px; overflow:hidden; margin-top:5px; }
.pbar i { display:block; height:100%; background:var(--green); border-radius:99px; }
.pstep.active .pbar i { background:var(--yellow); }
.psec { text-align:right; font-variant-numeric:tabular-nums; font-weight:650; }
.budget { height:10px; background:#ffffff12; border-radius:99px; overflow:hidden; margin-top:10px; }
.budget i { display:block; height:100%; background:linear-gradient(90deg,var(--green),var(--yellow)); }
.budget.over i { background:var(--red); }
.btn { appearance:none; background:var(--panel2); color:var(--text); border:1px solid var(--line); border-radius:9px; padding:9px 13px; font:650 13px/1 inherit; cursor:pointer; }
.btn:hover { border-color:var(--green); color:var(--green); } .btn:active { transform:translateY(1px); }
ul.rules li { padding:6px 0; color:var(--muted); } ul.rules b { color:var(--text); }
code { background:#ffffff10; border-radius:4px; padding:1px 5px; font-size:12px; }
.tagrow { display:flex; flex-wrap:wrap; gap:6px; margin-top:8px; }
.tag { background:#ffffff10; border:1px solid var(--line); border-radius:99px; padding:3px 9px; font-size:11.5px; color:var(--muted); }
.healclass { border-bottom:1px solid #ffffff0d; padding:10px 0; } .healclass:last-child { border-bottom:0; }
.healclass .top { display:flex; justify-content:space-between; gap:12px; align-items:baseline; }
.healclass .cls { font-weight:700; } .healclass .n { color:var(--yellow); font-variant-numeric:tabular-nums; }
.healclass .what { color:var(--muted); font-size:12.5px; margin-top:3px; }

/* ---- hero strip -------------------------------------------------------
 * The top of the page used to be four small metrics in a card. The farm's whole
 * job is a number that goes up, so that number is now the largest thing on the
 * page and it moves between polls (interpolated from the measured rate) rather
 * than jumping every 2 seconds. A dashboard for a live system should look live.
 */
.hero { grid-column:1/-1; display:grid; grid-template-columns:repeat(auto-fit,minmax(184px,1fr)); gap:0;
  background:rgba(24,35,30,.96); border:1px solid var(--line); border-radius:14px; overflow:hidden; }
.hero-cell { background:rgba(24,35,30,.96); border-right:1px solid var(--line); border-bottom:1px solid var(--line); padding:14px 16px; min-width:0; }
.hero-cell label { display:block; color:var(--muted); font-size:11px; text-transform:uppercase; letter-spacing:.09em; }
.hero-cell strong { display:block; font-size:29px; font-weight:750; letter-spacing:-.035em;
  font-variant-numeric:tabular-nums; margin-top:3px; line-height:1.1; }
.hero-cell small { display:block; color:var(--muted); font-size:11.5px; margin-top:3px;
  white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.hero-cell.lead strong { color:var(--green); }
.hero-cell.warnish strong { color:var(--yellow); }
.hero-cell.badish strong { color:var(--red); }
.spark { display:block; height:26px; margin-top:6px; }
.spark svg { width:100%; height:100%; overflow:visible; }
.spark path.fill { fill:url(#sparkfill); stroke:none; }
.spark path.stroke { fill:none; stroke:var(--green); stroke-width:1.8; stroke-linejoin:round; stroke-linecap:round; }
.spark circle { fill:var(--green); }

/* ---- the farm view ----------------------------------------------------
 * Everything drawn here is a field from the live state payload. The two species measured to
 * produce nothing are drawn greyed out and labelled, because "we own 200 animals
 * that do nothing" is the single most important fact about this farm and a
 * number in a table never once made anybody notice it.
 */
.farmview { grid-column:1/-1; }
.scene { position:relative; border-radius:12px; padding:14px; overflow:hidden;
  background:linear-gradient(180deg,#16352a 0%,#12251d 58%,#132a1e 58%,#0f2018 100%);
  border:1px solid var(--line); }
.scene-sky { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; }
.scene-sun { font-size:23px; }
.scene-rank { text-align:right; }
.scene-rank b { display:block; font-size:19px; }
.scene-rank span { color:var(--muted); font-size:11.5px; }
.pens { display:grid; grid-template-columns:repeat(auto-fit,minmax(126px,1fr)); gap:9px; margin-top:12px; }
.pen { background:#0b1a13b8; border:1px solid var(--line); border-radius:10px; padding:9px 10px; min-width:0; }
.pen.idle { border-style:dashed; opacity:.72; }
.pen-top { display:flex; justify-content:space-between; align-items:baseline; gap:8px; }
.pen-top b { font-size:13px; text-transform:capitalize; }
.pen-count { font-variant-numeric:tabular-nums; font-weight:750; color:var(--green); font-size:13px; }
.pen.idle .pen-count { color:var(--muted); }
.herd { display:flex; flex-wrap:wrap; gap:2px; margin-top:7px; min-height:34px; align-content:flex-start; }
.herd i { font-size:13px; font-style:normal; line-height:1; animation:bob 2.6s ease-in-out infinite; }
.pen.idle .herd i { filter:grayscale(1) opacity(.5); animation:none; }
@keyframes bob { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-2.5px); } }
.pen-note { display:block; color:var(--muted); font-size:10.5px; margin-top:6px; line-height:1.35; }
.pen.idle .pen-note { color:var(--red); }
.scene-ground { display:grid; grid-template-columns:repeat(auto-fit,minmax(168px,1fr)); gap:10px; margin-top:12px; }
.race { display:flex; flex-direction:column; gap:12px; }
.racer { min-width:0; }
.race-label { display:flex; justify-content:space-between; gap:10px; font-size:12.5px; }
.race-label b { font-variant-numeric:tabular-nums; }
.race-track { height:8px; background:#ffffff10; border-radius:99px; overflow:hidden; margin-top:5px; }
.race-track i { display:block; height:100%; border-radius:99px; background:#557063; transition:width .45s ease; }
.racer.self .race-track i { background:linear-gradient(90deg,#3f9d6b,var(--green)); }
.racer small { display:block; color:var(--muted); font-size:10.5px; margin-top:3px; text-align:right; }
.gauge { background:#0b1a13b8; border:1px solid var(--line); border-radius:10px; padding:10px 11px; }
.gauge label { display:flex; justify-content:space-between; gap:10px; color:var(--muted); font-size:11px;
  text-transform:uppercase; letter-spacing:.07em; }
.gauge label b { color:var(--text); font-variant-numeric:tabular-nums; letter-spacing:0; }
.gtrack { height:9px; background:#ffffff12; border-radius:99px; overflow:hidden; margin-top:7px; position:relative; }
.gtrack i { display:block; height:100%; border-radius:99px; background:var(--green); transition:width .4s ease; }
.gtrack.hunger i { background:linear-gradient(90deg,var(--green),var(--yellow) 60%,var(--red)); }
.gtrack u { position:absolute; top:-3px; width:2px; height:15px; background:var(--red); text-decoration:none; }
.gauge small { display:block; color:var(--muted); font-size:11px; margin-top:6px; }

/* ---- interactive chart ------------------------------------------------- */
.chips { display:flex; flex-wrap:wrap; gap:6px; margin-bottom:12px; }
.chip { appearance:none; background:var(--panel2); border:1px solid var(--line); color:var(--muted);
  border-radius:99px; padding:5px 12px; font:650 12px/1 inherit; cursor:pointer; }
.chip:hover { color:var(--text); }
.chip[aria-pressed="true"] { background:var(--green); border-color:var(--green); color:#0d1a12; }
.chart { height:190px; width:100%; }
.chart svg { width:100%; height:100%; overflow:visible; }
.grid-line { stroke:#ffffff0f; stroke-width:1; }
.area { fill:url(#areafill); stroke:none; }
.dot { fill:var(--green); }
.dot-hit { fill:transparent; cursor:crosshair; }
.chart-label { fill:var(--muted); font-size:10.5px; }

/* ---- run drill-down ---------------------------------------------------- */
#runs, #cost-recent { max-width:100%; overflow-x:auto; }
tr.runrow { cursor:pointer; }
tr.runrow:hover td { background:#ffffff08; }
tr.runrow.open td { background:#ffffff0d; }
tr.rundetail td { padding:0 0 14px; }
.detail { display:grid; grid-template-columns:repeat(auto-fit,minmax(228px,1fr)); gap:14px;
  background:#0b100db8; border:1px solid var(--line); border-radius:11px; padding:13px 15px; }
.detail h3 { margin:0 0 7px; font-size:11px; text-transform:uppercase; letter-spacing:.09em; color:var(--muted); }
.detail .kv { grid-template-columns:1fr; }
.phasebars i { display:block; height:5px; border-radius:99px; background:var(--green); }
.phaserow { display:grid; grid-template-columns:78px 1fr 46px; gap:9px; align-items:center;
  font-size:12px; padding:3px 0; }
.phaserow span:first-child { color:var(--muted); }
.phaserow span:last-child { text-align:right; font-variant-numeric:tabular-nums; }

/* ---- token & cost history ----------------------------------------------
 * The tab distinguishes two evidence classes visually: green is booked ledger
 * data, amber is the measured pre-Python counterfactual, and its translucent
 * band is the honest 150k-600k input-token uncertainty rather than fake precision.
 */
.cost-hero .hero-cell strong { font-size:27px; }
.history-title { display:flex; justify-content:space-between; align-items:flex-start; gap:20px; flex-wrap:wrap; }
.history-title h2 { margin-bottom:4px; }
.history-title .method { margin:0; max-width:650px; }
.history-controls { display:flex; flex-direction:column; align-items:flex-end; gap:7px; }
.history-controls .chips { margin:0; justify-content:flex-end; }
.costcurve { width:100%; height:300px; margin-top:10px; }
.costcurve svg { width:100%; height:100%; overflow:visible; }
.cost-band { fill:var(--yellow); opacity:.11; }
.cost-old { fill:none; stroke:var(--yellow); stroke-width:2.5; stroke-linecap:round; stroke-linejoin:round; }
.cost-actual { fill:none; stroke:var(--green); stroke-width:3.5; stroke-linecap:round; stroke-linejoin:round; }
.cost-wakeup { fill:none; stroke:var(--red); stroke-width:2.5; stroke-linecap:round; stroke-linejoin:round; }
.cost-point { fill:var(--green); stroke:var(--panel); stroke-width:2; }
.cost-point.old { fill:var(--yellow); }
.cost-marker { stroke:var(--blue); stroke-width:1; stroke-dasharray:4 4; opacity:.8; }
.cost-legend { display:flex; flex-wrap:wrap; gap:16px; align-items:center; color:var(--muted); font-size:11.5px; }
.cost-legend span { display:inline-flex; gap:7px; align-items:center; }
.cost-legend i { width:22px; height:3px; border-radius:99px; background:var(--green); }
.cost-legend i.old { background:var(--yellow); }
.cost-legend i.band { height:9px; opacity:.25; }
.cost-legend i.wakeup { background:var(--red); }
.change-list { display:flex; flex-direction:column; position:relative; }
.change-list:before { content:""; position:absolute; left:22px; top:22px; bottom:22px; width:2px; background:var(--line); }
.change-step { position:relative; display:grid; grid-template-columns:46px minmax(0,1fr); gap:12px; padding:9px 0 13px; }
.change-icon { position:relative; z-index:1; display:flex; width:44px; height:44px; align-items:center; justify-content:center;
  border-radius:50%; background:var(--panel2); border:2px solid var(--line); font-size:20px; }
.change-step.before .change-icon { border-color:var(--red); }
.change-step.cutover .change-icon { border-color:var(--yellow); box-shadow:0 0 20px #f5cc7522; }
.change-step.python .change-icon, .change-step.proof .change-icon { border-color:var(--green); }
.change-head { display:flex; justify-content:space-between; align-items:baseline; gap:12px; flex-wrap:wrap; }
.change-head b { font-size:14px; }
.change-head span { color:var(--muted); font-size:11px; text-transform:uppercase; letter-spacing:.07em; }
.change-body p { margin:4px 0; color:var(--muted); font-size:12.5px; line-height:1.5; }
.change-impact { color:var(--green); font-size:12px; font-weight:650; }
.change-code { color:var(--blue); font:11px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace; margin-top:4px; }
.monthly label { display:block; color:var(--muted); font-size:11px; text-transform:uppercase; letter-spacing:.08em; }
.monthly strong { display:block; font-size:34px; letter-spacing:-.04em; margin:3px 0; font-variant-numeric:tabular-nums; }
.monthly small { display:block; color:var(--muted); font-size:11.5px; }
.monthly i { display:block; height:1px; background:var(--line); margin:16px 0; }
.source-bars { display:flex; flex-direction:column; gap:10px; }
.source-row { display:grid; grid-template-columns:minmax(0,1fr) 62px; gap:8px; }
.source-row label { font-size:12px; text-transform:capitalize; }
.source-row b { text-align:right; font-size:12px; font-variant-numeric:tabular-nums; }
.source-row small { grid-column:1/-1; color:var(--muted); font-size:10.5px; margin-top:-3px; }
.source-track { grid-column:1/-1; height:8px; background:#ffffff10; border-radius:99px; overflow:hidden; }
.source-track i { display:block; height:100%; border-radius:99px; background:linear-gradient(90deg,#557063,var(--green)); }
.ledger-dots { display:grid; grid-template-columns:repeat(auto-fill,minmax(11px,1fr)); gap:4px; margin:15px 0; }
.ledger-dot { display:block; aspect-ratio:1; min-height:8px; max-height:14px; border-radius:3px; background:var(--green); opacity:.8; }
.ledger-dot.healed { background:var(--yellow); opacity:1; }
.ledger-dot.charged { background:var(--red); opacity:1; box-shadow:0 0 8px #ff8a8366; }

/* ---- findings tab ------------------------------------------------------ */
.finding { grid-column:1/-1; }
.claim { font-size:15.5px; line-height:1.5; font-weight:600; margin:0 0 4px; }
.claim em { color:var(--green); font-style:normal; }
.method { color:var(--muted); font-size:12.5px; line-height:1.55; margin:8px 0 0; }
.scatter { height:250px; width:100%; margin-top:6px; }
.scatter svg { width:100%; height:100%; overflow:visible; }
.scatter .pt { fill:var(--green); opacity:.85; }
.scatter .pt.plateau { fill:var(--yellow); }
.scatter .fitline { stroke:var(--blue); stroke-width:2; stroke-dasharray:5 4; }
.scatter .divider { stroke:var(--red); stroke-width:1; stroke-dasharray:3 3; }
.twoup { display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:16px; }
.verdictbox { border:1px solid var(--line); border-radius:11px; padding:12px 14px; background:#ffffff06; }
.verdictbox b { display:block; font-size:13px; margin-bottom:5px; }
.verdictbox.good { border-color:#4d7a60; background:#20342a; }
.verdictbox.bad { border-color:#7a4d4d; background:#34201f; }
.slider { width:100%; margin:10px 0 4px; accent-color:var(--green); }
.counter { font-size:33px; font-weight:750; letter-spacing:-.035em; font-variant-numeric:tabular-nums; }
.counter.saved { color:var(--green); }
.timeline { position:relative; padding-left:24px; }
.timeline:before { content:""; position:absolute; left:6px; top:6px; bottom:6px; width:2px; background:var(--line); }
.tl { position:relative; padding:9px 0 9px 4px; }
.tl:before { content:""; position:absolute; left:-22px; top:15px; width:10px; height:10px; border-radius:50%;
  background:var(--panel); border:2px solid var(--green); }
.tl.experiment:before { border-color:var(--yellow); }
.tl.detector:before { border-color:var(--blue); }
.tl.correction:before { border-color:var(--red); }
.tl-run { color:var(--muted); font-size:11px; text-transform:uppercase; letter-spacing:.08em; }
.tl b { display:block; font-size:13.5px; margin:2px 0 3px; }
.tl span { color:var(--muted); font-size:12.5px; line-height:1.5; }
.bars { display:flex; flex-direction:column; gap:7px; margin-top:4px; }
.bar { display:grid; grid-template-columns:96px 1fr 108px; gap:10px; align-items:center; font-size:12.5px; }
.bar span:first-child { color:var(--muted); text-transform:capitalize; }
.bar span:last-child { text-align:right; font-variant-numeric:tabular-nums; font-weight:650; }
.bartrack { height:16px; background:#ffffff10; border-radius:5px; overflow:hidden; }
.bartrack i { display:block; height:100%; background:linear-gradient(90deg,#3f9d6b,var(--green)); border-radius:5px;
  transition:width .4s ease; }
.bartrack i.zero { background:var(--red); min-width:2px; }
.hint { color:var(--muted); font-size:11.5px; }
kbd { background:#ffffff12; border:1px solid var(--line); border-bottom-width:2px; border-radius:5px;
  padding:1px 5px; font:600 11px/1.5 ui-monospace,Menlo,monospace; }

@media (prefers-reduced-motion: reduce) {
  .herd i, .pstep.active .dot { animation:none; }
  .gtrack i, .bartrack i, .pbar i { transition:none; }
}
@media (max-width:900px) { .status,.blockers,.release,.wide,.side,.cost,.healing { grid-column:1/-1; } header { display:block; } .refresh { text-align:left; margin-top:10px; } .history-controls { align-items:flex-start; margin-top:12px; } .history-controls .chips { justify-content:flex-start; } .costcurve { height:240px; } }
__TRACE_CSS__
__GAME_CSS__
</style>
</head>
<body><main>
<header><div><h1>🌱 Nick's Farm Friends</h1><div class="subtitle">Read-only live monitor · no farm actions from this page</div></div><div class="refresh" id="updated">Connecting…<br>Auto-refresh: 2s</div></header>
<nav class="tabs" role="tablist">
  <button role="tab" data-tab="overview" aria-selected="true">Overview</button>
  <button role="tab" data-tab="pipeline" aria-selected="false">Pipeline</button>
  <button role="tab" data-tab="cost" aria-selected="false">Cost &amp; healing</button>
  <button role="tab" data-tab="history" aria-selected="false">📊 Token &amp; cost history</button>
  <button role="tab" data-tab="findings" aria-selected="false">🔬 Findings</button>
  <button role="tab" data-tab="game" aria-selected="false">🥚 Coop Rush</button>
</nav>
<div class="tab" id="tab-overview">
<section class="grid">
<div class="hero" aria-label="Live farm summary">
  <div class="hero-cell lead"><label>Lifetime produce · live estimate</label><strong id="hero-produce">—</strong><small id="hero-produce-sub">waiting for a measured rate</small><span class="spark" id="spark-produce"></span></div>
  <div class="hero-cell"><label>Production rate</label><strong id="hero-rate">—</strong><small id="hero-rate-sub">score delta over the real interval</small><span class="spark" id="spark-rate"></span></div>
  <div class="hero-cell"><label>Leaderboard</label><strong id="hero-rank">—</strong><small id="hero-gap">waiting for rivals</small><span class="spark" id="spark-rank"></span></div>
  <div class="hero-cell"><label>Herd</label><strong id="hero-animals">—</strong><small id="hero-herd-sub">growth policy loading</small><span class="spark" id="spark-animals"></span></div>
  <div class="hero-cell"><label>Hunger</label><strong id="hero-hunger">—</strong><small id="hero-hunger-sub">production stops at 70</small><span class="spark" id="spark-hunger"></span></div>
</div>
<div class="card farmview"><h2>Live farm <small style="text-transform:none;letter-spacing:0;color:var(--muted);font-weight:400">every object below is telemetry</small></h2><div class="scene" id="farm-scene"><div class="empty">Waiting for farm state…</div></div></div>
<div class="card status"><h2>Loop status</h2><div id="health"><span class="pill waiting">connecting</span></div><div class="metrics"><div class="metric"><label>Last run</label><strong id="last-run">—</strong></div><div class="metric"><label>Run age</label><strong id="run-age">—</strong></div><div class="metric"><label>Stage</label><strong id="stage">—</strong></div><div class="metric"><label>Cadence</label><strong id="cadence">—</strong></div></div></div>
<div class="card blockers"><h2>Blockers & alerts</h2><ul id="blockers"><li class="empty">Loading…</li></ul></div>
<div class="card release"><h2>Scheduler & release</h2><div class="kv" id="system"></div></div>
<div class="card wide"><h2>Farm state</h2><div class="kv" id="farm"></div></div>
<div class="card side"><h2>Leaderboard</h2><div id="leaderboard"></div></div>
<div class="card wide"><h2 id="chart-title">Farm trend</h2><div class="chips" id="chart-metrics" aria-label="Chart metric">
  <button class="chip" data-metric="produce" aria-pressed="true">Produce</button>
  <button class="chip" data-metric="produce_per_min" aria-pressed="false">Rate</button>
  <button class="chip" data-metric="animals" aria-pressed="false">Animals</button>
  <button class="chip" data-metric="max_hunger" aria-pressed="false">Hunger</button>
  <button class="chip" data-metric="feed" aria-pressed="false">Feed</button>
  <button class="chip" data-metric="coins" aria-pressed="false">Coins</button>
</div><div class="chart" id="chart"></div><div class="hint" id="chart-note">Choose a metric · hover a point for the run</div></div>
<div class="card side"><h2>Current intent</h2><div class="kv" id="intent"></div></div>
<div class="card full"><h2>Growth policy</h2><div id="growth-verdict"></div><div class="kv" id="growth" style="margin-top:12px"></div></div>
<div class="card full"><h2>Recent runs</h2><div id="runs"></div></div>
<div class="card full"><h2>Launchd log tail</h2><div class="log" id="log">Loading…</div></div>
</section>
</div>
<div class="tab" id="tab-pipeline" hidden>
<section class="grid">
  <div class="card status"><h2>Run</h2><div id="pipe-status"><span class="pill waiting">connecting</span></div><div class="metrics"><div class="metric"><label>Run</label><strong id="pipe-run">—</strong></div><div class="metric"><label>Elapsed</label><strong id="pipe-elapsed">—</strong></div><div class="metric"><label>Active step</label><strong id="pipe-active">—</strong></div><div class="metric"><label>Steps done</label><strong id="pipe-count">—</strong></div><div class="metric"><label>Next run</label><strong id="pipe-next">—</strong></div></div><div class="subtitle" id="pipe-heartbeat" style="margin-top:10px;font-size:12px">—</div></div>
  <div class="card blockers"><h2>Cycle budget</h2><div class="kv" id="pipe-budget"></div><div class="budget" id="pipe-budget-bar"><i style="width:0%"></i></div><div class="subtitle" style="margin-top:9px;font-size:12px">Adoption stops at the budget; the process self-kills at the hard timeout so it never blocks the next slot.</div></div>
  <div class="card release"><h2>Last completed</h2><div class="kv" id="pipe-summary"></div></div>
  <div class="card trace">
    <div class="head">
      <div>
        <h2>Execution trace <small style="text-transform:none;letter-spacing:0;color:var(--muted);font-weight:400">measured spans + source-derived paths</small></h2>
        <div class="trace-sub">The run trace answers <b>what happened when</b>: real step durations and every observed MCP boundary call share one clock. The tool matrix answers <b>how the whole system is wired</b>: rows are pipeline steps, columns are external tools, hollow cells are reachable code paths and numbered cells are calls observed in this run. Select anything for arguments, result, source and call path. Python functions are shown as static reachability, never as invented runtime spans.</div>
      </div>
    </div>
    <div id="trace-explorer" class="trace-explorer" aria-live="polite" aria-label="Pipeline execution trace and MCP tool matrix"><div class="te-empty">Loading execution trace…</div></div>
  </div>
  <div class="card full"><h2>What the run is judged on</h2><div id="signal-verdict"></div><div class="kv" id="signals" style="margin-top:12px"></div><div class="subtitle" style="margin-top:10px;font-size:12px">Lifetime produce accrues as animals produce, and <code>collect_produce</code> returns nothing while the herd is hungry — the produce banks during the feed call instead. So the score rate leads, and collection counts trail it.</div></div>
  <div class="card full"><h2>Step timings, as recorded</h2><div class="pipe" id="pipe-steps"><div class="empty">Loading…</div></div></div>
</section>
</div>
<div class="tab" id="tab-cost" hidden>
<section class="grid">
  <div class="card status"><h2>All-time LLM cost</h2><div class="big" id="cost-total">—</div><div class="subtitle" id="cost-total-sub">—</div><div class="metrics"><div class="metric"><label>Tokens (all time)</label><strong id="cost-total-tokens">—</strong></div><div class="metric"><label>Wake-ups (all time)</label><strong id="cost-total-esc">—</strong></div><div class="metric"><label>Runs charged</label><strong id="cost-charged">—</strong></div><div class="metric"><label>Runs at zero</label><strong id="cost-free">—</strong></div></div></div>
  <div class="card blockers"><h2>Last 5 runs</h2><div id="cost-recent"></div><div class="subtitle" style="margin-top:10px;font-size:12px">Every cycle writes an explicit zero to <code>state/tokens.ndjson</code>, so “routine runs cost nothing” is a measurement, not a claim. A row only carries a cost when an alert survived healing and woke a model.</div></div>
  <div class="card release"><h2>Cost avoided by healing</h2><div class="big" id="cost-avoided">—</div><div class="subtitle">Alerts settled in Python that would otherwise have been wake-ups</div><div class="kv" id="cost-detail" style="margin-top:14px"></div></div>
  <div class="card cost"><h2>What is being self-healed</h2><div id="heal-classes"></div></div>
  <div class="card healing"><h2>Active knobs</h2><div class="kv" id="knobs"></div><div class="subtitle" style="margin-top:10px;font-size:12px">No knob can spend coins, adopt, sell, trade or gift. The worst a bad healing decision can do is slow the farm down, and every knob is clamped on read.</div></div>
  <div class="card full"><h2>Remedy log</h2><ul id="heal-log"></ul></div>
</section>
</div>
<div class="tab" id="tab-history" hidden>
<section class="grid">
  <div class="hero cost-hero" aria-label="Token and cost history summary">
    <div class="hero-cell lead"><label>Actual Python-era cost</label><strong id="hist-actual-cost">—</strong><small id="hist-actual-cost-sub">from the token ledger</small></div>
    <div class="hero-cell"><label>Actual tokens</label><strong id="hist-actual-tokens">—</strong><small>input + output booked after cutover</small></div>
    <div class="hero-cell"><label>Audited runs</label><strong id="hist-runs">—</strong><small id="hist-runs-sub">every zero is an explicit row</small></div>
    <div class="hero-cell warnish"><label>Old-loop cost avoided</label><strong id="hist-avoided">—</strong><small id="hist-avoided-sub">measured counterfactual range</small></div>
    <div class="hero-cell"><label>Cost reduction</label><strong id="hist-reduction">—</strong><small>routine execution, like for like</small></div>
    <div class="hero-cell"><label>Model wake-ups</label><strong id="hist-wakeups">—</strong><small id="hist-wakeups-sub">after deterministic healing</small></div>
  </div>
  <div class="card full"><div class="history-title"><div><h2 id="hist-chart-title">Cumulative cost over audited runs</h2><p class="method">Green is the actual ledger. Amber is what the same cycles would have cost at the measured pre-Python run profile.</p></div><div class="history-controls"><div class="chips" id="hist-metrics"><button class="chip" data-hmetric="cost" aria-pressed="true">Cumulative cost</button><button class="chip" data-hmetric="tokens" aria-pressed="false">Cumulative tokens</button><button class="chip" data-hmetric="per_run" aria-pressed="false">Per-run cost</button><button class="chip" data-hmetric="healing" aria-pressed="false">Healing</button></div><div class="chips" id="hist-range"><button class="chip" data-hrange="all" aria-pressed="true">All</button><button class="chip" data-hrange="100" aria-pressed="false">100 runs</button><button class="chip" data-hrange="50" aria-pressed="false">50 runs</button></div></div></div><div class="costcurve" id="hist-chart"><div class="empty">Loading ledger…</div></div><div class="cost-legend" id="hist-legend"></div><p class="method" id="hist-chart-note"></p></div>
  <div class="card wide"><h2>What changed the curve</h2><div class="change-list" id="hist-changes"><div class="empty">Loading execution history…</div></div></div>
  <div class="card side"><h2>At operating cadence</h2><div class="monthly"><label>Old LLM loop · projected monthly</label><strong id="hist-old-monthly">—</strong><small id="hist-old-monthly-range">—</small><i></i><label>Python routine execution · measured</label><strong class="good" id="hist-new-monthly">$0</strong><small>Models are reserved for surviving exceptions.</small></div><h2 style="margin-top:22px">Where the tokens went before</h2><div class="source-bars" id="hist-sources"></div></div>
  <div class="card full"><h2>The zero-cost run</h2><p class="claim">A zero is only evidence if you write it down. Every square is a Python-era run in <code>state/tokens.ndjson</code>: green cost $0, amber healed an alert locally, red woke a model.</p><div class="ledger-dots" id="hist-ledger"></div><div class="metrics" id="hist-ledger-stats"></div><p class="method" id="hist-disclosure"></p></div>
</section>
</div>
<div class="tab" id="tab-findings" hidden>
<section class="grid">
  <div class="card finding"><h2>The finding that changed the strategy</h2><p class="claim" id="ev-ceiling-claim">Loading measured evidence…</p><div class="scatter" id="ev-ceiling-chart"></div><div class="metrics" id="ev-ceiling-stats"></div><p class="method" id="ev-ceiling-method"></p></div>
  <div class="card wide"><h2>Species experiment <small style="text-transform:none;letter-spacing:0;color:var(--muted);font-weight:400">run 50 and every run since</small></h2><div class="bars" id="ev-species"></div><p class="method" id="ev-species-note"></p></div>
  <div class="card side"><h2>Dead ends we retired</h2><div id="ev-dead-ends"><div class="empty">Loading…</div></div></div>
  <div class="card wide"><h2>The cost of leaving strategy in a prompt</h2><p class="claim">The old loop re-read a growing farm state across ~21 turns. The current loop executes the same decisions as arithmetic in <code>rules.py</code>.</p><label class="method" for="ev-runs-slider">Counterfactual LLM runs per day: <b id="ev-runs-label">288</b></label><input class="slider" id="ev-runs-slider" type="range" min="1" max="480" value="288"><div class="twoup"><div><label class="method">Old loop · estimated monthly cost</label><div class="counter" id="ev-old-cost">—</div></div><div><label class="method">Current loop · measured monthly cost</label><div class="counter saved" id="ev-new-cost">$0.00</div></div></div><p class="method" id="ev-cost-note"></p></div>
  <div class="card side"><h2>Detector redesigns</h2><div id="ev-detectors"><div class="empty">Loading…</div></div></div>
  <div class="card finding"><h2>How the model changed</h2><div class="timeline" id="ev-timeline"><div class="empty">Loading evidence…</div></div></div>
</section>
</div>
<!--GAME_MARKUP_START-->
<div class="tab" id="tab-game" hidden>
__GAME_MARKUP__
</div>
<!--GAME_MARKUP_END-->
</main>
<script>
/*HELPERS_START*/
const $ = id => document.getElementById(id);
const nf = new Intl.NumberFormat();
const esc = value => String(value ?? "—").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]));
const num = value => value == null ? "—" : nf.format(value);
const fixed = (value, digits=2) => value == null ? "—" : Number(value).toFixed(digits);
function time(value) { if (!value) return "—"; const d = new Date(value); return isNaN(d) ? value : d.toLocaleTimeString([], {hour:"2-digit", minute:"2-digit", second:"2-digit"}); }
function age(seconds) { if (seconds == null) return "—"; if (seconds < 60) return `${seconds}s`; return `${Math.floor(seconds/60)}m ${seconds%60}s`; }
function kv(items) { return items.map(([k,v]) => `<div><span>${esc(k)}</span><span>${v}</span></div>`).join(""); }
/*HELPERS_END*/
// One panel must never be able to silence the others. render() used to be a
// single unguarded chain, so a throw in an early panel left the pipeline,
// signals, chart and log tail frozen at their last values while the overview
// kept refreshing -- a stuck page that looks alive.
let LAST = null, LAST_FETCH_MS = null, FETCH_ERROR = null;
let EVIDENCE = null, EVIDENCE_LOADING = false;
let CHART_METRIC = "produce", ACTIVE_RUN = null;
let COST_HISTORY_METRIC = "cost", COST_HISTORY_RANGE = "all";
let PANEL_ERRORS = [];
const METRICS = {
  produce: {label:"Lifetime produce", unit:"", digits:0},
  produce_per_min: {label:"Production rate", unit:" / min", digits:0},
  animals: {label:"Animals", unit:"", digits:0},
  max_hunger: {label:"Maximum hunger", unit:" / 100", digits:0},
  feed: {label:"Feed reserve", unit:"", digits:0},
  coins: {label:"Coins", unit:"c", digits:0},
};
const KIND_ICON = {chicken:"🐔", pig:"🐷", beehive:"🐝", sheep:"🐑", cow:"🐄"};
function safe(label, fn) {
  try { fn(); return true; }
  catch (error) {
    PANEL_ERRORS.push(`${label}: ${error && error.message ? error.message : error}`);
    if (typeof console !== "undefined" && console.error) console.error(`panel ${label} failed`, error);
    return false;
  }
}
function render(data) {
  LAST = data; LAST_FETCH_MS = Date.now(); FETCH_ERROR = null; PANEL_ERRORS = [];
  safe("overview", () => renderOverview(data));
  safe("cost", () => renderCost(data.tokens || {}, data.cost || {}));
  safe("healing", () => renderHealing(data.heal || {}));
  safe("growth", () => renderGrowth(data.growth || {}));
  safe("pipeline", () => renderPipeline(data.pipeline || {}, data.signals || {}, data.cadence_seconds));
  // The execution trace owns its topology cache and interaction state. A poll
  // only hands it measured spans; if it failed to mount, safe() keeps that local.
  safe("trace", () => { if (window.TracePanel) window.TracePanel.update(data); });
  safe("signals", () => renderSignals(data.signals || {}, data.growth || {}));
  safe("chart", () => renderChart(data.trend || []));
  safe("log", () => { $("log").textContent = (data.log_tail || []).join("\n") || "No launchd log yet"; });
  renderHeartbeat();
}
// Re-render the time-dependent panels on a local 1s tick, not only when a poll
// lands: the pipeline's elapsed clock, step timers and next-run countdown are
// functions of now(), so they must advance even when the payload is unchanged.
function tick() {
  if (!LAST) return;
  safe("hero", () => renderHero(LAST));
  safe("pipeline", () => renderPipeline(LAST.pipeline || {}, LAST.signals || {}, LAST.cadence_seconds));
  safe("trace", () => { if (window.TracePanel) window.TracePanel.paint(); });
  safe("run-age", () => {
    const ts = LAST.latest && LAST.latest.ts ? new Date(LAST.latest.ts).getTime() : null;
    $("run-age").textContent = age(ts ? Math.max(0, Math.floor((Date.now() - ts) / 1000)) : null);
  });
  renderHeartbeat();
}
// Proof of life for the page itself, so "nothing is changing" can be told apart
// from "the poll died" or "a panel threw".
function renderHeartbeat() {
  const bits = [];
  if (FETCH_ERROR) bits.push(`<span class="bad">disconnected: ${esc(FETCH_ERROR)}</span>`);
  else if (LAST_FETCH_MS) {
    const dataAge = Math.max(0, Math.round((Date.now() - LAST_FETCH_MS) / 1000));
    bits.push(`Updated ${new Date(LAST_FETCH_MS).toLocaleTimeString()} (${dataAge}s ago)`);
  }
  bits.push("Auto-refresh: 2s, redraw 1s");
  if (PANEL_ERRORS.length) bits.push(`<span class="bad">${PANEL_ERRORS.length} panel error(s): ${esc(PANEL_ERRORS.join("; "))}</span>`);
  const html = bits.join("<br>");
  const updated = $("updated"); if (updated) updated.innerHTML = html;
  const beat = $("pipe-heartbeat"); if (beat) beat.innerHTML = html;
}
function spark(values, label) {
  values = (values || []).filter(v=>v!==null&&v!==undefined).map(Number).filter(Number.isFinite);
  if (!values.length) return `<span class="empty">no history</span>`;
  const w=180, h=26, min=Math.min(...values), max=Math.max(...values), span=Math.max(1,max-min);
  const pts=values.map((v,i) => [values.length === 1 ? w : i/(values.length-1)*w, h-3-(v-min)/span*(h-6)]);
  const line=pts.map(p => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area=`M0,${h} L${pts.map(p => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" L")} L${w},${h} Z`;
  const end=pts[pts.length-1];
  return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(label)} recent trend"><path class="fill" d="${area}" style="fill:var(--green);opacity:.09"></path><polyline class="stroke" points="${line}"></polyline><circle cx="${end[0]}" cy="${end[1]}" r="2.5"></circle></svg>`;
}
function renderHero(data) {
  const r=data.latest || {}, s=data.scene || {}, signal=data.signals || {}, rows=data.trend || [];
  const rateSec=Number.isFinite(Number(s.produce_per_sec)) ? Number(s.produce_per_sec)
    : (Number.isFinite(Number(signal.produce_per_min)) ? Number(signal.produce_per_min)/60 : 0);
  const base=Number(s.produce != null ? s.produce : r.produce);
  const stamp=s.ts || r.ts, elapsed=stamp ? Math.max(0,(Date.now()-new Date(stamp).getTime())/1000) : 0;
  // It is explicitly labelled an estimate: the authoritative score is only read
  // once per cycle, but production accrues continuously on the server.
  const cap=Math.max(0,Number(data.cadence_seconds || 180)*1.25);
  const live=Number.isFinite(base) ? base + rateSec*Math.min(elapsed,cap) : null;
  $("hero-produce").textContent=live == null ? "—" : num(Math.floor(live));
  $("hero-produce-sub").textContent=rateSec > 0 ? `+${num(Math.round(rateSec))}/s estimated between score reads` : "waiting for a measured rate";
  const perMin=Number(s.produce_per_sec)*60 || Number(signal.produce_per_min);
  $("hero-rate").textContent=Number.isFinite(perMin) ? `${num(Math.round(perMin))}/min` : "—";
  $("hero-rate-sub").textContent=r.units_per_chicken_min == null ? "score delta over the real interval" : `${fixed(r.units_per_chicken_min,4)} per animal · denominator-aware`;
  $("hero-rank").textContent=r.rank == null ? "—" : `#${r.rank}${r.rank===1 ? " 👑" : ""}`;
  const rivals=Array.isArray(data.leaderboard) ? data.leaderboard : [];
  const closest=rivals.slice().sort((a,b) => Math.abs(a.gap)-Math.abs(b.gap))[0];
  $("hero-gap").textContent=closest ? `${closest.gap>=0?"+":""}${num(closest.gap)} ahead of ${closest.name}` : "no rival score available";
  $("hero-animals").textContent=num(s.animals != null ? s.animals : r.animals);
  $("hero-herd-sub").textContent=data.growth && data.growth.saturated ? "growth stopped · marginal output measured at zero" : "growth policy is still sampling";
  const hunger=s.hunger != null ? s.hunger : r.max_hunger;
  $("hero-hunger").textContent=hunger == null ? "—" : `${hunger} / ${s.hunger_stop || 70}`;
  $("hero-hunger-sub").textContent=hunger == null ? "production stops at 70" : hunger >= (s.hunger_stop || 70) ? "production stopped" : `${(s.hunger_stop || 70)-hunger} points of headroom`;
  $("spark-produce").innerHTML=spark(rows.map(x=>x.produce),"produce");
  $("spark-rate").innerHTML=spark(rows.map(x=>x.produce_per_min),"production rate");
  $("spark-rank").innerHTML=spark(rows.map(x=>x.rank == null ? null : -x.rank),"rank");
  $("spark-animals").innerHTML=spark(rows.map(x=>x.animals),"herd");
  $("spark-hunger").innerHTML=spark(rows.map(x=>x.max_hunger),"hunger");
}
function renderScene(s, rows) {
  const kinds=Object.entries(s.by_kind || {}), idle=new Set(s.idle_kinds || []);
  const pens=kinds.map(([kind,count],ki) => {
    // Logarithmic marks: a pen with 11,000 chickens should look much fuller than
    // 100 cows without attempting to place eleven thousand DOM nodes.
    const marks=Math.max(1,Math.min(24,Math.round(Math.log10(Math.max(1,count))*6)));
    const herd=Array.from({length:marks},(_,i)=>`<i style="animation-delay:${((i+ki)%8)*-.19}s">${KIND_ICON[kind] || "🐾"}</i>`).join("");
    const dead=idle.has(kind);
    return `<div class="pen${dead?" idle":""}"><div class="pen-top"><b>${esc(kind)}</b><span class="pen-count">${num(count)}</span></div><div class="herd">${herd}</div><span class="pen-note">${dead?"measured output: zero, ever":kind==="chicken"?"effectively the entire farm's output":"measured token output"}</span></div>`;
  }).join("") || `<div class="empty">No species data</div>`;
  const feedPct=s.feed_fill==null?0:Math.round(s.feed_fill*100), hungerPct=s.hunger_fill==null?0:Math.round(s.hunger_fill*100);
  const readyMax=Math.max(1,...(rows||[]).map(x=>Number(x.ready_units)||0)), readyPct=Math.min(100,Math.round((Number(s.ready_units)||0)/readyMax*100));
  $("farm-scene").innerHTML=`<div class="scene-sky"><span class="scene-sun">${Number(s.hunger||0)>50?"🌥️":"☀️"}</span><div class="scene-rank"><b>${s.rank==null?"—":`#${s.rank}${s.rank===1?" 👑":""}`}</b><span>${num(s.produce)} lifetime produce</span></div></div><div class="pens">${pens}</div><div class="scene-ground"><div class="gauge"><label>Feed silo <b>${num(s.feed)} / ${num(s.reserve_target)}</b></label><div class="gtrack"><i style="width:${feedPct}%"></i></div><small>${feedPct}% of reserve target</small></div><div class="gauge"><label>Hunger pressure <b>${num(s.hunger)} / ${num(s.hunger_stop)}</b></label><div class="gtrack hunger"><i style="width:${hungerPct}%"></i><u style="left:100%"></u></div><small>${Math.max(0,(s.hunger_stop||70)-(s.hunger||0))} points before production stops</small></div><div class="gauge"><label>Barn backlog <b>${num(s.ready_units)}</b></label><div class="gtrack"><i style="width:${readyPct}%"></i></div><small>${s.produce_delta==null?"waiting for a score delta":`${num(s.produce_delta)} produced since last run`}</small></div></div>`;
}
function renderOverview(data) {
  const r = data.latest || {}, current = data.current || {}, ld = data.launchd || {};
  const health = data.health || "offline";
  $("health").innerHTML = `<span class="pill ${esc(health)}">${esc(health)}</span>`;
  $("last-run").textContent = r.run == null ? "—" : `#${r.run}`;
  $("run-age").textContent = age(data.latest && data.latest.ts ? Math.max(0, Math.floor((Date.now()-new Date(data.latest.ts).getTime())/1000)) : null);
  $("stage").textContent = current.active ? current.stage : "idle";
  $("cadence").textContent = `${data.cadence_seconds}s`;
  renderHero(data);
  renderScene(data.scene || {}, data.trend || []);

  $("blockers").innerHTML = (data.blockers || []).map(b => `<li class="alert ${esc(b.level)}"><span class="alert-dot"></span><span>${esc(b.text)}</span></li>`).join("");
  $("system").innerHTML = kv([
    ["cycle agent", ld.loaded ? `${esc(ld.state)}${ld.pid ? ` · pid ${ld.pid}` : ""}` : "not loaded"],
    ["supervisor", ld.supervisor?.loaded ? `${esc(ld.supervisor.state)}` : "not loaded"],
    ["agent runs", num(ld.runs)],
    ["last exit", esc(ld.last_exit || "—")],
    ["release", esc(data.release?.revision || "—")],
    ["code in this view", data.release?.diverged
      ? `<span style="color:var(--yellow)">working tree (unreleased)</span>`
      : `matches release`],
    ["server calls", num(r.calls)],
  ]);
  $("farm").innerHTML = kv([
    ["leaderboard", r.rank == null ? "—" : `#${r.rank}`],
    ["lifetime produce", num(r.produce)],
    ["animals", num(r.animals)],
    ["by kind", Object.entries(r.by_kind || {}).map(([k,v]) => `${esc(k)} ${num(v)}`).join(" · ") || "—"],
    ["coins", num(r.coins)],
    ["feed / reserve", `${num(r.feed)} / ${num(r.reserve_target)}`],
    ["hunger", r.max_hunger == null ? "—" : `${r.max_hunger} / 70`],
    ["ready produce", num(r.ready_units)],
    ["throughput", r.units_per_chicken_min == null ? "—" : `${fixed(r.units_per_chicken_min,4)} / chicken / min`],
    ["last collected", Object.entries(r.collected || {}).map(([k,v]) => `${esc(k)} ${num(v)}`).join(" · ") || "none"],
    ["adopted", `${num(r.adopted)} / ${num(r.adopt_requested)}`],
    ["cycle duration", r.duration_s == null ? "—" : `${fixed(r.duration_s,1)}s`],
  ]);

  const board = Array.isArray(data.leaderboard) ? data.leaderboard : [];
  const racers=[{name:"Nick",produce:Number(r.produce)||0,gap:0,self:true},...board]
    .sort((a,b)=>b.produce-a.produce), top=Math.max(1,...racers.map(x=>x.produce));
  $("leaderboard").innerHTML = racers.length ? `<div class="race">${racers.map((x,i)=>`<div class="racer${x.self?" self":""}"><div class="race-label"><span>${i===0?"👑 ":""}${esc(x.name)}</span><b>${num(x.produce)}</b></div><div class="race-track"><i style="width:${Math.max(2,x.produce/top*100).toFixed(1)}%"></i></div>${x.self?"":`<small>${x.gap>=0?num(x.gap)+" behind Nick":num(Math.abs(x.gap))+" ahead"}</small>`}</div>`).join("")}</div>` : `<div class="empty">No leaderboard data</div>`;
  $("intent").innerHTML = kv([
    ["status", current.active ? "active" : "idle"],
    ["stage", esc(current.stage)],
    ["started", time(current.ts)],
    ["detail", Object.entries(current.detail || {}).map(([k,v]) => `${esc(k)}=${esc(v)}`).join(" · ") || "—"],
  ]);

  renderRuns(data.trend || [], (data.tokens && data.tokens.per_run) || {});
}
function renderRuns(rows, perRun) {
  const host=$("runs"), usd=value=>value==null?"—":`$${Number(value).toFixed(4)}`;
  if (!rows.length) { host.innerHTML=`<div class="empty">No runs recorded</div>`; return; }
  const body=[];
  for (const x of rows.slice().reverse()) {
    const t=perRun[x.run] || {tokens:0,cost_usd:0}, open=String(ACTIVE_RUN)===String(x.run);
    body.push(`<tr class="runrow${open?" open":""}" data-run="${esc(x.run)}" aria-expanded="${open}"><td>#${esc(x.run)}</td><td>${time(x.ts)}</td><td>${x.rank===1?"#1 👑":"#"+esc(x.rank)}</td><td>${num(x.animals)}</td><td>${num(x.produce)}</td><td class="${x.produce_per_min!=null&&x.produce_per_min>0?"good":""}">${x.produce_per_min==null?fixed(x.units_per_chicken_min,4):num(Math.round(x.produce_per_min))+"/m"}</td><td>${esc(x.max_hunger)}</td><td>${num(x.adopted)}</td><td class="${t.tokens?"bad":"good"}">${num(t.tokens)}</td><td class="${t.cost_usd?"bad":"good"}">${usd(t.cost_usd)}</td><td class="${(x.anomalies||[]).length?"bad":"good"}">${(x.anomalies||[]).length||"OK"}</td></tr>`);
    if (open) body.push(`<tr class="rundetail"><td colspan="11">${runDetail(x)}</td></tr>`);
  }
  host.innerHTML=`<table><thead><tr><th>Run</th><th>Time</th><th>Rank</th><th>Animals</th><th>Produce</th><th>Rate</th><th>Hunger</th><th>Adopted</th><th>Tokens</th><th>Cost</th><th>Alerts</th></tr></thead><tbody>${body.join("")}</tbody></table><div class="hint">Click a run to inspect phase timing, actions and decision inputs.</div>`;
}
function runDetail(x) {
  const phases=Object.entries(x.phases||{}).sort((a,b)=>Number(b[1])-Number(a[1]));
  const max=Math.max(1,...phases.map(p=>Number(p[1])||0));
  const bars=phases.length?phases.map(([name,sec])=>`<div class="phaserow"><span>${esc(name)}</span><span class="phasebars"><i style="width:${(Number(sec)/max*100).toFixed(1)}%"></i></span><span>${fixed(sec,1)}s</span></div>`).join(""):`<div class="empty">No phase timing recorded</div>`;
  const notes=[...(x.notes||[]),...(x.notes_soft||[])];
  return `<div class="detail"><div><h3>Where the run spent time</h3>${bars}</div><div><h3>Actions</h3><div class="kv">${kv([["collected",num(x.units_collected)],["fed",num(x.fed)],["feed bought",num(x.feed_bought)],["revenue",x.revenue==null?"—":num(x.revenue)+"c"],["server calls",num(x.calls)],["verified",x.verified?"yes":"no"]])}</div></div><div><h3>Decision evidence</h3><div class="kv">${kv([["growth",esc((x.growth||{}).reason||x.adopt_stopped||"—")],["plan",Object.entries(x.plan||{}).map(([k,v])=>`${esc(k)}=${esc(v)}`).join(" · ")||"—"],["notes",notes.length?notes.map(esc).join(" · "):"none"]])}</div></div></div>`;
}
const STATUS_PILL = {running:"running", ok:"healthy", failed:"offline", idle:"waiting"};
function secs(value) { return value == null ? "—" : `${Number(value).toFixed(1)}s`; }
function renderGrowth(g) {
  const saturated = !!g.saturated;
  const recent = g.recent_units_per_min, window = g.smaller_units_per_min;
  const gain = recent && window ? ((recent / window - 1) * 100) : null;
  $("growth-verdict").innerHTML = `<span class="pill ${saturated ? "waiting" : "healthy"}">`
    + `${saturated ? "saturated · adoption stopped" : "growing"}</span>`
    + `<div class="subtitle" style="margin-top:10px">${esc(g.reason || "no measurement yet")}</div>`;
  $("growth").innerHTML = kv([
    ["adoptions allowed", g.cap == null ? "—" : num(g.cap)],
    ["herd", num(g.herd)],
    ["output now", recent == null ? "—" : `${num(recent)} units/min`],
    ["output at smaller herd", window == null ? "—" : `${num(window)} units/min`],
    ["marginal gain", gain == null ? "—" : `${gain >= 0 ? "+" : ""}${gain.toFixed(1)}% (need +10%)`],
    ["plateau", g.plateau == null ? "—" : `${num(g.plateau)} units/min`],
    ["samples", `${num(g.recent_samples)} now / ${num(g.smaller_samples)} smaller`],
    ["decided", g.changed_run == null ? "—" : `run ${esc(g.changed_run)}`],
  ]);
}
function renderSignals(s, growth) {
  const rate = s.produce_per_min, floor = s.floor;
  const stalled = s.below_floor && s.prev_below_floor;
  const watching = s.below_floor && !s.prev_below_floor;
  const level = stalled ? "error" : (watching ? "waiting" : "healthy");
  const label = stalled ? "production stalled · escalating"
    : (watching ? "one low window · watching" : "producing normally");
  $("signal-verdict").innerHTML = `<span class="pill ${level}">${esc(label)}</span>`
    + `<div class="subtitle" style="margin-top:10px">Score rate ${rate == null ? "—" : num(Math.round(rate)) + " produce/min"}`
    + ` against a ${num(Math.round(floor))}/min floor. Escalation needs two consecutive low windows — single windows are lumpy.</div>`;
  const hunger = s.hunger, stop = s.hunger_stop;
  $("signals").innerHTML = kv([
    ["score rate (this run)", rate == null ? "—" : `${num(Math.round(rate))} / min`],
    ["score rate (previous)", s.prev_produce_per_min == null ? "—" : `${num(Math.round(s.prev_produce_per_min))} / min`],
    ["floor for this herd", `${num(Math.round(floor))} / min`],
    ["hunger vs production stop", hunger == null ? "—" : `${hunger} / ${stop}`],
    ["feed / reserve", `${num(s.feed)} / ${num(s.reserve_target)}`],
    ["units collected (trailing)", num(s.units_collected)],
    ["server calls", `${num(s.calls)} at ${fixed(s.call_rate,2)}/s`],
    ["adoption", growth && growth.saturated ? `0 · saturated at ${num(growth.herd)} animals` : `allowed: ${num((growth||{}).cap)}`],
  ]);
  const soft = s.soft || [];
  if (soft.length) {
    $("signals").innerHTML += `<div class="tagrow">${soft.map(x => `<span class="tag">${esc(x)}</span>`).join("")}</div>`;
  }
}
function renderPipeline(p, signals, cadenceSeconds) {
  const steps = p.steps || [];
  const status = p.status || "idle";
  const started = p.started_ts ? new Date(p.started_ts).getTime() : null;
  const now = Date.now();
  // A running pipeline is measured against the wall clock so the active step
  // ticks upward between polls; a finished one uses its recorded end time.
  const endRef = status === "running" ? now : (p.finished_ts ? new Date(p.finished_ts).getTime() : null);
  const elapsed = started && endRef ? Math.max(0, (endRef - started) / 1000) : null;
  const done = steps.filter(s => s.status === "done").length;
  const skipped = steps.filter(s => s.status === "skipped").length;

  // Between runs the whole tab is legitimately static for ~3 of every ~4.3
  // minutes, which is indistinguishable from a dead page. So an idle pipeline
  // shows a live countdown to the next expected run, and a "running" pipeline
  // whose progress writes have stopped (a hard-killed process never calls
  // finish()) is reported as stalled instead of ticking forever.
  const cadenceMs = Number(cadenceSeconds || 0) * 1000;
  const finished = p.finished_ts ? new Date(p.finished_ts).getTime() : null;
  const updated = p.updated_ts ? new Date(p.updated_ts).getTime() : null;
  const timeoutS = Number(p.timeout_s || 0) || 240;
  const staleFor = status === "running" && updated ? (now - updated) / 1000 : null;
  const stalled = staleFor != null && staleFor > Math.max(90, timeoutS);
  const untilNext = status !== "running" && finished && cadenceMs ? (finished + cadenceMs - now) / 1000 : null;

  let pill = STATUS_PILL[status] || "waiting", label = status;
  if (stalled) { pill = "offline"; label = `stalled - no progress write for ${age(Math.round(staleFor))}`; }
  else if (status === "running") { label = `running - ${p.active || "starting"}`; }
  else if (untilNext != null && untilNext > 0) { pill = "waiting"; label = `${status} - waiting for next run`; }
  else if (untilNext != null) { pill = "warn"; label = `${status} - next run overdue by ${age(Math.abs(Math.round(untilNext)))}`; }

  $("pipe-status").innerHTML = `<span class="pill ${esc(pill)}">${esc(label)}</span>`;
  $("pipe-run").textContent = p.run == null ? "—" : `#${p.run}${p.dry ? " (dry)" : ""}`;
  $("pipe-elapsed").textContent = elapsed == null ? "—" : secs(elapsed);
  $("pipe-active").textContent = p.active ? esc(p.active) : (status === "running" ? "—" : "idle");
  $("pipe-next").textContent = status === "running" ? "after this run"
    : untilNext == null ? "—"
    : untilNext > 0 ? `in ${age(Math.ceil(untilNext))}`
    : `overdue ${age(Math.abs(Math.round(untilNext)))}`;
  $("pipe-count").textContent = `${done}/${steps.length}${skipped ? ` (+${skipped} skipped)` : ""}`;

  const budget = Number(p.budget_s || 0), timeout = Number(p.timeout_s || 0);
  const pct = budget && elapsed != null ? Math.min(100, (elapsed / budget) * 100) : 0;
  $("pipe-budget").innerHTML = kv([
    ["elapsed", elapsed == null ? "—" : secs(elapsed)],
    ["adoption budget", budget ? `${budget}s` : "—"],
    ["hard timeout", timeout ? `${timeout}s` : "—"],
    ["headroom", budget && elapsed != null ? secs(Math.max(0, budget - elapsed)) : "—"],
  ]);
  const bar = $("pipe-budget-bar");
  bar.className = `budget${budget && elapsed > budget ? " over" : ""}`;
  bar.innerHTML = `<i style="width:${pct.toFixed(1)}%"></i>`;

  const summary = p.summary || {};
  $("pipe-summary").innerHTML = Object.keys(summary).length ? kv([
    ["run", summary.run == null ? "—" : `#${summary.run}`],
    ["duration", secs(summary.duration_s)],
    ["rank", summary.rank == null ? "—" : `#${summary.rank}`],
    ["animals", num(summary.animals)],
    ["revenue", summary.revenue == null ? "—" : `${num(summary.revenue)}c`],
    ["anomalies", summary.anomalies == null ? "—" : num(summary.anomalies)],
  ]) : `<div class="empty">No completed run recorded yet</div>`;

  const baseline = p.baseline || {};
  const widest = Math.max(1, ...steps.map(s => Number(s.seconds) || 0), ...Object.values(baseline).map(Number));
  $("pipe-steps").innerHTML = steps.length ? steps.map(s => {
    const live = s.status === "active" && s.started_ts ? Math.max(0, (Date.now() - new Date(s.started_ts).getTime()) / 1000) : null;
    const shown = s.status === "active" ? live : (s.seconds == null ? null : Number(s.seconds));
    const width = shown == null ? 0 : Math.min(100, (shown / widest) * 100);
    const detail = Object.entries(s.detail || {}).filter(([k]) => k !== "seconds")
      .map(([k, v]) => `${esc(k)} <b>${esc(v)}</b>`).join(" · ");
    const note = s.note ? `<span style="color:var(--muted)">${esc(s.note)}</span>` : "";
    const base = baseline[s.name] != null ? `<span style="color:var(--muted)"> · median ${secs(baseline[s.name])}</span>` : "";
    return `<div class="pstep ${esc(s.status)}"><div class="dot"></div>`
      + `<div class="pname">${esc(s.label)}<small>${esc(s.hint || "")}</small></div>`
      + `<div class="pmeta">${detail || note || "—"}${base}${shown != null ? `<div class="pbar"><i style="width:${width.toFixed(1)}%"></i></div>` : ""}</div>`
      + `<div class="psec">${s.status === "skipped" ? "skipped" : (shown == null ? "—" : secs(shown))}</div></div>`;
  }).join("") : `<div class="empty">No pipeline data yet</div>`;
}
function renderCost(t, c) {
  const usd = value => `$${Number(value || 0).toFixed(4)}`;
  $("cost-total").textContent = usd(t.total_cost_usd);
  $("cost-total").className = `big ${Number(t.total_cost_usd || 0) > 0 ? "" : ""}`;
  $("cost-total-sub").textContent = `${num(c.ledger_runs)} runs in the ledger`
    + (c.first_ts ? ` since ${time(c.first_ts)}` : "");
  $("cost-total-tokens").textContent = num(t.total_tokens || 0);
  $("cost-total-esc").textContent = num(t.total_escalations || 0);
  $("cost-charged").textContent = num(c.charged_runs);
  $("cost-free").textContent = num(c.free_runs);
  $("cost-avoided").textContent = usd(t.avoided_cost_usd);
  $("cost-detail").innerHTML = kv([
    ["alerts healed in python", num(t.total_healed || 0)],
    ["cost per wake-up", usd(t.cost_per_escalation_usd)],
    ["escalations (24h)", num(t.window_escalations || 0)],
    ["cost (24h)", usd(t.window_cost_usd)],
    ["last 5 runs", usd(c.recent_cost_usd)],
    ["tokens, last 5 runs", num(c.recent_tokens)],
  ]);
  const rows = c.runs || [];
  $("cost-recent").innerHTML = rows.length
    ? `<table><thead><tr><th>Run</th><th>Time</th><th>Tokens in</th><th>Out</th><th>Cost</th><th>Wake-ups</th><th>Healed</th></tr></thead><tbody>`
      + rows.map(r => `<tr><td>#${esc(r.run)}</td><td>${time(r.ts)}</td><td>${num(r.tokens_in)}</td><td>${num(r.tokens_out)}</td>`
        + `<td class="${r.cost_usd ? "bad" : "good"}">${usd(r.cost_usd)}</td>`
        + `<td class="${r.escalations ? "bad" : "good"}">${r.escalations || "0"}</td>`
        + `<td class="${r.healed ? "good" : ""}">${r.healed || "—"}</td></tr>`
        + (r.alerts && r.alerts.length ? `<tr><td colspan="7" style="padding-top:0"><div class="tagrow">${r.alerts.map(a => `<span class="tag">${esc(a)}</span>`).join("")}</div></td></tr>` : "")).join("")
      + `</tbody></table>`
    : `<div class="empty">No ledger rows yet</div>`;
}
function renderHealing(h) {
  const k = h.knobs || {};
  const overrides = k.overrides || {};
  const mark = (name, value) => name in overrides ? `${value} <span style="color:var(--yellow)">(healed)</span>` : `${value}`;
  $("knobs").innerHTML = kv([
    ["call rate ceiling", mark("rate_ceiling", `${fixed(k.rate_ceiling,2)}/s`)],
    ["adopt cap (safety)", mark("adopt_cap", num(k.adopt_cap))],
    ["adopt workers", mark("adopt_workers", num(k.adopt_workers))],
    ["collect passes", mark("collect_passes", num(k.collect_passes))],
    ["individual feeds", mark("individual_feeds", num(k.individual_feeds))],
    ["active overrides", Object.keys(overrides).length ? esc(Object.keys(overrides).join(", ")) : "none (all defaults)"],
  ]);
  const classes = (h.classes || []).filter(c => c.class !== "relax");
  const relax = (h.classes || []).find(c => c.class === "relax");
  $("heal-classes").innerHTML = (classes.length
    ? classes.map(c => `<div class="healclass"><div class="top"><span class="cls">${esc(c.class)}</span>`
        + `<span class="n">${num(c.count)}× · last run ${esc(c.last_run)}</span></div>`
        + `<div class="what">${esc(c.last_action || "—")}</div>`
        + (c.alerts && c.alerts.length ? `<div class="tagrow">${c.alerts.map(a => `<span class="tag">${esc(a)}</span>`).join("")}</div>` : "")
        + `</div>`).join("")
    : `<div class="empty">Nothing has needed healing</div>`)
    + (relax ? `<div class="healclass"><div class="top"><span class="cls">relax</span><span class="n">${num(relax.count)}×</span></div>`
        + `<div class="what">Knobs stepping back toward default after quiet runs — ${esc(relax.last_action || "")}</div></div>` : "");
  const log = h.recent || [];
  $("heal-log").innerHTML = log.length ? log.map(x => `<li><span style="color:var(--muted)">${time(x.ts)} run ${esc(x.run)}</span> <strong>${esc(x.class)}</strong>: ${esc(x.action)}${x.alert ? `<div class="what" style="color:var(--muted);font-size:12.5px">${esc(x.alert)}</div>` : ""}</li>`).join("") : `<li class="empty">No remedies applied yet</li>`;
}
function renderChart(rows) {
  const host=$("chart"), meta=METRICS[CHART_METRIC]||METRICS.produce;
  const clean=(rows||[]).map(r=>({row:r,value:Number(r[CHART_METRIC])})).filter(p=>Number.isFinite(p.value));
  if (!clean.length) { host.innerHTML=`<div class="empty">No ${esc(meta.label.toLowerCase())} data in these runs</div>`; return; }
  const values=clean.map(p=>p.value), min=Math.min(...values), max=Math.max(...values), span=Math.max(1,max-min);
  const w=900,h=180,pad={l:52,r:12,t:12,b:24}, cw=w-pad.l-pad.r,ch=h-pad.t-pad.b;
  const pts=clean.map((p,i)=>({x:pad.l+(clean.length===1?cw:i/(clean.length-1)*cw),y:pad.t+(max-p.value)/span*ch,...p}));
  const poly=pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const area=`M${pad.l},${pad.t+ch} L${pts.map(p=>`${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" L")} L${pad.l+cw},${pad.t+ch} Z`;
  const grid=[0,.25,.5,.75,1].map(f=>{const y=pad.t+ch*f,v=max-span*f;return `<line class="grid-line" x1="${pad.l}" y1="${y}" x2="${pad.l+cw}" y2="${y}"></line><text class="chart-label" x="0" y="${y+4}">${esc(short(v))}</text>`}).join("");
  const dots=pts.map(p=>`<circle class="dot" cx="${p.x}" cy="${p.y}" r="2.8"><title>Run ${esc(p.row.run)} · ${meta.label}: ${num(Math.round(p.value))}${meta.unit} · ${time(p.row.ts)}</title></circle><circle class="dot-hit" cx="${p.x}" cy="${p.y}" r="9"><title>Run ${esc(p.row.run)} · ${meta.label}: ${num(Math.round(p.value))}${meta.unit}</title></circle>`).join("");
  host.innerHTML=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(meta.label)} trend"><defs><linearGradient id="areafill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#72e09a" stop-opacity=".28"></stop><stop offset="1" stop-color="#72e09a" stop-opacity="0"></stop></linearGradient></defs>${grid}<path class="area" d="${area}"></path><polyline class="line" points="${poly}"></polyline>${dots}<text class="chart-label" x="${pad.l}" y="${h-4}">run ${esc(clean[0].row.run)}</text><text class="chart-label" x="${pad.l+cw}" y="${h-4}" text-anchor="end">run ${esc(clean[clean.length-1].row.run)}</text></svg>`;
  $("chart-title").textContent=`${meta.label} trend`;
  $("chart-note").textContent=`${clean.length} runs · min ${num(Math.round(min))}${meta.unit} · latest ${num(Math.round(values[values.length-1]))}${meta.unit} · max ${num(Math.round(max))}${meta.unit}`;
  document.querySelectorAll("#chart-metrics .chip").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.metric===CHART_METRIC)));
}
function short(v) {
  const n=Number(v), a=Math.abs(n);
  if (!Number.isFinite(n)) return "—";
  if (a>=1e9) return `${(n/1e9).toFixed(1)}B`;
  if (a>=1e6) return `${(n/1e6).toFixed(1)}M`;
  if (a>=1e3) return `${(n/1e3).toFixed(a>=1e4?0:1)}K`;
  return String(Math.round(n));
}
function money(value, digits=2) {
  const n=Number(value||0);
  return `$${n.toLocaleString(undefined,{minimumFractionDigits:digits,maximumFractionDigits:digits})}`;
}
function renderCostHistory(h) {
  const stats=h.stats||{}, assumption=h.per_run_assumption||{}, points=h.points||[];
  $("hist-actual-cost").textContent=money(stats.actual_cost,2);
  $("hist-actual-cost-sub").textContent=`booked across ${num(stats.ledger_runs)} ledger runs`;
  $("hist-actual-tokens").textContent=num(stats.actual_tokens);
  $("hist-runs").textContent=num(stats.ledger_runs);
  $("hist-runs-sub").textContent=`runs ${num(stats.first_run)}-${num(stats.last_run)} · ${num(stats.zero_runs)} explicit zeros`;
  $("hist-avoided").textContent=money(stats.counterfactual_cost_mid,0);
  $("hist-avoided-sub").textContent=`range ${money(stats.counterfactual_cost_low,0)}-${money(stats.counterfactual_cost_high,0)}`;
  $("hist-reduction").textContent=stats.reduction_pct==null?"—":`${fixed(stats.reduction_pct,1)}%`;
  $("hist-wakeups").textContent=num(stats.escalations);
  $("hist-wakeups-sub").textContent=`${num(stats.healed)} alerts healed before escalation`;
  $("hist-old-monthly").textContent=money(stats.old_monthly_cost_mid,0);
  $("hist-old-monthly-range").textContent=`measured range ${money(stats.old_monthly_cost_low,0)}-${money(stats.old_monthly_cost_high,0)} at a 5-minute cadence`;
  $("hist-new-monthly").textContent=money(stats.actual_cost,2);

  const sources=h.token_sources||[], sourceMax=Math.max(1,...sources.map(x=>Number(x.tokens)||0));
  $("hist-sources").innerHTML=sources.map(x=>`<div class="source-row"><label>${esc(x.name)}</label><b>${short(x.tokens)}</b><div class="source-track"><i style="width:${Math.max(2,Number(x.tokens)/sourceMax*100).toFixed(1)}%"></i></div><small>${esc(x.note)}</small></div>`).join("")||`<div class="empty">No baseline composition</div>`;
  $("hist-changes").innerHTML=(h.changes||[]).map(x=>`<div class="change-step ${esc(x.kind)}"><span class="change-icon">${esc(x.icon)}</span><div class="change-body"><div class="change-head"><b>${esc(x.era)}</b><span>${esc(x.when)}</span></div><p>${esc(x.change)}</p><div class="change-impact">${esc(x.impact)}</div><div class="change-code">${esc(x.code)}</div></div></div>`).join("")||`<div class="empty">No execution history</div>`;

  $("hist-ledger").innerHTML=points.map(p=>`<i class="ledger-dot${p.actual_cost||p.escalations?" charged":p.healed?" healed":""}" title="Run ${esc(p.run)} · ${p.actual_tokens?num(p.actual_tokens)+" tokens":p.healed?num(p.healed)+" alert(s) healed locally":"explicit zero tokens"}"></i>`).join("");
  $("hist-ledger-stats").innerHTML=[
    ["explicit zero-cost runs",`${num(stats.zero_runs)} / ${num(stats.ledger_runs)}`],
    ["alerts healed in Python",num(stats.healed)],
    ["model wake-ups",num(stats.escalations)],
    ["exception cost avoided",money(stats.healing_cost_avoided,4)],
  ].map(([k,v])=>`<div class="metric"><label>${esc(k)}</label><strong>${esc(v)}</strong></div>`).join("");
  $("hist-disclosure").textContent=h.disclosure||"";
  renderCostHistoryChart(h);
}
function renderCostHistoryChart(h) {
  const all=h.points||[], count=COST_HISTORY_RANGE==="all"?all.length:Number(COST_HISTORY_RANGE)||all.length;
  const points=all.slice(-count), assumption=h.per_run_assumption||{};
  const host=$("hist-chart");
  if (!points.length) { host.innerHTML=`<div class="empty">No token ledger rows yet</div>`; return; }
  let actual=[], old=[], low=[], high=[], title="", actualLabel="Actual ledger", oldLabel="Old-loop midpoint", note="";
  if (COST_HISTORY_METRIC==="tokens") {
    actual=points.map(p=>Number(p.cumulative_actual_tokens)||0);
    old=points.map(p=>Number(p.counterfactual_tokens_mid)||0);
    low=points.map(p=>Number(p.counterfactual_tokens_low)||0);
    high=points.map(p=>Number(p.counterfactual_tokens_high)||0);
    title="Cumulative tokens over audited runs";
    note=`Actual ${num(actual[actual.length-1])} tokens vs ${short(old[old.length-1])} at the old-loop midpoint.`;
  } else if (COST_HISTORY_METRIC==="per_run") {
    actual=points.map(p=>Number(p.actual_cost)||0);
    old=points.map(()=>Number(assumption.cost_mid)||0);
    low=points.map(()=>Number(assumption.cost_low)||0);
    high=points.map(()=>Number(assumption.cost_high)||0);
    title="Cost per run";
    note=`Each explicit Python cycle is ${money(actual[actual.length-1],2)}; the measured old-loop range was ${money(assumption.cost_low,2)}-${money(assumption.cost_high,2)} per cycle.`;
  } else if (COST_HISTORY_METRIC==="healing") {
    actual=points.map(p=>Number(p.cumulative_healed)||0);
    old=points.map(p=>Number(p.cumulative_escalations)||0);
    low=[]; high=[]; title="Python healing vs model wake-ups";
    actualLabel="Alerts healed in Python"; oldLabel="Model wake-ups";
    note=`${num(actual[actual.length-1])} alerts healed locally; ${num(old[old.length-1])} model wake-ups booked.`;
  } else {
    actual=points.map(p=>Number(p.cumulative_actual_cost)||0);
    old=points.map(p=>Number(p.counterfactual_cost_mid)||0);
    low=points.map(p=>Number(p.counterfactual_cost_low)||0);
    high=points.map(p=>Number(p.counterfactual_cost_high)||0);
    title="Cumulative cost over audited runs";
    note=`Actual ${money(actual[actual.length-1],2)} vs old-loop midpoint ${money(old[old.length-1],0)}; measured range ${money(low[low.length-1],0)}-${money(high[high.length-1],0)}.`;
  }
  const w=900,hgt=280,pad={l:66,r:18,t:20,b:30},cw=w-pad.l-pad.r,ch=hgt-pad.t-pad.b;
  const ceiling=Math.max(1,...actual,...old,...high), x=i=>pad.l+(points.length===1?cw:i/(points.length-1)*cw), y=v=>pad.t+(ceiling-Number(v))/ceiling*(ch-3);
  const line=values=>values.map((v,i)=>`${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
  let band="";
  if (low.length&&high.length) band=`<path class="cost-band" d="M${low.map((v,i)=>`${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" L")} L${high.slice().reverse().map((v,j)=>{const i=high.length-1-j;return `${x(i).toFixed(1)},${y(v).toFixed(1)}`}).join(" L")} Z"></path>`;
  const grid=[0,.25,.5,.75,1].map(f=>{const v=ceiling*(1-f),yy=pad.t+ch*f;return `<line class="grid-line" x1="${pad.l}" y1="${yy}" x2="${w-pad.r}" y2="${yy}"></line><text class="chart-label" x="0" y="${yy+4}">${esc(historyValue(v,COST_HISTORY_METRIC))}</text>`}).join("");
  const sampleEvery=Math.max(1,Math.floor(points.length/12));
  const dots=points.map((row,i)=>i%sampleEvery===0||i===points.length-1?`<circle class="cost-point" cx="${x(i)}" cy="${y(actual[i])}" r="4"><title>Run ${esc(row.run)} · actual ${historyValue(actual[i],COST_HISTORY_METRIC)}</title></circle><circle class="cost-point old" cx="${x(i)}" cy="${y(old[i])}" r="3"><title>Run ${esc(row.run)} · counterfactual ${historyValue(old[i],COST_HISTORY_METRIC)}</title></circle>`:"").join("");
  const gateIndex=points.findIndex(row=>Number(row.run)===46), marker=gateIndex>=0?`<line class="cost-marker" x1="${x(gateIndex)}" y1="${pad.t}" x2="${x(gateIndex)}" y2="${pad.t+ch}"></line><text class="chart-label" x="${x(gateIndex)+5}" y="${pad.t+10}">run 46 · growth gate</text>`:"";
  host.innerHTML=`<svg viewBox="0 0 ${w} ${hgt}" role="img" aria-label="${esc(title)}">${grid}${band}${marker}<polyline class="cost-old${COST_HISTORY_METRIC==="healing"?" cost-wakeup":""}" points="${line(old)}"></polyline><polyline class="cost-actual" points="${line(actual)}"></polyline>${dots}<text class="chart-label" x="${pad.l}" y="${hgt-5}">run ${esc(points[0].run)}</text><text class="chart-label" x="${w-pad.r}" y="${hgt-5}" text-anchor="end">run ${esc(points[points.length-1].run)}</text></svg>`;
  $("hist-chart-title").textContent=title;
  $("hist-chart-note").textContent=note;
  $("hist-legend").innerHTML=`<span><i></i>${esc(actualLabel)}</span><span><i class="${COST_HISTORY_METRIC==="healing"?"wakeup":"old"}"></i>${esc(oldLabel)}</span>${low.length?`<span><i class="old band"></i>Measured low-high range</span>`:""}`;
  document.querySelectorAll("#hist-metrics .chip").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.hmetric===COST_HISTORY_METRIC)));
  document.querySelectorAll("#hist-range .chip").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.hrange===COST_HISTORY_RANGE)));
}
function historyValue(value, metric) {
  if (metric==="cost"||metric==="per_run") return money(value,metric==="per_run"?2:0);
  if (metric==="tokens") return short(value);
  return num(Math.round(Number(value)||0));
}
function renderEvidence(ev) {
  if (!ev || ev.error) {
    $("ev-ceiling-claim").textContent=`Evidence unavailable: ${ev&&ev.error?ev.error:"empty response"}`;
    return;
  }
  renderCostHistory(ev.cost_history||{});
  const c=ev.ceiling||{}, buckets=c.buckets||[];
  $("ev-ceiling-claim").textContent=c.claim||"No claim recorded.";
  $("ev-ceiling-chart").innerHTML=evidenceChart(buckets,c.regression_from||8000);
  const below=c.regression_below||{}, above=c.regression||{};
  $("ev-ceiling-stats").innerHTML=[
    ["samples",num(c.samples)],
    ["growth slope below 8k",below.slope==null?"—":`${below.slope>=0?"+":""}${fixed(below.slope*1000,1)} units/min per +1k animals`],
    ["slope above 8k",above.slope==null?"—":`${above.slope>=0?"+":""}${fixed(above.slope*1000,1)} units/min per +1k animals`],
    ["correlation above 8k",above.r==null?"—":fixed(above.r,3)],
    ["plateau median",c.plateau_median==null?"—":`${num(Math.round(c.plateau_median))}/min`],
  ].map(([k,v])=>`<div class="metric"><label>${esc(k)}</label><strong style="font-size:15px">${esc(v)}</strong></div>`).join("");
  $("ev-ceiling-method").textContent=`Each point is a herd-size bucket, not a cherry-picked run. Earlier rates are reconstructed from lifetime-score deltas over real wall-clock intervals; later rates are recorded directly. Regression above ${num(c.regression_from)} animals asks the decision-relevant question: did the marginal herd buy output?`;

  const sp=ev.species||{}, species=sp.table||[], max=Math.max(1,...species.map(x=>Number(x.collected)||0));
  $("ev-species").innerHTML=species.map(x=>`<div class="bar"><span>${KIND_ICON[x.kind]||"🐾"} ${esc(x.kind)}</span><span class="bartrack"><i class="${x.collected?"":"zero"}" style="width:${x.collected?Math.max(1,x.collected/max*100).toFixed(2)+"%":"2px"}"></i></span><span>${num(x.collected)} ${esc(x.produce)}</span></div>`).join("")||`<div class="empty">No species measurements</div>`;
  $("ev-species-note").textContent=`${num(sp.runs_observed)} runs observed. Share of measured output, not ownership, drives the bars. Sheep and cows remain at zero despite 100 of each; chickens account for effectively the entire farm.`;

  const crops=ev.crops||{}, collection=ev.collection||{};
  $("ev-dead-ends").innerHTML=`<div class="verdictbox bad"><b>🌾 Crops: retired</b>${esc(crops.claim||"No crop result")}</div><div class="verdictbox bad" style="margin-top:9px"><b>🧺 Collected units as the score: retired</b>${esc(collection.claim||"No collection result")}</div><div class="verdictbox good" style="margin-top:9px"><b>✅ What replaced both</b>${esc(collection.consequence||"Measure lifetime score and keep the herd fed.")}</div>`;

  const det=ev.detectors||[];
  $("ev-detectors").innerHTML=det.map(d=>`<div class="verdictbox" style="margin-bottom:9px"><b>${esc(d.name)}</b><div class="method"><span class="bad">Was:</span> ${esc(d.was)}</div><div class="method"><span class="good">Now:</span> ${esc(d.fix)}</div></div>`).join("")||`<div class="empty">No detector history</div>`;
  $("ev-timeline").innerHTML=(ev.timeline||[]).map(x=>`<div class="tl ${esc(x.kind)}"><span class="tl-run">Run ${esc(x.run)} · ${esc(x.kind)}</span><b>${esc(x.title)}</b><span>${esc(x.text)}</span></div>`).join("")||`<div class="empty">No findings yet</div>`;

  const slider=$("ev-runs-slider");
  slider.oninput=()=>paintCostCounterfactual(ev.cost||{},Number(slider.value));
  paintCostCounterfactual(ev.cost||{},Number(slider.value));
}
function evidenceChart(buckets, divider) {
  if (!buckets.length) return `<div class="empty">No comparable runs yet</div>`;
  const w=900,h=240,p={l:56,r:16,t:16,b:30}, maxX=Math.max(...buckets.map(b=>Number(b.herd)||0)), maxY=Math.max(1,...buckets.map(b=>Number(b.units_per_min)||0));
  const x=v=>p.l+Number(v)/maxX*(w-p.l-p.r), y=v=>p.t+(maxY-Number(v))/maxY*(h-p.t-p.b);
  const grid=[0,.25,.5,.75,1].map(f=>`<line class="grid-line" x1="${p.l}" y1="${y(maxY*f)}" x2="${w-p.r}" y2="${y(maxY*f)}"></line><text class="chart-label" x="0" y="${y(maxY*f)+4}">${short(maxY*f)}/m</text>`).join("");
  const line=buckets.map(b=>`${x(b.herd)},${y(b.units_per_min)}`).join(" ");
  const pts=buckets.map(b=>`<circle class="pt ${b.herd>=divider?"plateau":""}" cx="${x(b.herd)}" cy="${y(b.units_per_min)}" r="${Math.max(4,Math.min(9,3+Math.sqrt(b.samples||1)))}"><title>${esc(b.label)} animals · ${num(b.units_per_min)}/min · ${num(b.samples)} runs</title></circle>`).join("");
  return `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Herd size versus production rate">${grid}<polyline class="line" points="${line}"></polyline>${pts}<line class="divider" x1="${x(divider)}" y1="${p.t}" x2="${x(divider)}" y2="${h-p.b}"></line><text class="chart-label" x="${x(divider)+5}" y="${p.t+9}">8k: test marginal herd here</text><text class="chart-label" x="${p.l}" y="${h-5}">0 animals</text><text class="chart-label" x="${w-p.r}" y="${h-5}" text-anchor="end">${short(maxX)} animals</text></svg>`;
}
function paintCostCounterfactual(cost, runsPerDay) {
  const old=cost.llm_era||{}, inAvg=(Number(old.input_tokens_low||0)+Number(old.input_tokens_high||0))/2;
  const perRun=inAvg/1e6*Number(cost.price_per_mtok_in||0)+Number(old.thinking_tokens||0)/1e6*Number(cost.price_per_mtok_out||0);
  const monthly=perRun*runsPerDay*30;
  $("ev-runs-label").textContent=num(runsPerDay);
  $("ev-old-cost").textContent=`$${monthly.toLocaleString(undefined,{maximumFractionDigits:0})}`;
  $("ev-new-cost").textContent="$0.00";
  $("ev-cost-note").textContent=`At ${num(runsPerDay)} runs/day, the measured old-loop midpoint (${num(Math.round(inAvg))} input/tool tokens plus ${num(old.thinking_tokens)} thinking/output tokens per run) implies about $${perRun.toFixed(2)} per cycle. Current routine cycles write an explicit zero-token ledger row.`;
}
async function loadEvidence() {
  if (EVIDENCE || EVIDENCE_LOADING) return;
  EVIDENCE_LOADING=true;
  try {
    const response=await fetch(`/api/evidence?t=${Date.now()}`,{cache:"no-store"});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    EVIDENCE=await response.json();
    safe("findings",()=>renderEvidence(EVIDENCE));
  } catch(error) {
    safe("findings",()=>renderEvidence({error:error&&error.message?error.message:String(error)}));
  } finally { EVIDENCE_LOADING=false; }
}
async function load() {
  try {
    const response = await fetch(`/api/state?t=${Date.now()}`, {cache:"no-store"});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    render(await response.json());
    if (!EVIDENCE) loadEvidence();
  } catch (error) {
    // Keep polling: a monitor restart or a half-written read must not end the
    // refresh loop. The heartbeat shows the page is trying, not dead.
    FETCH_ERROR = error && error.message ? error.message : String(error);
    $("health").innerHTML = `<span class="pill offline">disconnected</span>`;
    renderHeartbeat();
  }
}
function activateTab(name, writeHash) {
  const allowed=["overview","pipeline","cost","history","findings","game"];
  if (!allowed.includes(name)) name="overview";
  document.querySelectorAll("nav.tabs button").forEach(b=>b.setAttribute("aria-selected",String(b.dataset.tab===name)));
  document.querySelectorAll(".tab").forEach(panel=>{panel.hidden=panel.id!==`tab-${name}`;});
  if (writeHash && typeof location!=="undefined" && location.hash!==`#${name}`) location.hash=name;
  if ((name==="findings"||name==="history") && EVIDENCE) safe(name,()=>renderEvidence(EVIDENCE));
  // Coop Rush watches its own panel's hidden flag: an idle game must keep
  // simulating in the background, it just stops painting.
  if (window.CRUI && name==="game") window.CRUI.paint();
  // Repaint on entry so the active span's local clock is current immediately.
  if (window.TracePanel && name==="pipeline") window.TracePanel.paint();
}
document.querySelectorAll("nav.tabs button").forEach(button=>button.addEventListener("click",()=>activateTab(button.dataset.tab,true)));
if (typeof document.addEventListener==="function") document.addEventListener("click",event=>{
  const metric=event.target && event.target.closest ? event.target.closest("#chart-metrics [data-metric]") : null;
  if (metric) { CHART_METRIC=metric.dataset.metric; if (LAST) safe("chart",()=>renderChart(LAST.trend||[])); return; }
  const hmetric=event.target && event.target.closest ? event.target.closest("#hist-metrics [data-hmetric]") : null;
  if (hmetric) { COST_HISTORY_METRIC=hmetric.dataset.hmetric; if (EVIDENCE) safe("history chart",()=>renderCostHistoryChart(EVIDENCE.cost_history||{})); return; }
  const hrange=event.target && event.target.closest ? event.target.closest("#hist-range [data-hrange]") : null;
  if (hrange) { COST_HISTORY_RANGE=hrange.dataset.hrange; if (EVIDENCE) safe("history range",()=>renderCostHistoryChart(EVIDENCE.cost_history||{})); return; }
  const row=event.target && event.target.closest ? event.target.closest("tr.runrow") : null;
  if (row) { ACTIVE_RUN=String(ACTIVE_RUN)===String(row.dataset.run)?null:row.dataset.run; if (LAST) renderRuns(LAST.trend||[],(LAST.tokens&&LAST.tokens.per_run)||{}); return; }
  // Trace interactions are delegated by the explorer on its own stable root.
});
if (typeof window.addEventListener==="function") {
  window.addEventListener("hashchange",()=>activateTab((location.hash||"").slice(1),false));
  window.addEventListener("keydown",event=>{
    if (event.metaKey||event.ctrlKey||event.altKey) return;
    if (event.target && /input|textarea|select/i.test(event.target.tagName||"")) return;
    const map={o:"overview",p:"pipeline",c:"cost",t:"history",f:"findings",g:"game"}, tab=map[String(event.key||"").toLowerCase()];
    if (tab) activateTab(tab,true);
  });
}
if (typeof location!=="undefined" && location.hash) activateTab(location.hash.slice(1),false);

// The trace explorer is evaluated BEFORE the polling bootstrap: mount() must
// exist by the time the first payload lands, and a throw here must not be able to
// stop load() from ever running. Hence the try/catch and guarded mount.
try {
/*TRACE_JS_START*/
__TRACE_JS__
/*TRACE_JS_END*/
  if (window.TracePanel) window.TracePanel.mount({rootId:"trace-explorer"});
} catch (error) {
  if (typeof console !== "undefined" && console.error) console.error("trace panel failed to load", error);
  const stage = document.getElementById("trace-explorer");
  if (stage) stage.innerHTML = `<div class="te-empty">The execution trace failed to load: ${esc(error && error.message ? error.message : error)}<br>Step timings below are unaffected.</div>`;
}

// The dashboard's own refresh is started BEFORE the game bundle is evaluated.
// It used to come last, so any top-level throw in the game (or a failed game
// bundle substitution) stopped load() and setInterval from ever running and
// froze every tab at "connecting". Do not write the game placeholder token in
// a comment here: it is substituted textually, so a mention becomes a copy.
load(); setInterval(load, 2000); setInterval(tick, 1000);

try {
/*GAME_JS_START*/
__GAME_JS__
/*GAME_JS_END*/
} catch (error) {
  // The game is a tab, not the product. It must not be able to break monitoring.
  if (typeof console !== "undefined" && console.error) console.error("Coop Rush failed to load", error);
  const panel = document.getElementById("tab-game");
  if (panel) panel.innerHTML = `<div class="card"><h2>Coop Rush</h2><div class="empty">The game failed to load: ${esc(error && error.message ? error.message : error)}<br>The dashboard is unaffected.</div></div>`;
}
</script></body></html>"""


# Composed once at import: the page is static apart from the /api/state poll, and
# an import-time build keeps HTML a plain module constant for anything that reads it.
HTML = (
    HTML_TEMPLATE.replace("__TRACE_CSS__", TRACE_CSS)
    .replace("__GAME_CSS__", GAME_CSS)
    .replace("__GAME_MARKUP__", GAME_MARKUP)
    .replace("__TRACE_JS__", TRACE_JS)
    .replace("__GAME_JS__", GAME_JS)
)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path == "/api/state":
            payload = json.dumps(snapshot(), separators=(",", ":")).encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
        elif path == "/api/topology":
            # The call graph is a function of the source on disk, so it is fetched
            # once and re-fetched only when the fingerprint in /api/state changes.
            # Serving it inside the 2s poll would re-send ~25KB of identical graph
            # 1,800 times an hour.
            try:
                graph: Dict[str, Any] = dict(topology.cached_graph())
                graph["fingerprint"] = (snapshot_trace_fingerprint())
            except Exception as exc:  # noqa: BLE001
                graph = {"error": str(exc)[:200], "nodes": [], "edges": []}
            payload = json.dumps(graph, separators=(",", ":")).encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
        elif path == "/api/evidence":
            # Its own endpoint because none of it changes at the 2s poll rate, and
            # folding it into /api/state would re-send several KB of unchanged
            # findings 1,800 times an hour.
            try:
                body: Dict[str, Any] = evidence.report()
            except Exception as exc:  # noqa: BLE001
                body = {"error": str(exc)[:200]}
            payload = json.dumps(body, separators=(",", ":")).encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
        elif path in ("/", "/index.html"):
            payload = HTML.encode("utf-8")
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            # The page is composed at import time from game/ and dashboard/ assets,
            # so restarting the monitor after editing them changes this document.
            # Without this header a browser happily keeps the previous bundle and
            # the new code appears not to work at all, which is exactly how stale
            # embedded assets look while iterating on the dashboard.
            self.send_header("Cache-Control", "no-store")
        else:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:
        return


def _serve(port: int, search: int) -> Optional[ThreadingHTTPServer]:
    """Bind the first free port at or after `port`.

    8765 is a popular number: it was already taken by an unrelated local app on
    this machine. Dying with "Address already in use" is a worse answer than
    landing on 8766 and saying so.
    """
    last: Optional[OSError] = None
    for candidate in range(port, port + max(1, search) + 1):
        try:
            return ThreadingHTTPServer(("127.0.0.1", candidate), Handler)
        except OSError as exc:
            last = exc
            continue
    if last:
        print(f"could not bind {port}-{port + search}: {last}", file=sys.stderr)
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="Read-only Farm Friends monitor")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-open", action="store_true", help="do not open a browser")
    parser.add_argument(
        "--strict-port", action="store_true", help="fail instead of trying the next free port"
    )
    args = parser.parse_args()
    # The farm modules address state with project-relative paths.
    os.chdir(PROJECT)
    server = _serve(args.port, 0 if args.strict_port else PORT_SEARCH)
    if server is None:
        return 1
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/"
    if port != args.port:
        print(f"port {args.port} was busy; using {port}")
    print(f"Farm monitor: {url}")
    print("Read-only; press Ctrl-C to stop.")
    if not args.no_open:
        threading.Timer(0.25, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nFarm monitor stopped.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
