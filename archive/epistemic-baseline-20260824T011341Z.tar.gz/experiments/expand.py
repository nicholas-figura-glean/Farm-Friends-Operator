#!/usr/bin/env python3
"""Bounded expansion sprint: convert surplus coins into herd, fast.

Why this exists as a separate job rather than a bigger adoption step in the
cycle: the 150s cycle budget is spent almost entirely on two inherently slow
server calls (collect ~55s, bulk feed ~77s), which leaves ~8s for adoption, or
about 14 animals per run. That is not a rate limit - the cycle only issues ~27
calls in 150s, well under the ~5/s the server tolerates - it is latency. So the
way to grow is a second process that does nothing but adopt.

Guardrails, in order of importance:
  1. Never spend the feed reserve. Coins are floored at the reserve needed to
     keep the TARGET herd fed for FEED_BUFFER_MIN_MINUTES.
  2. Never outrun the server. Rate is capped below the measured ceiling so the
     concurrent cycle keeps its headroom.
  3. Always stoppable. --max-adopt and --max-seconds both bound the run, and the
     farm is re-read at the end so the report reflects reality.

It deliberately does NOT take the cycle lock: it only adopts, and adoption is
additive. It never feeds, sells, or collects.

    python3 experiments/expand.py --target 30000 --max-seconds 900
"""

from __future__ import annotations

import argparse
import errno
import fcntl
import os
import queue
import signal
import sys
import threading
import time

PROJECT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT)

from farm import mcp, parse, rules  # noqa: E402
from farm.mcp import Client, McpError, ToolError  # noqa: E402

LOCK = os.path.join(PROJECT, "state", ".expand.lock")


def _lock():
    """Exactly one sprint at a time.

    Without this the agent was self-destructive. A sprint can stall on a slow
    call (MCP timeout is 120s and retries 3 times), so it outlives its own
    --max-seconds deadline, which is only checked between calls. launchd then
    fires the next sprint on schedule, and the two overlap: 16 workers becomes
    32, then 48. The server started returning 504 Gateway Timeout, the CYCLE
    began failing and skipping, and herd growth collapsed to +25 animals in 13
    minutes - worse than running nothing at all.
    """
    os.makedirs(os.path.dirname(LOCK), exist_ok=True)
    fh = open(LOCK, "w")
    try:
        fcntl.flock(fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except IOError as exc:
        if exc.errno in (errno.EAGAIN, errno.EACCES):
            print("EXPAND skipped: previous sprint still running")
            sys.exit(0)
        raise
    return fh


def _arm_watchdog(seconds: int) -> None:
    """Guarantee the process exits, even blocked inside a socket read."""

    def _fire(signum, frame):  # noqa: ANN001
        print("EXPAND hard timeout after %ds - exiting" % seconds)
        os._exit(0)

    signal.signal(signal.SIGALRM, _fire)
    signal.alarm(seconds)


def affordable(coins: int, herd: int, feed_on_hand: int = 0) -> int:
    """How many animals we can adopt AND still keep fed.

    Delegates to rules.affordable_adoptions so the floor is testable and lives
    with the rest of the strategy. See that docstring: the version that lived
    here charged coins for the reserve of the whole herd, ignoring the feed
    already in the barn, and so reported 1,048 affordable animals at run 379
    while 1.9M coins sat idle next to 538 minutes of feed.
    """
    return rules.affordable_adoptions(coins, herd, feed_on_hand)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=int, default=30000, help="herd size to build toward")
    ap.add_argument("--max-seconds", type=float, default=900.0)
    ap.add_argument("--rate", type=float, default=3.0, help="calls/s, below the 5/s ceiling")
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    handle = _lock()  # noqa: F841 - held for the process lifetime
    # Hard ceiling well inside the 300s launchd interval, so a sprint can never
    # still be alive when the next one is due.
    _arm_watchdog(int(args.max_seconds) + 20)

    mcp.LIMITER.set_rate(min(args.rate, rules.MAX_CALLS_PER_SECOND))
    c = Client()
    farm = parse.parse_farm(c.call("list_farm"))
    can_afford = affordable(farm.coins, farm.animal_count, farm.feed)

    # Never adopt past the herd we can still feed in time. `feed_animals("all")`
    # is one gateway-limited call, so past ~25,000 animals it reaches a shrinking
    # fraction of the herd and the unfed tail's hunger climbs with herd size
    # (measured: max_hunger = 0.000614*herd - 7.14). Production stops outright at
    # ~125,700 animals, and this agent was being launched with --target 250000 -
    # twice the wall. Past the ceiling every coin buys an animal that produces
    # nothing and still has to be fed, which is the run-291 starvation reached
    # from the opposite direction.
    ceiling = rules.hunger_safe_herd_ceiling()
    target = min(args.target, ceiling)
    room = max(0, target - farm.animal_count)
    want = min(room, can_afford)

    print("herd=%d coins=%d feed=%d" % (farm.animal_count, farm.coins, farm.feed))
    if target < args.target:
        print(
            "target capped %d -> %d: hunger-safe ceiling (proj max hunger %.0f, "
            "production stops at %d)"
            % (args.target, target, rules.projected_max_hunger(target), rules.HUNGER_STOP)
        )
    print(
        "target=%d (room %d)  affordable %d (keeps %d feed/animal reserved)  -> adopt %d %ss"
        % (target, room, can_afford, rules.FEED_PER_ANIMAL_RESERVE, want,
           rules.PRIMARY_KIND)
    )
    if args.dry_run or want <= 0:
        return 0

    work = queue.Queue()
    for _ in range(want):
        work.put(1)
    done = {"ok": 0, "fail": 0}
    lock = threading.Lock()
    stop = threading.Event()
    deadline = time.time() + args.max_seconds

    def worker(endpoint):
        client = Client(endpoint)
        while not stop.is_set() and time.time() < deadline:
            try:
                work.get_nowait()
            except queue.Empty:
                return
            try:
                client.call("adopt_animal", kind=rules.PRIMARY_KIND)
                with lock:
                    done["ok"] += 1
            except (ToolError, McpError) as exc:
                with lock:
                    done["fail"] += 1
                    if done["fail"] <= 3:
                        print("  adopt failed: %s" % str(exc)[:120])
                    too_many = done["fail"] > 25
                # Out of coins or sustained pushback: stop the sprint rather than
                # hammering a server that is already refusing.
                if "coin" in str(exc).lower() or too_many:
                    stop.set()
                    return

    threads = [
        threading.Thread(target=worker, args=(c.endpoint,), daemon=True)
        for _ in range(max(1, args.workers))
    ]
    started = time.time()
    for t in threads:
        t.start()
    while any(t.is_alive() for t in threads):
        time.sleep(5)
        with lock:
            ok, fail = done["ok"], done["fail"]
        print("  adopted %d (fail %d) %.1f/s" % (ok, fail, ok / max(1e-6, time.time() - started)))
    for t in threads:
        t.join(timeout=5)

    final = parse.parse_farm(c.call("list_farm"))
    print(
        "DONE adopted=%d failed=%d in %.0fs | herd %d -> %d | coins %d -> %d | feed %d"
        % (done["ok"], done["fail"], time.time() - started, farm.animal_count,
           final.animal_count, farm.coins, final.coins, final.feed)
    )
    buffer_min = rules.feed_buffer_minutes(final.feed, final.animal_count)
    print("feed runway now %.0f min (floor %d)" % (buffer_min, rules.FEED_BUFFER_MIN_MINUTES))
    if buffer_min < rules.FEED_BUFFER_MIN_MINUTES:
        print("WARNING: runway below floor - the next cycle must top up feed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
