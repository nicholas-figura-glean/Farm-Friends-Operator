# Farm Friends operator

Deterministic Python runs the farm. An LLM is only involved when something breaks.

## Why

The loop used to be executed by an LLM automation every 5 minutes. Measured over
46 runs on 2026-08-20, each run cost roughly **150k-600k billed input tokens**:
62k/run of raw tool text, 59k of thinking, re-sent across ~21 assistant turns.
The largest single input was `list_farm`, a plain-text wall that grows ~65 bytes
per animal and was read three or four times per run. At 3,000 animals that alone
is ~200KB per run.

None of that reasoning was necessary. The strategy is arithmetic against fixed
thresholds, so it lives in `farm/rules.py` and runs for free.

| | before | after |
|---|---|---|
| per cycle | 150k-600k billed input tokens | **0** |
| cadence | every 300s | every 180s |
| supervision | the loop itself | `--alerts`, one line, hourly |
| scaling with herd size | re-read and re-reasoned every turn | parsed in Python, never surfaced |

## Layout

```
run.py                 --cycle --dry-run --supervise --heal-status --alerts --review N
                       --health --journal --self-test
experiments/           one-off measured probes, never on the cycle path
farm/mcp.py            JSON-RPC over Streamable HTTP, stdlib only, global rate limiter,
                       endpoint scrubbing
farm/parse.py          plain text -> dataclasses; raises ParseDrift on any unknown line
farm/rules.py          ALL strategy: thresholds, prices, reserve, budget, rate, engine
farm/growth.py         is a bigger herd still buying output? (adoption gate)
farm/evidence.py       measured findings as JSON: ceiling, species, dead ends, cost
farm/cycle.py          the loop, intent log, parallel adoption, backstop mode
farm/watch.py          anomaly detectors; the only thing that wakes an LLM
farm/heal.py           deterministic remedies per alert class + escalation policy
farm/scheduler.py      launchd liveness and repair for both agents
farm/progress.py       live pipeline position for the dashboard
farm/topology.py       static call graph (steps -> functions -> MCP tools), read from farm/*.py with ast
farm/tokens.py         token/cost ledger for the exception path
farm/report.py         compact rendering (cycle summary, review, dry-run plan)
farm/journal.py        generates journal entries and the alert queue
farm/release.py        release identity and staleness detection
monitor.py             read-only local dashboard (python3 monitor.py)
POSTMORTEM-run291.md   how first place was lost and what was changed; read this
                       before touching feed, the growth gate, or the healer
POSTMORTEM-run377.md   how it was nearly lost again: three throttles aimed at the
                       wrong variable, the collect timeout wall, and the measured
                       proof that output is linear in herd size. Read this before
                       touching transport errors, the reserve alert, or collect.
dashboard/             2D trace explorer, tool matrix, styles and headless tests
game/                  Coop Rush: engine, UI, styles, markup and headless tests
deploy/release.sh      publish an immutable release, flip the pointer atomically
deploy/test_dashboard.sh  topology, MCP spans, trace model and page-render suites
deploy/install.sh      install/remove BOTH launchd agentsreleases/<rev>/        immutable published copies; `release` symlinks to the live one
state/history.ndjson   one machine-readable row per run
state/alerts.ndjson    anomaly queue consumed by `--alerts`
state/heal.json        supervisor knobs (only farm/heal.py writes this)
state/heal.ndjson      every remedy the supervisor applied
state/progress.json    live pipeline position (which step, how long, what it found)
state/tool_calls.ndjson paired start/end spans for every MCP boundary call
state/growth.json      growth verdict + the output plateau recorded at saturation
state/tokens.ndjson    token/cost ledger; routine runs record an explicit zero
state/raw/latest/      last raw responses, overwritten each run (post-mortem only)
state/intents.ndjson   written before and after every mutating call
```

Exit codes: `0` routine, `3` needs attention, `4` hard failure.

## Operating it

```bash
python3 run.py --dry-run      # read live state, print the decision, mutate nothing
python3 run.py --alerts       # only what survived healing; costs tokens when it prints
python3 run.py --supervise     # the self-healing pass (what the 60s agent runs)
python3 run.py --heal-status    # active knobs, recent remedies, token cost
python3 run.py --review 20    # trend across recent runs
python3 run.py --self-test    # 80 checks: parsers, rules, detectors, healing, cost, progress, growth
deploy/release.sh             # publish the working tree (required after ANY edit)
deploy/install.sh             # install/refresh both agents
deploy/install.sh --uninstall # stop the schedule (boots out the supervisor first)
python3 monitor.py             # open the read-only live dashboard
python3 monitor.py --no-open    # serve it without opening a browser
python3 monitor.py --port 8877  # if 8765 is taken (it also auto-falls-back)
deploy/open_monitor.py          # reuse a running dashboard, else start one, then open it
deploy/export_game.py           # write coop-rush.html, a standalone playable file
deploy/test_game.sh             # run the game's headless test suites
deploy/test_dashboard.py        # 58 checks: panels, liveness, visuals, cost history, findings
python3 deploy/test_evidence.py  # 25 checks: derived findings and cost history stay ledger-faithful
deploy/make_app.sh              # build double-clickable Coop Rush.app / Farm Monitor.app
```

### Running the dashboard and the game

There is no native app and no build step: the dashboard is a local Python server
and the game is a dependency-free DOM app on one of its tabs. Three ways in, in
order of effort:

| | what it does |
| --- | --- |
| `python3 monitor.py` | serves the dashboard and opens it; the game is the **Coop Rush** tab |
| `python3 deploy/export_game.py` then open `coop-rush.html` | the game alone, one self-contained file, no server and no network |
| `deploy/make_app.sh` | `apps/Coop Rush.app` and `apps/Farm Monitor.app`, double-clickable in Finder |

The `.app` bundles are real bundles (Info.plist + an executable) but not native
code: one re-exports and opens the HTML, the other calls `deploy/open_monitor.py`.
Nothing depends on them.

Two port details, both learned the hard way on this machine:

- **8765 was already taken** by an unrelated local app, so `monitor.py` now binds
  the first free port at or after the one requested and prints where it landed
  (`--strict-port` to refuse instead).
- **"Does something answer on 8765?" is the wrong liveness check.** The squatter
  returned HTTP 200 on `/`, so a status-code check reused someone else's page and
  never started the monitor. `deploy/open_monitor.py` identifies our dashboard by
  the `app: farmfriends-monitor` marker in `/api/state`, which is why running it
  twice reuses one server instead of starting a second.

The monitor is local and read-only, with six tabs. Use the tabs or the keyboard:
`O` overview, `P` pipeline, `C` cost, `T` token history, `F` findings, `G` game.

- **Overview** - a live-estimated hero counter with sparklines; a farm scene whose
  pens, silo, hunger pressure and barn are all real telemetry; a leaderboard race;
  six switchable trend metrics; both agents' launchd status; current intent;
  growth policy; and recent runs. Click a run to expand its phase timing, actions
  and the evidence behind its decisions.
- **Pipeline** - opens with a two-part **execution trace**, using the same model
  as production tracing tools instead of asking one spatial graph to explain
  everything. **Run trace** is a nested waterfall: the fourteen measured step
  spans share one clock, and every observed MCP call is grouped beneath its
  parent step. Repeated calls (for example 40 adoptions) occupy one lane with 40
  individually inspectable ticks, not 40 noisy rows. **Tool matrix** is the whole
  system at a glance: pipeline steps are rows, the 11 external MCP tools are
  columns, a hollow cell means the code can reach that tool, and a numbered green
  cell is how many calls this run actually made. A blank is meaningful: `plan`
  and `finish` have no server path. Selecting a step, call lane or matrix cell
  opens its measured start/duration/status, arguments, bounded result or error,
  and the source-derived Python path. Functions are explicitly labelled **static
  reachability, not measured time**; the UI never invents function spans.
- Below it, the same run step by step: status per step
  (pending / active / done / skipped / failed), duration against the recent
  median for that step, what each step found (units collected, revenue, adopted
  vs requested, rank), the reason any step was skipped, and elapsed time against
  the cycle budget and hard timeout. A run occupies ~80s of every ~260s, so
  between runs the tab counts down to the next expected start (last finish +
  cadence) and flags it when that is overdue; a run whose progress writes have
  stopped reads **stalled** rather than ticking forever, which is what a
  hard-killed process leaves behind. Plus **what the run is judged on**: the score
  rate against its floor, whether the previous window was also low (escalation
  needs two), hunger against the production stop, and feed against the reserve.
- **Cost & healing** - all-time LLM cost, tokens and wake-ups; how many runs were
  charged versus recorded at zero; the last 5 runs broken out (tokens in/out,
  cost, wake-ups, alerts healed, and the alerts each run raised); the cost avoided
  by healing; **what is being self-healed**, grouped by alert class with the last
  remedy and the alert text behind it; the active knobs with healed ones marked;
  and the full remedy log.
- **Token & cost history** - the longitudinal before/after story: actual cumulative
  ledger cost against the measured LLM-era low/mid/high counterfactual, switchable
  cost/token/per-run/healing views, 50/100/all-run ranges, the token composition of
  the old loop, projected monthly impact, a run-by-run zero-cost proof strip, and
  the six Python changes that moved the line to zero. Green is booked data; amber
  is explicitly labelled as the 46-run historical estimate rather than an invoice.
- **Findings** - the depth behind the operator: a ledger-derived herd/output curve,
  the run-50 species experiment, retired crop and collection hypotheses, a live
  old-loop cost counterfactual, detector redesigns, and the run-by-run timeline of
  how the model changed. It comes from `/api/evidence`, fetched once rather than
  repeated on the 2-second state poll.
- **Coop Rush** - a playable incremental farm game (see below).

It reads `state/` only and never calls the farm API.

The pipeline view is fed by `farm/progress.py`, which the loop updates as it
runs. Progress writes are atomic and best-effort: monitoring costs visibility
when it fails, never a cycle. The alternative (inferring position from
`state/raw/latest/` file mtimes) needed no instrumentation but could not tell
which run a file belonged to, could not see steps that make no server call, and
could not distinguish "skipped" from "not reached yet".

The execution trace combines two sources, and keeps their epistemic boundary
visible:

- **Measured spans.** `farm/progress.py` records the fourteen step intervals.
  `farm/mcp.py` records best-effort start/end rows around `Client.call()` and the
  `tools/list` handshake in `state/tool_calls.ndjson`: tool, bounded arguments,
  duration, success/error and a scrubbed 240-character result preview. Writes
  swallow their own errors, so a full disk costs observability rather than a
  cycle. Until that instrumentation is present in a deployed release, the panel
  falls back to mutation intent pairs and says **mutation calls only** rather
  than pretending read-only calls were captured.
- **Static reachability.** `farm/topology.py` parses `farm/*.py` with `ast` and
  resolves calls it can prove: `self.foo()`, `module.foo()`, `foo()` and
  `self.c.call("tool")`. Anything dynamic resolves to nothing rather than to a
  guess. Static extraction shows all possible paths, including a skipped step;
  measured boundary spans show which paths this run actually took. Profiling
  every Python function would slow the cycle and still say nothing about paths a
  particular run skipped, so functions stay in the inspector instead of the
  timing waterfall.
- **Time and architecture are separate views.** A waterfall is good at sequence,
  nesting and duration. A matrix is good at many-to-many reachability. The old
  spatial graph tried to encode both and produced crossing lines; the matrix has
  no lines to cross and preserves meaningful absence.
- **Static data stays off the poll.** `/api/topology` is fetched once and refreshed
  only when its fingerprint changes. `/api/state` carries the small live half:
  progress plus current-run call spans.
- **No dependency or build step.** `dashboard/trace_explorer.js` derives the span
  model, routes source paths, renders both views and owns interaction state with
  plain DOM/CSS. Its primary view is already structured text, so there is no
  canvas fallback or animation loop to fail.
- **Headless proof.** `dashboard/test_trace_explorer.js` verifies 50 model and HTML
  contracts; `deploy/test_tool_trace.py` verifies 19 telemetry, pairing, error and
  redaction contracts; `deploy/test_dashboard.py` runs the real page script and
  snapshot against a DOM stub for 91 checks; topology adds 55. Run all 215 with
  `deploy/test_dashboard.sh`. Render the current real run without opening a
  browser using `python3 deploy/preview_trace_explorer.py --check` (or
  `--view matrix`). `run.py --self-test` additionally blocks a release whose
  topology no longer matches `progress.STEPS` or has lost a server call.

The dashboard's own JavaScript is tested headlessly by `deploy/test_dashboard.py`,
which runs the real page script in JavaScriptCore against a DOM stub. It exists
because the page had two ways to freeze while still looking alive, neither
visible from the server side:

- **`render()` was one unguarded chain.** The pipeline, signals, chart and log
  tail were painted last, so a throw in any earlier panel left them frozen at
  their previous values while the overview kept refreshing. Each panel is now
  painted through `safe()`, and the number of failed panels is shown on the page
  instead of only in the console.
- **The poll bootstrap ran after the injected game bundle.** A top-level throw in
  the game stopped `load()` and `setInterval` from ever running and froze every
  tab at "connecting". The refresh now starts first and the game is wrapped in
  its own try/catch: the game is a tab, not the product.

Time-dependent panels also redraw on a local 1s tick rather than only when a poll
lands, so elapsed clocks and the next-run countdown advance even when the payload
is unchanged. A related trap the suite now guards: template placeholders are
substituted textually, so merely *naming* the game placeholder in a comment
injected a second 31 KB copy of the bundle into the page.

### Coop Rush

The real game is a measured dead end: the farm cap is saturated, crop timers never
advance, and only chickens ever produce. So the game tab is an idle/incremental
farm where all of that *does* scale - the fantasy the real one refused to provide.

Genre mechanics follow AdVenture Capitalist, whose numbers are documented:

| mechanic | how it works here |
| --- | --- |
| cost curve | `cost = base * coeff^owned`, coefficients 1.07 (coop) to 1.13 (market) |
| buy amounts | x1 / x10 / x100 / Max, priced as a geometric series; keys `1-4` |
| manual play | clicking a producer **starts** a cycle; the tick finishes it |
| managers | one-time coin cost, then the producer runs itself - what makes it idle |
| milestones | 25 / 50 / 100 / 200 / 300 / 400 owned alternate x2 produce and halved cycles |
| one-off upgrades | 14 permanent-for-the-run purchases, wiped by a rebuild |
| prestige | rebuild for heirloom hens: `floor(12 * sqrt(produce / 1M))`, +2% each |
| heirloom upgrades | 7 permanent perks, multiplicative with the per-heirloom bonus |
| offline | managed producers bank up to 4h of output while the page is closed |
| achievements | 18 measured-finding badges, +1% produce each and permanent across rebuilds |
| advisor | ranks affordable purchases by payback time; `B` buys it and `M` hires the next manager |
| feedback | floating output, egg bursts, milestone celebrations, stacked toasts and number pops |

Seven producers (coop, truffle pigs, beehives, wool shed, dairy barn, wheat field,
farmers market) are named after the things that produced nothing on the real farm.
`Ceiling Lift I/II` and `The Run-50 Lesson` are named after the ceiling that turned
out to be real.

The game lives in `game/` as real files rather than inside `monitor.py`'s HTML
string, because a simulation worth testing is not something you can test inside a
string literal. Both the dashboard tab and the standalone export compose from the
same files, so they cannot drift.

```
game/coop_rush.js        the simulation: DOM-free and network-free, so it is testable
game/coop_rush_ui.js     rendering and input; structure rebuilds only when it changes
game/coop_rush.css       styles, sharing the dashboard's palette variables
game/coop_rush.html      the markup fragment
game/test_mechanics.js   costs, milestones, achievements, advisor, saves, offline, balance
game/test_ui.js          drives the real click handler against a DOM stub
game/test_balance.js     6h auto-player simulation, printed as a table
deploy/test_game.sh      runs all of it: deploy/test_game.sh [--balance]
deploy/preview_game.py   static render of the panels, for looking at spacing
```

`deploy/preview_game.py` also produces a hostile-fixture render (0 owned, `8.42Qi`
costs, long text, all milestones done). It lifts the real card templates out of
the UI source and inlines the real stylesheet, so layout regressions can be
inspected even without running the server. The live dashboard and game were also
verified in the in-app browser at the responsive 704px viewport.

```
python3 deploy/preview_game.py --serve            # serve it on :8790
python3 deploy/preview_game.py --desktop --fit    # wide layout, scaled to a narrow panel
```

Looking at the result caught two defects beyond the reported one: the Buy/Manager
stack drifted against every card title by a different amount (centred column,
shorter than the card body - now stretched), and the cycle timer was dark-on-dark
whenever the bar was under half full.

There is no npm here and no browser automation, so the suites run in
JavaScriptCore via `osascript -l JavaScript`. That constraint is why the engine is
kept DOM-free. It has already earned its keep - the headless runs caught three
bugs that reading the code did not:

- **The game was unstartable.** With no coins and no producers there was no first
  move; the auto-player sat at zero purchases for 40 simulated minutes. You now
  start with one coop, exactly as AdCap hands you one lemonade stand.
- **The prestige button lied.** The sqrt handed out its first heirloom at ~7k
  produce while the button claimed it needed 1M, and a 1-heirloom reset is a trap.
  There is now a real 1M floor, and the locked button shows progress toward it.
- **A rebuild flatlined the farm.** Resetting dropped you to one hand-clicked coop
  with no income, and a 6h simulation showed it never recovering once the player
  stopped clicking. `Farmhand` (25 heirlooms, the cheapest perk) starts every
  rebuild with the coop manager already hired.

## Self-healing

Two agents run and repair each other, so no single stopped job silences the farm:

| agent | cadence | job |
| --- | --- | --- |
| `com.nickfigura.farmfriends` | 180s | the full cycle |
| `com.nickfigura.farmfriends.supervisor` | 60s | keep the schedule alive, remediate alerts |

`--supervise` does three things in order, and makes **no** farm calls unless the
loop has actually gone stale:

1. **Repair the schedule.** A dead scheduler makes every other signal
   meaningless. This is the failure that started it: the agent was simply not
   loaded, `--alerts` looked calm, and nothing ran for half an hour. Repairs are
   capped at `HEAL_SCHEDULER_MAX_REPAIRS_PER_HOUR` so a broken plist cannot
   become a restart loop.
2. **Recover a stale loop** by running one cycle inline, under the same lock the
   scheduled runs use, so it can never double-run the farm.
3. **Remediate alerts** via `farm/heal.py`, then acknowledge only what it fixed.

The healer's constraints are the interesting part:

- **Remedies are bounded and conservative.** Knobs can throttle growth
  (`rate_ceiling`, `adopt_cap`, `adopt_workers`) or do bounded extra work
  (`collect_passes`, `individual_feeds`). None can spend coins, adopt, sell,
  trade, or gift. The worst a bad healing decision can do is slow the farm down,
  and `rules.py` clamps every knob on read, so a corrupt store cannot escape the
  measured bounds.
- **One remedy per class per pass.** Several queued copies of one alert describe
  one condition. Stepping per alert once dropped a 5.0/s ceiling to 2.05/s.
- **Knobs relax one step per quiet pass** (`HEAL_ATTEMPT_RESET_RUNS`), so one bad
  afternoon cannot throttle the farm permanently.
- **Strategy is never healed.** Rank loss, threats, a rival passing us, a changed
  `tools/list`, a shrinking herd, or hunger at the production stop always
  escalate. So does any class whose remedy stops working: silent self-healing
  that is not working is worse than a page.

## Cost

Routine runs cost nothing, and `state/tokens.ndjson` proves it rather than
asserting it. Every cycle records an explicit zero; the only rows with a cost are
LLM wake-ups, booked at the moment `--alerts` prints a payload. Tokens are
estimated as `chars/4` plus the fixed context a wake-up carries, priced by
`LLM_INPUT_COST_PER_MTOK` / `LLM_OUTPUT_COST_PER_MTOK`. `--heal-status` and the
dashboard show cost per run, 24h, all-time, and the cost avoided by healing. The
**Token & cost history** tab then joins that ledger to the measured pre-Python
baseline: 150k-600k billed input tokens plus 59k thinking/output tokens per cycle.
It preserves the full low/high range instead of collapsing historical estimates
into fake precision, and its actual series moves automatically if a future alert
really wakes a model.

The detectors matter more than the prices here. Two of them were firing almost
every run for non-incidents, and fixing them removed most of the spend:

- **Throughput** now consults the backlog. A low units/chicken/min reading is
  only an incident if produce is piling up: runs 27-29 collected 62-760 units but
  ended with only 666-3,303 ready, so the herd was drained, not broken.
- **Transport retries** need a call-volume floor. One retry in a 35-call run is
  2.9% and looked like an incident; it also convinced the cycle that the previous
  run was unclean, which pinned the rate limiter at its 0.5/s floor for runs on
  end. `rules.transport_trouble` is now the single definition of "trouble" shared
  by the detector and the cycle's rate recovery.

**launchd runs `release/`, never the working tree.** Editing a file changes
nothing until `deploy/release.sh` publishes it. `--alerts` and `--review` print
the live revision and warn when the working tree has diverged.

## Growth is gated on evidence, not on ambition
Production is capped **per farm**, not per animal. Measured over runs 2-46:

| herd size | samples | total output | per chicken |
| --- | --- | --- | --- |
| 4,000-6,000 | 3 | 970 units/min | 0.194 |
| 6,000-8,000 | 3 | 1,135 units/min | 0.162 |
| 8,000-10,000 | 4 | 1,646 units/min | 0.183 |
| 10,000-10,800 | 3 | 1,487 units/min | 0.143 |
| 10,800-11,500 | 18 | 1,540 units/min | 0.138 |

Regression above 8,000 animals: **-0.028 units/min per extra chicken** (r=-0.065),
indistinguishable from zero. The last ~3,400 chickens produced nothing while feed
climbed from 20% to 40% of revenue. The falling per-chicken column is arithmetic,
not degradation: a flat numerator over a growing denominator. (It is also why the
throughput detector was firing constantly - that fix was right for the wrong
reason.)

So `MAX_ADOPTIONS_PER_RUN` is now only a **safety** ceiling for the cycle budget.
The economic decision is `rules.growth_verdict()`, re-measured every run:

- Output **now** (herd >= 95% of current) is compared against output at a herd
  **70-90% of current**. A window, not an open-ended tail: comparing 11,400
  animals against 420 always concludes growth works, which is how the farm ended
  up 3,400 animals past the ceiling.
- Growth continues only while now beats that window by 10%.
- On saturation the cap goes to 0 and the plateau is recorded **once**.
  Re-baselining it every run would make a real ceiling lift invisible.
- **It reverses itself.** If output at the same herd size later rises 15% above
  the plateau, the ceiling has moved and adoption resumes with no model involved.
- Thin evidence holds the standing decision instead of oscillating, and a herd
  under 2,000 is never gated, so early growth can't be blocked by noise.

Effect on run 46: adoptions 25 -> 0, server calls 30 -> 8, throughput back inside
the band at 0.181 units/chicken/min, and rank unchanged at #1 (406,432 vs Moe's
45,205). A counterfactual sweep confirmed the same rule would have permitted every
earlier stage of growth (caps of 25 at 3k, 5k, 7k, 9k, 10.5k animals).

### The cap is per farm, not per kind (tested, run 50)

The table above was built by varying chicken count only, which left an obvious
alternative alive: maybe the ceiling is per **kind**, and the farm was capped on
eggs while four other species sat unused. The supporting evidence was real - as
the egg rate per chicken fell 0.25 -> 0.134 units/min, the 2 pigs and 1 beehive
held 0.25-0.29 units/animal/min, which is exactly what a per-kind cap looks like.
Had it been true, total produce was capped near a fifth of the farm's potential.

`experiments/species_probe.py` settled it: 100 each of pig, sheep, cow and beehive
in one batch (9,517 coins out of 570k idle, under the cycle's own lock). Over the
next six runs, 25 minutes:

| kind | n | produce |
| --- | --- | --- |
| sheep | 100 | 0 wool, ever |
| cow | 100 | 0 milk, ever |
| pig | 102 | 1-2 truffles/run - same as the 2 pigs before |
| beehive | 101 | 1-2 honey/run - same as the 1 beehive before |

Total output stayed at ~1,550/min. The new animals sat at hunger 0 with nothing
ready, so this is not a warm-up artifact. **The cap is per farm and already
saturated: an animal of any kind added past saturation produces nothing.** The
growth gate was right, and is now right by experiment instead of by inference.
`rules.ADOPTABLE_KINDS` records the ban so nothing re-litigates it later.

Crops were tested in the same pass: one wheat, one corn and one pumpkin plot.
27 minutes later all three still read `0% grown, about 15/20/30 min left` - the
timers never advance, so a plot is a coin sink that never yields produce. `plant()`
will happily create unlimited plots, so this would have scaled badly.

Cost of the experiment: ~9,500 coins and ~500 feed/run for 400 animals that will
never produce. Against 570k idle coins and 15k/run of revenue that is noise, and
it closed the largest open question about the ceiling.

## What actually scores

Units collected is not the score, and twice it has been badly misleading:

- **Produce accrues as animals produce, not when we collect.** Run 25 gained
  41,207 lifetime produce while a collect call returned 572 units.
- **`collect_produce` returns "Nothing to collect right now ... or make sure your
  animals are fed" while any hunger is present.** The produce then appears in the
  barn during `feed_animals`. Runs 50 and 51 recorded `collected={}` and sold
  11,597 and 7,934 eggs in the same run.

So the authoritative health signal is the **leaderboard produce delta per minute**,
and `watch.py` judges that (`rules.produce_floor`, scaled per animal so an early
1,177-animal farm is not compared against an 11k-animal plateau). It catches the
one failure that can actually lose the game - the herd reaching hunger 70, where
production stops while collection and every other signal still look ordinary.

It requires **two consecutive low windows**. Produce arrives in bursts, so single
windows are lumpy: replaying all 56 runs of history, runs 40, 46 and 55 each read
105-246/min immediately before a 1,600-2,000/min window. One window would have
woken a model three times for nothing; two windows fires on none of them and still
catches a real stall one cycle (~4 min) later. A `PRODUCTION` alert has no remedy
and escalates by design - production stopping is not something to self-heal past.

Because production accrues without us, the loop's real job is narrower than it
looks: **keep the herd fed and never stall long enough for hunger to reach 70.**
Collecting, selling and adopting cannot raise the score at saturation; only feed
uptime can lower it.

## What the game actually does (measured, not assumed)

These corrected four wrong assumptions inherited from the prompt-era strategy:

- **Production is per-animal, not a global 5-minute tick.** 980 units appeared
  2.5 minutes after a collection that returned nothing. So the loop never aligns
  to a tick and measures throughput as units/chicken/**minute** over the real
  interval. Steady state is ~0.28-0.31.
- **Uncollected produce accumulates and is never lost.** Collecting more often is
  purely a reinvestment-speed play, which is why the cadence is 180s.
- **`feed_animals('all')` feeds a large subset, not everyone,** and costs ~1.1-1.5
  feed per fed animal *regardless of that animal's hunger*. Cost therefore scales
  with feeding frequency, so feeding is on a cooldown (`FEED_COOLDOWN_RUNS`) with
  an urgent override at hunger 60, well below the 70 production stop. Feeding
  every run was burning 40% of revenue.
- **`farm_events` is not worth a call.** With hundreds of adoptions per run its
  50-event window is entirely adoption spam. Removed.

## Safety and failure behaviour

- Unrecognized server wording raises `ParseDrift` **before** any mutating call.
- A global rate limiter (`MAX_CALLS_PER_SECOND`) bounds total pressure across all
  6 adoption workers, halves itself on a real server error, and recovers 10% per
  clean run. "You can't afford that" is classified as a normal stop, not an error.
- A 150s wall-clock budget governs adoption; a 240s `SIGALRM` makes the process
  kill itself rather than overrun its slot. (A stuck run once held the lock for
  nine minutes and cost three cycles of compounding.)
- `flock` on `state/.lock` means an overlapping run skips instead of double-acting.
- Every mutating call is bracketed in `state/intents.ndjson`.
- `--health` (4x/hour) runs a full recovery cycle itself if the last run is more
  than 11 minutes old, so a dead scheduler heals without a model.

## Secret handling

The MCP endpoint is a secret. It is read from `$FARM_MCP_URL` or
`~/.config/farm/endpoint` (mode 0600), never passed as a CLI argument (keeping it
out of `ps` and shell history), and scrubbed from every exception and log line by
`Client.scrub()`.

## Changing strategy

Edit `farm/rules.py`, run `--self-test`, then `deploy/release.sh`. Nothing else
encodes strategy, and changes cost no tokens. If you find yourself doing the same
arithmetic or judgement call every run, that belongs in `rules.py` or
`watch.py` — not in a prompt.
